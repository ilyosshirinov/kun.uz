package com.asgardiateam.ofb.humoservice.config;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("prod")
// todo : remove this comment after stage and prod are ready to work separate
@ImportAutoConfiguration(exclude = {org.springdoc.webmvc.ui.SwaggerConfig.class})
public class SwaggerConfigProd {

}