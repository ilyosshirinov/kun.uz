package com.asgardiateam.ofb.humoservice.humo.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@JsonPropertyOrder({"totalDebit", "totalCredit", "data"})
public class CardHistoryInfo {

    private Long totalDebit;

    private Long totalCredit;

    private List<BaseHistoryInfo> data;

    public CardHistoryInfo() {
        totalCredit = totalDebit = 0L;
        data = Collections.emptyList();
    }

}
