package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsStatusDTO {

    private Set<IiacsStatusItemDTO> item = new HashSet<>();

}
