package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.HUMO_NOT_AVAILABLE;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "humo_error")
public class HumoError {

    @Id
    private String id;

    @Column(name = "message_key")
    private String messageKey;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_status")
    private TransactionStatus status;

    public static HumoError pendingState(String state) {
        HumoError humoError = new HumoError();
        humoError.setId(state);
        humoError.setMessageKey(HUMO_NOT_AVAILABLE);
        humoError.setStatus(TransactionStatus.PENDING);
        return humoError;
    }

}
