package com.asgardiateam.ofb.humoservice.card;

import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import io.vavr.control.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.asgardiateam.ofb.humoservice.common.Utils.setIfNonNull;

@Log4j2
@Service
@RequiredArgsConstructor
public class CardServiceImpl implements CardService {

    private final CardRepository cardRepository;

    @Override
    @Transactional(readOnly = true)
//    @Cacheable(value = "card-by-uuid", key = "#uuid.toString()", unless = "#result == null ")
    public CardEntity getByUUID(UUID uuid) {
        return cardRepository.findById(uuid).orElseThrow(HumoServiceApiException::cardNotFound);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CardEntity> getByUUIDs(Collection<UUID> uuids) {
        return cardRepository.findByIdIn(uuids);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CardEntity> findByEncPan(String pan) {
        return cardRepository.findByEncryptedPan(pan);
    }

    @Override
    @Transactional(readOnly = true)
//    @Cacheable(value = "card_by_pan", key = "#pan", unless = "#result == null ")
    public CardEntity getByEncPan(String pan) {
        return cardRepository.findByEncryptedPan(pan).orElseThrow(HumoServiceApiException::cardNotFound);
    }

    @Override
//    @CacheEvict(value = "card_by_pan", key = "#cardEntity.encryptedPan")
    public CardEntity updateCardEntity(CardEntity cardEntity, OnlineCardInfo cardInfo) {
        try {
            setField(cardEntity, cardInfo);
            return save(cardEntity);
        } catch (Exception e) {
            log.error(e);
            log.error(Arrays.toString(e.getStackTrace()));
        }
        return cardEntity;
    }

    @Override
    @Transactional(readOnly = true)
//    @Cacheable(value = "card_by_id", key = "#id.toString()", unless = "#result == null ")
    public CardEntity getById(UUID id) {
        return cardRepository.findById(id).orElseThrow(HumoServiceApiException::cardNotFound);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CardEntity> findById(UUID id) {
        return Try.of(() -> getById(id)).toJavaOptional();
    }

    @Override
    @Transactional
    public void delete(CardEntity cardEntity) {
        cardRepository.delete(cardEntity);
    }

    @Override
    public void update(CardEntity cardEntity, OnlineCardInfo cardInfo) {
        try {
            setField(cardEntity, cardInfo);

            save(cardEntity);
        } catch (Throwable e) {
            log.error(e);
            log.error(Arrays.toString(e.getStackTrace()));
        }
    }

    private void setField(CardEntity cardEntity, OnlineCardInfo cardInfo) {
        setIfNonNull(cardInfo.getExpire(), cardEntity::setExpiry);
        setIfNonNull(cardInfo.getPhone(), cardEntity::setPhone);
        setIfNonNull(cardInfo.getHolderName(), cardEntity::setHolderName);
        Optional.of(cardInfo.isPrivate()).ifPresent(cardEntity::setIsPrivate);
        setIfNonNull(cardInfo.getCurrency(), cardEntity::setCurrency);
    }

    @Override
//    @Caching(evict = {
//            @CacheEvict(cacheNames = "card-by-id", key = "#a0.id.toString()"),
//            @CacheEvict(cacheNames = "card-by-encPan", key = "#a0.encryptedPan")
//    })
    public CardEntity save(CardEntity cardEntity) {
        return cardRepository.save(cardEntity);
    }
}
