package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PinVerifyDto {

    private UUID id;

    private String code;

}