package com.asgardiateam.ofb.humoservice.exception;

import com.asgardiateam.ofb.humoservice.log.LogService;
import com.asgardiateam.ofb.humoservice.message.MessageKey;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData.errorResponseData;
import static java.util.Objects.isNull;

@Log4j2
@RestController
@ControllerAdvice
@RequiredArgsConstructor
@SuppressWarnings("NullableProblems")
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private final LogService logService;

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleException(Exception e) {
        logService.logException(e);
        return ResponseEntity.internalServerError().body(errorResponseData(MessageKey.INTERNAL_ERROR));
    }

    @ExceptionHandler(HumoServiceApiException.class)
    public ResponseEntity<?> handlerHumoServiceApiException(HumoServiceApiException e) {
        log.debug("HumoServiceApiException message: {}, cause: {}", e.getMessage(), e.getCause());
        log.error(e);
        return ResponseEntity.status(e.getHttpStatus()).body(errorResponseData(e.getMessage()));
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        String message = isNull(ex.getBindingResult().getFieldError()) ? MessageKey.PARAMETERS_NOT_VALID : ex.getBindingResult().getFieldError().getDefaultMessage();
        return ResponseEntity.badRequest().body(errorResponseData(message));
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        return ResponseEntity.badRequest().body(errorResponseData(MessageKey.PARAMETERS_NOT_VALID));
    }
}
