package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.encryptservice.encrypt.EncryptDecryptService;
import com.asgardiateam.ofb.humoservice.card.CardEntity;
import com.asgardiateam.ofb.humoservice.card.CardService;
import com.asgardiateam.ofb.humoservice.card.balance.CardBalanceService;
import com.asgardiateam.ofb.humoservice.common.CircuitBreakerFactory;
import com.asgardiateam.ofb.humoservice.common.Lang;
import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.config.props.AppProps;
import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.controller.dto.CardDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.CardListToken;
import com.asgardiateam.ofb.humoservice.controller.dto.CardVerifyDTO;
import com.asgardiateam.ofb.humoservice.encryption.TripleDES;
import com.asgardiateam.ofb.humoservice.epos.RecoEposRepository;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.ShortCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsSmsVerifyResponseInProd;
import com.asgardiateam.ofb.humoservice.message.ValidationHelperService;
import com.asgardiateam.ofb.humoservice.transaction.TransactionRepo;
import com.asgardiateam.sms.SmsService;
import com.asgardiateam.sms.dto.SmsProvider;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Set;

import static com.asgardiateam.ofb.humoservice.common.Utils.reverseExpiry;
import static com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException.expiryNotValid;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.OTP_IS_NOT_CORRECT_MESSAGE;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
@Profile("prod")
public class CardHelperImpl extends HumoService {

    private final SmsService smsService;
    private final CardService cardService;
    private final EncryptDecryptService encryptDecryptService;
    private final ValidationHelperService validationHelperService;

    public CardHelperImpl(HumoAPI humoAPI, AppProps appProps, CardService cardService, TransactionRepo transactionRepo, RecoEposRepository recoEposRepository, CardBalanceService cardBalanceService, CircuitBreakerFactory circuitBreakerFactory, EncryptDecryptService encryptDecryptService, HumoErrorRepository humoErrorRepository, HumoProps humoProps, TripleDES tripleDES, SmsService smsService, ValidationHelperService validationHelperService) {
        super(humoAPI, appProps, cardService, transactionRepo, recoEposRepository, cardBalanceService, circuitBreakerFactory, encryptDecryptService, humoErrorRepository, humoProps, tripleDES, smsService);
        this.smsService = smsService;
        this.cardService = cardService;
        this.encryptDecryptService = encryptDecryptService;
        this.validationHelperService = validationHelperService;
    }

    @Override
    public ShortCardInfo addCard(CardDTO cardDTO, String lang) {
        String encPan = cardDTO.getPan();
        String pan = encryptDecryptService.decrypt(encPan);

        String exp = reverseExpiry(cardDTO.getExpire());
        OnlineCardInfo cardInfo = getCardByEncPan(encPan);
        if (!Objects.equals(exp, cardInfo.getExpire()))
            throw expiryNotValid();

        validationHelperService.checkPhoneNumbers(cardInfo.getPhone(), cardDTO.getUserPhone());

        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));

        String code = validationHelperService.generateCodeToAddCard();

        Lang defaultName = Lang.findLangByValue(lang);

        smsService.sendSms(validationHelperService.messageForClientToAddCard(code, defaultName.name()), cardInfo.getPhone(), SmsProvider.PLAY_MOBILE, true);

        String encCode = encryptDecryptService.encrypt(code);

        card.setVerifyCode(encCode);
        cardService.save(card);

        return ShortCardInfo.builder()
                .pan(pan)
                .id(card.getId())
                .expiry(cardDTO.getExpire())
                .phone(cardInfo.getPhone())
                .build();

    }

    @Override
    public OnlineCardInfo verifyCard(CardVerifyDTO cardVerifyDto) {
        CardEntity card = cardService.getById(cardVerifyDto.getId());

        OnlineCardInfo onlineCardInfo = getCardByEncPan(card.getEncryptedPan());

        String code = encryptDecryptService.encrypt(cardVerifyDto.getCode());
        if (!Objects.equals(code, card.getVerifyCode()))
            throw new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);

        return onlineCardInfo;

    }

    @Override
    public ShortCardInfo addCardNewWay(CardDTO cardDTO) {
        String encPan = cardDTO.getPan();
        String pan = encryptDecryptService.decrypt(encPan);

        OnlineCardInfo cardInfo = getCardByEncPan(encPan);
        String exp = reverseExpiry(cardDTO.getExpire());
        if (!Objects.equals(exp, cardInfo.getExpire()))
            throw expiryNotValid();

        // validationHelperService.checkPhoneNumbers(cardInfo.getPhone(), cardDTO.getUserPhone());

        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));
        card.setPhone(cardDTO.getUserPhone());

        sendRequestToHumoToAddCard(pan, Utils.makePhoneFormatForHumo(cardDTO.getUserPhone()));

        cardService.save(card);


        return ShortCardInfo.builder()
                .pan(pan)
                .id(card.getId())
                .expiry(cardDTO.getExpire())
                .phone(cardInfo.getPhone())
                .build();

    }

    @Override
    public OnlineCardInfo verifyCardNew(CardVerifyDTO cardVerifyDTO) {
        CardEntity card = cardService.getById(cardVerifyDTO.getId());

        OnlineCardInfo onlineCardInfo = getCardByEncPan(card.getEncryptedPan());
        Boolean isPin = status(cardVerifyDTO.getId());
        onlineCardInfo.setIsPinCode(isPin);
        IiacsSmsVerifyResponseInProd response = sendRequestToHumoToVerifyAddCard(card, cardVerifyDTO);

        if (Objects.isNull(response.getToken()))
            throw new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);
        card.setToken(response.getToken());
        cardService.save(card);
        return onlineCardInfo;
    }


}
