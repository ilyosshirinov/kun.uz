package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.message.MessageKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;

import java.util.UUID;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.UUID_NOT_VALID;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CardHistoryDTO {

    @NotNull(message = UUID_NOT_VALID)
    private UUID id;

    @PositiveOrZero(message = MessageKey.DATE_INVALID)
    private Long from;

    @Positive(message = MessageKey.DATE_INVALID)
    private Long to;

}
