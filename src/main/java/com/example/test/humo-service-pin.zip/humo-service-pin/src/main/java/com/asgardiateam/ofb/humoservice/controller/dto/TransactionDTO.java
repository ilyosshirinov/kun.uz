package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import java.util.UUID;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionDTO {

    @NotNull(message = PAN_NOT_VALID)
    private UUID cardId;

    @Positive(message = AMOUNT_NOT_VALID)
    @NotNull(message = AMOUNT_NOT_VALID)
    private Long amount;

    @Valid
    @NotNull(message = EPOS_NOT_VALID)
    private EposDTO epos;

    @NotBlank(message = ID_NOT_VALID)
    private String extId;

}
