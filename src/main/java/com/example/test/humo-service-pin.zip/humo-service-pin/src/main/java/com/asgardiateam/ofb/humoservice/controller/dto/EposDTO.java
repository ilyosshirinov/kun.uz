package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.MERCHANT_ID_NOT_VALID;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.TERMINAL_ID_NOT_VALID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EposDTO {

    @NotBlank(message = MERCHANT_ID_NOT_VALID)
    private String merchantId;

    @NotBlank(message = TERMINAL_ID_NOT_VALID)
    private String terminalId;

}
