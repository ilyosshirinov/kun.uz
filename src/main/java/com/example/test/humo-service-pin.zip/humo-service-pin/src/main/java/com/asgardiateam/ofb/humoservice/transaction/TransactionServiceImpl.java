package com.asgardiateam.ofb.humoservice.transaction;

import com.asgardiateam.ofb.humoservice.card.CardEntity;
import com.asgardiateam.ofb.humoservice.card.CardService;
import com.asgardiateam.ofb.humoservice.card.balance.CardBalanceService;
import com.asgardiateam.ofb.humoservice.common.Currency;
import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.ProcessingService;
import com.asgardiateam.ofb.humoservice.humo.dto.DocumentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import com.asgardiateam.ofb.humoservice.mapper.TransactionMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException.extIdExists;
import static com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException.transactionCanNotConfirm;
import static com.asgardiateam.ofb.humoservice.transaction.TransType.*;


@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final CardService cardService;
    private final TransactionRepo transactionRepo;
    private final ProcessingService processingService;
    private final TransactionMapper transactionMapper;
    private final CardBalanceService cardBalanceService;

    @Override
    public TransactionInfoDTO holdCreate(TransactionDTO request) {
        return doTransaction(request, DEBIT);
    }

    @Override
    public TransactionInfoDTO holdConfirm(String extID) {
        Transaction transaction = transactionRepo.findByExtId(extID).orElseThrow(HumoServiceApiException::transactionNotFound);
        if (!transaction.isHold())
            throw transactionCanNotConfirm();

        processingService.holdConfirm(transaction);
        return transactionMapper.toDTO(transaction);
    }

    @Override
    public TransactionInfoDTO credit(CreditTransactionDTO transaction) {
        return doTransaction(transaction, CREDIT);
    }

    @Override
    public TransactionInfoDTO reverse(String id) {
        var transaction = transactionRepo.findByExtId(id).orElseThrow(HumoServiceApiException::transactionNotFound);
        if (!transaction.isFailed())
            transaction = processingService.reverse(transaction);
        return transactionMapper.toDTO(transaction);
    }

    @Override
    public TransactionInfoDTO checkTransaction(String extId) {
        var transaction = transactionRepo.findByExtId(extId).orElseThrow(HumoServiceApiException::transactionNotFound);
        if (transaction.isPending()) {
            var transactionStatus = processingService.checkTransaction(transaction);
            transaction.setStatus(transactionStatus);
            transactionRepo.save(transaction);
        }
        return transactionMapper.toDTO(transaction);
    }

    private TransactionInfoDTO doTransaction(TransactionDTO request, TransType transType) {
        boolean isExists = transactionRepo.existsByExtId(request.getExtId());
        if (isExists)
            throw extIdExists();

        CardEntity card = cardService.getByUUID(request.getCardId());
        EposDTO epos = request.getEpos();
        Transaction transaction = Transaction.builder()
                .amount(request.getAmount())
                .currency(Currency.UZS)
                .extId(request.getExtId())
                .status(TransactionStatus.PROCESSING)
                .merchantId(epos.getMerchantId())
                .terminalId(epos.getTerminalId())
                .cardId(card.getId())
                .card(card.getEncryptedPan())
                .startTime(System.currentTimeMillis())
                .type(transType)
                .build();
        transaction = transactionRepo.save(transaction);
        transaction.setRequestId(Utils.generateToken());
        transactionRepo.save(transaction);
        cardBalanceService.resetBalance(card.getEncryptedPan());

        if (transType == CREDIT) {
            var creditTransactionDTO = (CreditTransactionDTO) request;
            transaction = processingService.credit(transaction, buildDocument(creditTransactionDTO.getSender()));
        } else
            transaction = processingService.holdCreate(transaction);

        return transactionMapper.toDTO(transaction);
    }

    private SenderDTO buildDocument(SenderDetailsDTO senderDetailsDTO) {
        PassportDocumentDTO passport = senderDetailsDTO.getDocument();
        DocumentDTO document = new DocumentDTO();
        Optional.ofNullable(passport).ifPresent(pass -> {
            Optional.ofNullable(pass.getSeriesNumber())
                    .ifPresent(document::setSeriesNumber);

            Optional.ofNullable(pass.getPinfl())
                    .ifPresent(document::setPinfl);
        });

        return SenderDTO.builder()
                .pan(senderDetailsDTO.getPan())
                .firstName(senderDetailsDTO.getFirstName())
                .lastName(senderDetailsDTO.getLastName())
                .retrievalRefNumber(senderDetailsDTO.getRetrievalRefNumber())
                .doc(document)
                .build();
    }

    @Override
    public BaseTransactionInfoDTO p2p(P2PTransactionDTO request) {
        boolean isExists = transactionRepo.existsByExtId(request.getExtId());
        if (isExists)
            throw extIdExists();

        EposDTO epos = request.getEpos();
        CardEntity senderCard = cardService.getByUUID(request.getSender());
        CardEntity receiverCard = cardService.getByUUID(request.getReceiver());

        Transaction transaction = Transaction.builder()
                .amount(request.getAmount())
                .currency(Currency.UZS)
                .extId(request.getExtId())
                .status(TransactionStatus.PROCESSING)
                .merchantId(epos.getMerchantId())
                .terminalId(epos.getTerminalId())
                .cardId(senderCard.getId())
                .card(senderCard.getEncryptedPan())
                .extraCardId(receiverCard.getId())
                .extraCard(receiverCard.getEncryptedPan())
                .startTime(System.currentTimeMillis())
                .type(P2P)
                .build();

        transactionRepo.save(transaction);
        transaction = processingService.p2p(transaction);

        return transactionMapper.toP2PDTO(transaction);
    }

}
