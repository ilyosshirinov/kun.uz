package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.hibernate.annotations.Check;
import com.asgardiateam.ofb.humoservice.validate.CheckPan;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardDTO {


    @NotBlank(message = PAN_NOT_VALID)
    private String pan;

    @NotBlank(message = CARD_EXPIRY_INVALID)
    @Pattern(regexp = "^((0\\d)|(1[012]))\\d{2}$", message = CARD_EXPIRY_INVALID)
    private String expire;

    @NotBlank(message = USER_PHONE_NOT_VALID)
    private String userPhone;

    public CardDTO(String pan, String expire) {
        this.pan = pan;
        this.expire = expire;
    }

}
