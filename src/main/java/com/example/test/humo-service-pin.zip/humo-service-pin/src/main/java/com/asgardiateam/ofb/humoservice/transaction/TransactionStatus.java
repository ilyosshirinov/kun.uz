package com.asgardiateam.ofb.humoservice.transaction;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TransactionStatus {

    HOLD(3),
    SUCCESS(4),
    FAILED(20),
    REVERSED(50),
    PENDING(30),
    PROCESSING(5);

    private final int code;

}
