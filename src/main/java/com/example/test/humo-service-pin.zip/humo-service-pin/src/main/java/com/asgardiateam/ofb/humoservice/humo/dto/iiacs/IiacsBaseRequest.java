package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class IiacsBaseRequest<T> {

    private String id;

    private T params;
}
