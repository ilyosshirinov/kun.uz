package com.asgardiateam.ofb.humoservice.humo.dto.balance;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import com.asgardiateam.ofb.humoservice.humo.HumoCardStatus;

@Getter
@Setter
@Builder
@ToString
public class CardBalanceDTO {

    private String pan;

    private String expiry;

    private String amount;

    private HumoCardStatus status;

    private String holderName;
}
