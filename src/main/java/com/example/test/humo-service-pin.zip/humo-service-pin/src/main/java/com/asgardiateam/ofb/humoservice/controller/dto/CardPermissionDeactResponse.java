package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CardPermissionDeactResponse {

    private Boolean isDeactivated;

}
