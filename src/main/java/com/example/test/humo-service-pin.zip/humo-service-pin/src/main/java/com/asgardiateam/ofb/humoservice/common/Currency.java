package com.asgardiateam.ofb.humoservice.common;

import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum Currency {

    UZS(860),
    USD(840);

    private final Integer code;


    public static Currency getCurrency(String code) {
        return Arrays.stream(Currency.values())
                .filter(currency -> currency.getCode().toString().equals(code))
                .findFirst()
                .orElseThrow(HumoServiceApiException::currencyNotValid);
    }

}
