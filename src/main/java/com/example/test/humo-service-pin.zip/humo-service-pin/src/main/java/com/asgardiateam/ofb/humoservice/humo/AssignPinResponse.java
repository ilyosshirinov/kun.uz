package com.asgardiateam.ofb.humoservice.humo;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssignPinResponse {

    private String approvalCode;

    private String systemsTraceAuditNumber;

    private String transmissionDateTime;

    private String transactionDateTime;

    private String acquirerId;

    private String terminalId;
}