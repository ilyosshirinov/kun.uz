package com.asgardiateam.ofb.humoservice.humo.dto;

public class BalanceCardInfo {
}
