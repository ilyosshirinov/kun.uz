package com.asgardiateam.ofb.humoservice.message;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class MessageInfo {

    private String message;
}
