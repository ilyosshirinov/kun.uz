package com.asgardiateam.ofb.humoservice.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Getter
public class HumoServiceApiException extends RuntimeException {

    private final HttpStatus httpStatus;

    public HumoServiceApiException(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
    }

    public static HumoServiceApiException cardNotFound() {
        return new HumoServiceApiException(CARDS_NOT_FOUND, BAD_REQUEST);
    }

    public static HumoServiceApiException permissionAlreadyGranted() {
        return new HumoServiceApiException(PERMISSION_ALREADY_GRANTED, BAD_REQUEST);
    }

    public static HumoServiceApiException transactionNotFound() {
        return new HumoServiceApiException(TRANSACTION_NOT_FOUND, BAD_REQUEST);
    }

    public static HumoServiceApiException otpNotCorrect() {
        return new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);
    }

    public static HumoServiceApiException permissionWasNotGrantedPreviously() {
        return new HumoServiceApiException(PERMISSION_WAS_NOT_GRANTED_PREVIOUSLY, BAD_REQUEST);
    }

    public static HumoServiceApiException phoneNumberNotSame() {
        return new HumoServiceApiException(PHONE_NOT_VALID, BAD_REQUEST);
    }

    public static HumoServiceApiException eposNotFound() {
        return new HumoServiceApiException(EPOS_NOT_FOUND, BAD_REQUEST);
    }

    public static HumoServiceApiException transactionCanNotConfirm() {
        return new HumoServiceApiException(TRANSACTION_CAN_NOT_CONFIRM, BAD_REQUEST);
    }

    public static HumoServiceApiException extIdExists() {
        return new HumoServiceApiException(EXT_ID_EXISTS, BAD_REQUEST);
    }

    public static HumoServiceApiException expiryNotValid() {
        return new HumoServiceApiException(CARD_EXPIRY_INVALID, BAD_REQUEST);
    }

    public static HumoServiceApiException humoNotAvailable() {
        return new HumoServiceApiException(HUMO_NOT_AVAILABLE, BAD_REQUEST);
    }

    public static HumoServiceApiException bankNotFound() {
        return new HumoServiceApiException(BANK_NOT_FOUND, BAD_REQUEST);
    }

    public static HumoServiceApiException currencyNotValid() {
        return new HumoServiceApiException(CURRENCY_NOT_VALID, BAD_REQUEST);
    }

    public static HumoServiceApiException errorParamPan() {
        return new HumoServiceApiException(PAN_MUST_CONTAIN_ONLY_16DIGITS, BAD_REQUEST);
    }
    public static HumoServiceApiException errorPanPnflNotFound() {
        return new HumoServiceApiException(PINFL_NOT_FOUND, BAD_REQUEST);
    }
}
