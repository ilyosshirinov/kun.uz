package com.asgardiateam.ofb.humoservice.humo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentDTO {
    private String seriesNumber;

    private String pinfl;
    public DocumentDTO(String seriesNumber) {
        this.seriesNumber = seriesNumber;
    }


}
