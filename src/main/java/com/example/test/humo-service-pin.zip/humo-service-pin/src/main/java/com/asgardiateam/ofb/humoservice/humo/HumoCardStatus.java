package com.asgardiateam.ofb.humoservice.humo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Set;

@Getter
@RequiredArgsConstructor
public enum HumoCardStatus {

    APPROVED(Set.of("000")),
    NOT_ACTIVE(Set.of("104", "125")),
    BLOCKED(Set.of("100", "204", "207", "208", "209", "280")),
    BLOCKED_BY_USER(Set.of("281")),
    ;

    private final Set<String> statuses;

    private static final HumoCardStatus[] cardStatuses = HumoCardStatus.values();

    public static HumoCardStatus getStatus(String actionCode) {
        return Arrays.stream(cardStatuses)
                .filter(status -> status.getStatuses().contains(actionCode))
                .findFirst()
                .orElse(BLOCKED);
    }

}
