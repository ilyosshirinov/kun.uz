package com.asgardiateam.ofb.humoservice.transaction;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TransType {

    DEBIT(1),
    CREDIT(2),
    P2P(3);

    private final int code;
}
