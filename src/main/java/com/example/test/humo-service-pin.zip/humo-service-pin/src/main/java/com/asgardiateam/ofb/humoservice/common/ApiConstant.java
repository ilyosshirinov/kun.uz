package com.asgardiateam.ofb.humoservice.common;

public class ApiConstant {

    private ApiConstant() {

    }

    public static final String PROCESSING_V1_API = "/api/v1";
    public static final String HUMO_PAY = "/humo-pay";
    public static final String CARD = "/card";
    public static final String ADD = "/add";
    public static final String INFO = "/info";
    public static final String RECO = "/reco";
    public static final String HISTORY = "/history";
    public static final String BLOCK = "/block";
    public static final String STATUS = "/status";
    public static final String UNBLOCK = "/unblock";
    public static final String TRANSACTION = "/transaction";
    public static final String DEBIT = "/debit";
    public static final String HOLD = "/hold";
    public static final String HOLD_CONFIRM = "/hold-confirm";
    public static final String CREDIT = "/credit";
    public static final String REVERSE = "/reverse";
    public static final String CHECK = "/check";
    public static final String P2P = "/p2p";
    public static final String VERIFY = "/verify";

    public static final String DEACTIVATE = "/deactivate";
    public static final String PERMISSION = "/permission";
    public static final String RESET = "/reset";
    public static final String PIN = "/pin";
    public static final String TOTAL = "/total";
    public static final String BALANCE = "/balance";
    public static final String ASSIGN = "/assign";
    public static final String DASHBOARD = "/dashboard";

    public static final String GET_PINFL_METHOD = "/get-pinfl-method";

    public static final String TOKEN_LIST = "/token-list";
}
