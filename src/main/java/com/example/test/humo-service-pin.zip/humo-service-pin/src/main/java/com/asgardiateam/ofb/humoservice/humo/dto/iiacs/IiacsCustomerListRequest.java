package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsCustomerListRequest {
    private String phone;

    private String bankId;

    public IiacsCustomerListRequest(String phone) {
        this(phone,"MB_STD");
    }






}
