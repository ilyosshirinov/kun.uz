package com.asgardiateam.ofb.humoservice.common.responsedata;

import com.asgardiateam.ofb.humoservice.config.ThreadLocalSinglton;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData.responseData;

@Aspect
@Component
public class ResponseWrapperAspect {

    @Around("@annotation(com.asgardiateam.ofb.humoservice.common.responsedata.WrapResponse)")
    public Object wrapResponse(ProceedingJoinPoint point) throws Throwable {
        Object result = point.proceed();
        ThreadLocalSinglton.remove();
        return ResponseEntity.ok(responseData(result));
    }
}
