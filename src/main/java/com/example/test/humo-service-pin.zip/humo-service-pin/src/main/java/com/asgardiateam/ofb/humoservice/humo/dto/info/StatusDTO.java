package com.asgardiateam.ofb.humoservice.humo.dto.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonTypeName("statuses")
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusDTO {

    private String actionCode;

    private String actionDescription;

    private String effectiveDate;

}
