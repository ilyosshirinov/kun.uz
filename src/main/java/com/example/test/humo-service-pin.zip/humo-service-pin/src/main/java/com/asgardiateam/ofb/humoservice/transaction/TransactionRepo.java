package com.asgardiateam.ofb.humoservice.transaction;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransactionRepo extends JpaRepository<Transaction, Long> {

    boolean existsByExtId(String extID);

    Optional<Transaction> findByExtId(String extID);

}
