package com.asgardiateam.ofb.humoservice.controller;

import com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData;
import com.asgardiateam.ofb.humoservice.common.responsedata.WrapResponse;
import com.asgardiateam.ofb.humoservice.controller.dto.SendNotificationDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.ProcessingPanDTO;
import com.asgardiateam.ofb.humoservice.humopay.HumoPayService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;

import static com.asgardiateam.ofb.humoservice.common.ApiConstant.HUMO_PAY;
import static com.asgardiateam.ofb.humoservice.common.ApiConstant.PROCESSING_V1_API;

@Log4j2
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = PROCESSING_V1_API + HUMO_PAY, produces = MediaType.APPLICATION_JSON_VALUE)
public class HumoPayController {

    private final HumoPayService humoPayService;

    @PostMapping("/send-push-notification")
    public void sendPushNotification(@RequestBody @Valid SendNotificationDTO sendNotificationDTO) {
        humoPayService.sendPushNotification(sendNotificationDTO);
    }

    @WrapResponse
    @GetMapping("/processing-pan")
    public Object getProcessingPan(@RequestParam(name = "id") UUID id) {
        return humoPayService.getProcessingPan(id);
    }

}
