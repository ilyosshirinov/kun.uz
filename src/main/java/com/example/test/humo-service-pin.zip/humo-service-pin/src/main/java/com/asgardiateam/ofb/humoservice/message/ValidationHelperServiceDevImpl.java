package com.asgardiateam.ofb.humoservice.message;

import com.asgardiateam.messageservice.message.service.MessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.SMS_SEND_TO_ADD_CARD;

@Log4j2
@Service
@Profile("dev")
@RequiredArgsConstructor
public class ValidationHelperServiceDevImpl implements ValidationHelperService {

    private final MessageService messageService;

    @Override
    public String messageForClientToAddCard(String otp, String lang) {
        try {
            return String.format(messageService.getMessage(lang, SMS_SEND_TO_ADD_CARD), otp);
        } catch (Exception e) {
            return otp;
        }
    }

    @Override
    public void checkPhoneNumbers(String phoneNumber1, String phoneNumber2) {
        // do nothing
    }

    @Override
    public String generateCodeToAddCard() {
        return "999999";
    }

}
