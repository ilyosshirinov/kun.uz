package com.asgardiateam.ofb.humoservice.humo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.UUID;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ShortCardInfo {

    private UUID id;

    private String pan;

    private String expiry;

    private String phone;

}
