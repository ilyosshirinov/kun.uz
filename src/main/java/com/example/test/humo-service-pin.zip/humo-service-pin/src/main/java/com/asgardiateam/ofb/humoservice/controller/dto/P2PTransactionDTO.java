package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.message.MessageKey;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.util.UUID;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.AMOUNT_NOT_VALID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class P2PTransactionDTO {

    @NotNull(message = MessageKey.SENDER_CARD_NOT_VALID)
    private UUID sender;

    @NotNull(message = MessageKey.RECEIVER_CARD_NOT_VALID)
    private UUID receiver;

    @Positive(message = AMOUNT_NOT_VALID)
    @NotNull(message = AMOUNT_NOT_VALID)
    private Long amount;

    @NotBlank(message = ID_NOT_VALID)
    private String extId;

    @Valid
    @NotNull(message = EPOS_NOT_VALID)
    private EposDTO epos;

}

