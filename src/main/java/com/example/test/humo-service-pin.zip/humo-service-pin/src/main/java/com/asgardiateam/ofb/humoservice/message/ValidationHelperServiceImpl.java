package com.asgardiateam.ofb.humoservice.message;

import com.asgardiateam.messageservice.message.service.MessageService;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Random;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.SMS_SEND_TO_ADD_CARD;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.USER_PHONE_NOT_VALID;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Log4j2
@Service
@Profile("prod")
@RequiredArgsConstructor
public class ValidationHelperServiceImpl implements ValidationHelperService {

    private final MessageService messageService;

    @Override
    public void checkPhoneNumbers(String phoneNumber1, String phoneNumber2) {
        if (!Objects.equals(phoneNumber1, phoneNumber2))
            throw new HumoServiceApiException(USER_PHONE_NOT_VALID, BAD_REQUEST);
    }

    @Override
    public String generateCodeToAddCard() {
        Random random = new Random();
        return String.format(String.valueOf(random.nextInt(100000, 999999)));
    }


    @Override
    public String messageForClientToAddCard(String otp, String lang) {



        try {
            String message = messageService.getMessage(lang, SMS_SEND_TO_ADD_CARD);
            if (message.contains("%s")) {
                return String.format(message, otp);
            } else {
                return otp;
            }
        } catch (Exception e) {
            return otp;
        }
    }
}
