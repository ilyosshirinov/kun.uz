package com.asgardiateam.ofb.humoservice.epos;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "epos")
public class RecoEpos {

    @Transient
    private static final String sequenceName = "reco_epos_seq";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName =  sequenceName, allocationSize = 1)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "merchant")
    private String merchant;

    @Column(name = "terminal")
    private String terminal;

    @Column(name = "reco_time")
    private Long recoTime;

    @Version
    @Column(name = "version")
    private Long version;


}
