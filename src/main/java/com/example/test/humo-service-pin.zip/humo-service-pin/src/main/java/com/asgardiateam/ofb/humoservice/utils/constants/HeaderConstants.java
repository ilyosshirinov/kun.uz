package com.asgardiateam.ofb.humoservice.utils.constants;

public class HeaderConstants {

    public static final String X_LANG = "X-Lang";

    private HeaderConstants() {
    }

}
