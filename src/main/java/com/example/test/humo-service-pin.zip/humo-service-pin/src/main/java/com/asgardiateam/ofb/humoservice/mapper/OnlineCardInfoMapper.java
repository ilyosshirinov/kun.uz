package com.asgardiateam.ofb.humoservice.mapper;

import com.asgardiateam.ofb.humoservice.card.CardEntity;
import com.asgardiateam.ofb.humoservice.card.CardState;
import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.controller.dto.CardAddDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.CardInfoDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.P2PInfoDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.ShortCardInfo;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", imports = {Utils.class, CardState.class, StringUtils.class})
public interface OnlineCardInfoMapper {

    @Mapping(target = "id", source = "id")
    @Mapping(target = "expire", source = "expiry")
    @Mapping(target = "pan", expression = "java(pan)")
    @Mapping(target = "holderName", source = "holderName")
    @Mapping(target = "state", expression = "java(state)")
    @Mapping(target = "balance", expression = "java(balance)")
    @Mapping(target = "maskedPan", expression = "java(Utils.panFormat(pan))")
    @Mapping(target = "isPrivate", expression = "java(cardEntity.getIsPrivate())")
    @Mapping(target = "phone", expression = "java(Utils.phoneFormat(cardEntity.getPhone()))")
    @Mapping(target = "currency", source = "currency")
    OnlineCardInfo toDTO(CardEntity cardEntity, @Context String pan, @Context Long balance, @Context CardState state);

    @Mapping(target = "expire", expression = "java(Utils.reverseExpiry(cardInfo.getExpire()))")
    CardInfoDTO toDTO(OnlineCardInfo cardInfo);

    @Mapping(target = "pan", source = "pan")
    @Mapping(target = "id", source = "id")
    @Mapping(target = "phone", source = "phone")
    @Mapping(target = "expiry", source = "expiry")
    CardAddDTO toDTO(ShortCardInfo cardInfo);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "state", source = "state")
    @Mapping(target = "private", source = "private")
    @Mapping(target = "maskedPan", source = "maskedPan")
    @Mapping(target = "holderName", source = "holderName")
    @Mapping(target = "currency", source = "currency")
    @Mapping(target = "phone", source = "phone")
    P2PInfoDTO toP2PDTO(OnlineCardInfo cardInfo);

}
