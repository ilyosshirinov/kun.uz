package com.asgardiateam.ofb.humoservice.humo.dto.history;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MinMax {

    private int min;
    private int max;

    public static MinMax set(int min, int max) {
        return new MinMax(min, max);
    }

}
