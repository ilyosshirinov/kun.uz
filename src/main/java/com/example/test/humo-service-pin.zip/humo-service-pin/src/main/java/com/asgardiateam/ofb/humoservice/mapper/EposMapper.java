package com.asgardiateam.ofb.humoservice.mapper;

import com.asgardiateam.ofb.humoservice.epos.RecoEpos;
import com.asgardiateam.ofb.humoservice.epos.dto.RecoEposDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface EposMapper {

    RecoEposDTO toDTO(RecoEpos recoEpos);

    RecoEpos toEntity(RecoEposDTO recoEposDTO);
}
