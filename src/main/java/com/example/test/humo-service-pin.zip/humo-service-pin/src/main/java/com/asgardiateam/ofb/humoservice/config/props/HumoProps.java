package com.asgardiateam.ofb.humoservice.config.props;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;

@Setter
@Getter
@Validated
@ConfigurationProperties(prefix = "humo")
public class HumoProps {

    @NotBlank
    private String newUrl;

    @NotBlank
    private String newToken;

    @NotBlank
    private String login;

    @NotBlank
    private String ZPKKey;

    @NotBlank
    private String password;

    @NotBlank
    private String pointCode;

    @NotBlank
    private String issuingUrl;

    @NotBlank
    private String iiaCardUrl;

    @NotBlank
    private String balanceUrl;

    @NotBlank
    private String paymentUrl;

}
