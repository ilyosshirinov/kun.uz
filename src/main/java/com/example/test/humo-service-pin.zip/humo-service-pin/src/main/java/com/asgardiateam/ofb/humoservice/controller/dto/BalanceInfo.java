package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.common.Currency;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BalanceInfo {

    private Long totalBalance;

    private Currency currency;

}