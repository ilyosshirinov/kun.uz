package com.asgardiateam.ofb.humoservice.card;

import com.asgardiateam.ofb.humoservice.config.ThreadLocalSinglton;
import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.humo.ProcessingService;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.ShortCardInfo;
import com.asgardiateam.ofb.humoservice.mapper.OnlineCardInfoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CardManageServiceImpl implements CardManageService {

    private final ProcessingService processingService;
    private final OnlineCardInfoMapper cardInfoMapper;

    @Override
    public CardAddDTO addCard(CardDTO card, String  lang) {
        //ShortCardInfo cardInfo = processingService.addCard(card,lang);
        ShortCardInfo cardInfo = processingService.addCardNewWay(card);
        return cardInfoMapper.toDTO(cardInfo);
    }

    @Override
    public CardInfoDTO verifyCard(CardVerifyDTO card) {
        return cardInfoMapper.toDTO(processingService.verifyCardNew(card));
    }

    @Override
    public CardPermissionDeactResponse deactivatePermission(UUID cardId) {
        return new CardPermissionDeactResponse(processingService.deactivateCard(cardId));
    }

    @Override
    public CardInfoDTO getCard(UUID uuid) {
        return cardInfoMapper.toDTO(processingService.getCardByUuid(uuid));
    }

    @Override
    public P2PInfoDTO getCardBy(String encPan) {
        return cardInfoMapper.toP2PDTO(processingService.getCardByPan(encPan));
    }

    @Override
    public List<CardInfoDTO> getCards(Set<UUID> uuids) {
        return processingService.getCardsByUuids(uuids)
                .stream()
                .map(cardInfoMapper::toDTO)
                .sorted(
                        Comparator.comparing(CardInfoDTO::getExpire)
                                .thenComparing(CardInfoDTO::getMaskedPan)
                ).toList();
    }

    @Override
    public CardBlockResultDTO blockCard(CardBlockDTO request) {
        boolean isBlocked = processingService.block(request.getId());
        return new CardBlockResultDTO(request.getId(), isBlocked, ThreadLocalSinglton.getInfo(),ThreadLocalSinglton.getBlockOrUnblock());
    }

    @Override
    public CardUnblockResultDTO unblockCard(CardBlockDTO card) {
        return processingService.unblock(card.getId());
    }

    @Override
    public PinResetResponse resetPin(UUID cardId) {
        boolean isResetPinDone = processingService.resetPin(cardId);
        return new PinResetResponse(cardId, isResetPinDone);
    }

    @Override
    public PinVerifyResponse pinVerify(PinVerifyDto verifyDto) {
        boolean isPinVerify = processingService.pinVerify(verifyDto);
        return new PinVerifyResponse(verifyDto.getId(), isPinVerify);
    }

    @Override
    public TotalBalanceDTO getTotalBalance(Set<UUID> cards) {
        return processingService.getTotalBalance(cards);
    }

    @Override
    public CardHistoryInfo historyCard(CardHistoryDTO history) {
        return processingService.getCardHistory(history.getId(),
                history.getFrom(), history.getTo());
    }

    @Override
    public boolean assignPin(UUID cardId, String newPin, String terminalId) {
        return processingService.assignPin(cardId, newPin, terminalId);
    }

    @Override
    public PinflMethodDTO getCardPinfl(PinflMethodDTO request){
        return processingService.cardPinfl(request);
    }

    @Override
    public String getOnlyCardPinfl(String pan){
        return processingService.cardPinflByPan(pan);
    }

    @Override
    public Set<CardListToken> getListOfCardsByPhone(String phone) {
        return processingService.getListOfCardsByPhone(phone);
    }
}
