package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsCustomerListResponse {

    @JsonProperty(value = "Customer")
    private List<Customer> customer;

    @Getter
    @Setter
    @ToString
    public static class Customer{
        private String customerId;
        private String bankId;
        private String cardholderName;
        @JsonProperty(value = "Card")
        private List<Card> card;

    }


    @Getter
    @Setter
    @ToString
    public static class Card{
        private String state;
        private String pan;
        private String expiry;
    }


}
