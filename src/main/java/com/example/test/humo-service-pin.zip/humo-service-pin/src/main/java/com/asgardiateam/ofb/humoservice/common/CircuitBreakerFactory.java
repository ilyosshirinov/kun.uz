package com.asgardiateam.ofb.humoservice.common;

import com.asgardiateam.ofb.humoservice.config.R4JConfig;
import com.asgardiateam.ofb.humoservice.controller.dto.GroupType;
import com.asgardiateam.ofb.humoservice.controller.dto.TelegramMessageRequest;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.circuitbreaker.event.CircuitBreakerEvent;
import io.github.resilience4j.circuitbreaker.event.CircuitBreakerOnStateTransitionEvent;
import io.github.resilience4j.consumer.EventConsumerRegistry;
import io.vavr.control.Try;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;

@Getter
@Component
@Log4j2
public class CircuitBreakerFactory {

    private final CircuitBreakerRegistry registry;

    private final CircuitBreaker sendSms;
    private final CircuitBreaker payment;
    private final CircuitBreaker cardInfo;
    private final CircuitBreaker verifySms;
    private final CircuitBreaker cardsBlock;
    private final CircuitBreaker cardsUnBlock;
    private final CircuitBreaker recoBreaker;
    private final CircuitBreaker cardResetPin;
    private final CircuitBreaker cardsHistory;
    private final CircuitBreaker permissionDeactivate;

    private final CircuitBreaker deactivateCard;

    private static final String SEND_SMS = "send-sms";
    private static final String PAYMENT = "humo-payment";
    private static final String VERIFY_SMS = "verify-sms";
    private static final String CARD_INFO = "humo-cards-get";
    private static final String CARDS_BLOCK = "humo-cards-block";
    private static final String CARDS_UN_BLOCK = "humo-cards-un-block";
    private static final String CARD_RESET_PIN = "card-reset-pin";
    private static final String RECO_BREAKER = "humo-reco-breaker";
    private static final String CARDS_HISTORY = "humo-cards-history";
    private static final String DEACTIVATE_CARD = "humo-card-deactivate";
    private static final String PERMISSION_DEACTIVATE = "permission-deactivate";

    private final EventConsumerRegistry<CircuitBreakerEvent> eventRegistryEventConsumer;
    public static final String PUSH_NOTIFICATION_TO_GROUP_ROUTE = "push.notification.to.group.route";

    public static final String PUSH_NOTIFICATION_TO_GROUP_EXCHANGE = "push.notification.to.group.exchange";
    private final RabbitTemplate rabbitTemplate;

    private static final Map<CircuitBreaker.State, String> stateMap = new EnumMap<>(CircuitBreaker.State.class);

    public CircuitBreakerFactory(CircuitBreakerRegistry registry,
                                 EventConsumerRegistry<CircuitBreakerEvent> eventRegistryEventConsumer,
                                 RabbitTemplate rabbitTemplate) {
        this.registry = registry;

        this.sendSms = registry.circuitBreaker(SEND_SMS, R4JConfig.SEND_SMS);
        this.payment = registry.circuitBreaker(PAYMENT, R4JConfig.CARDS_CONFIG);
        this.cardInfo = registry.circuitBreaker(CARD_INFO, R4JConfig.CARDS_CONFIG);
        this.verifySms = registry.circuitBreaker(VERIFY_SMS, R4JConfig.VERIFY_SMS);
        this.cardsBlock = registry.circuitBreaker(CARDS_BLOCK, R4JConfig.BLOCK_CONFIG);
        this.recoBreaker = registry.circuitBreaker(RECO_BREAKER, R4JConfig.HUMO_HISTORY);
        this.cardsHistory = registry.circuitBreaker(CARDS_HISTORY, R4JConfig.HUMO_HISTORY);
        this.cardResetPin = registry.circuitBreaker(CARD_RESET_PIN, R4JConfig.CARD_RESET_PIN);
        this.deactivateCard = registry.circuitBreaker(DEACTIVATE_CARD, R4JConfig.CARDS_CONFIG);
        this.permissionDeactivate = registry.circuitBreaker(PERMISSION_DEACTIVATE, R4JConfig.PERMISSION_DEACTIVATE);
        this.cardsUnBlock = registry.circuitBreaker(CARDS_UN_BLOCK, R4JConfig.UN_BLOCK_CONFIG);
        this.eventRegistryEventConsumer = eventRegistryEventConsumer;
        this.rabbitTemplate = rabbitTemplate;
    }

    @PostConstruct
    public void init() {
        stateMap.put(CircuitBreaker.State.CLOSED, "\uD83D\uDFE2");
        stateMap.put(CircuitBreaker.State.OPEN, "\uD83D\uDD34");
        stateMap.put(CircuitBreaker.State.HALF_OPEN, "\uD83D\uDFE1");

        Arrays.stream(this.getClass().getDeclaredFields())
                .filter(field -> field.getType().equals(CircuitBreaker.class))
                .map(item -> Try.of(() -> item.get(this))
                        .getOrElseThrow(() -> new IllegalArgumentException("Can not init circuit breakers"))
                )
                .map(CircuitBreaker.class::cast)
                .map(CircuitBreaker::getEventPublisher)
                .forEach(eventPublisher -> eventPublisher.onStateTransition(this::notifyTelegramAnalytics));
    }

    private void notifyTelegramAnalytics(CircuitBreakerOnStateTransitionEvent circuitBreakerOnStateTransitionEvent) {

        log.debug("CB state: {}, time: {}, cbName: {}, cbTime: {}",
                circuitBreakerOnStateTransitionEvent.getStateTransition(),
                circuitBreakerOnStateTransitionEvent.getEventType(),
                circuitBreakerOnStateTransitionEvent.getCircuitBreakerName(),
                circuitBreakerOnStateTransitionEvent.getCreationTime());

        String textForTelegram = """
                📋 SERVICE NAME = #%s
                ———————————————————————
                📎 CB NAME = #%s
                %s CB STATE = %s
                🕒 TIME = %s
                """;

        String readyTemplate = String.format(textForTelegram,
                "HUMO-SERVICE",
                circuitBreakerOnStateTransitionEvent.getCircuitBreakerName(),
                stateMap.getOrDefault(circuitBreakerOnStateTransitionEvent.getStateTransition().getToState(), "\uD83D\uDFE3"),
                circuitBreakerOnStateTransitionEvent.getStateTransition(),
                circuitBreakerOnStateTransitionEvent.getCreationTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        Try.run(() -> rabbitTemplate.convertAndSend(PUSH_NOTIFICATION_TO_GROUP_EXCHANGE, PUSH_NOTIFICATION_TO_GROUP_ROUTE, new TelegramMessageRequest(readyTemplate, GroupType.CIRCUIT_BREAKER)))
                .onFailure(log::error);

    }

}
