package com.asgardiateam.ofb.humoservice.controller;

import com.asgardiateam.ofb.humoservice.card.CardManageService;
import com.asgardiateam.ofb.humoservice.common.responsedata.WrapResponse;
import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.validate.PhoneNumberConstraint;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Set;
import java.util.UUID;

import static com.asgardiateam.ofb.humoservice.common.ApiConstant.*;
import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData.responseData;

@Log4j2
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = PROCESSING_V1_API, produces = MediaType.APPLICATION_JSON_VALUE)
public class CardController {

    private final CardManageService cardManageService;

    @WrapResponse
    @PostMapping(CARD + ADD)
    public Object addCard(@Valid @RequestBody CardDTO card, @RequestParam(required = false) String  lang) {
        return cardManageService.addCard(card, lang);
    }

    @WrapResponse
    @PostMapping(CARD + VERIFY)
    public Object verifyCard(@Valid @RequestBody CardVerifyDTO cardDTO) {
        return cardManageService.verifyCard(cardDTO);
    }

    @WrapResponse
    @GetMapping(CARD + PERMISSION + DEACTIVATE + "/{cardId}")
    public Object deactivateCard(@PathVariable UUID cardId) {
        return cardManageService.deactivatePermission(cardId);
    }

    @WrapResponse
    @PostMapping(CARD + INFO)
    public Object getCardInfo(@Valid @RequestBody PanDTO card) {
        return cardManageService.getCardBy(card.getPan());
    }

    @WrapResponse
    @GetMapping(CARD + "/{uuid}")
    public Object getCard(@PathVariable UUID uuid) {
        return cardManageService.getCard(uuid);
    }

    @WrapResponse
    @PostMapping(CARD)
    public Object getCards(@RequestBody @NotEmpty Set<UUID> uuids) {
        return cardManageService.getCards(uuids);
    }

    @WrapResponse
    @PostMapping(CARD + BLOCK)
    public Object blockCard(@Valid @RequestBody CardBlockDTO card)   {
        return cardManageService.blockCard(card);
    }

    @WrapResponse
    @PostMapping(CARD + UNBLOCK)
    public Object unblock(@Valid @RequestBody CardBlockDTO card) {
        return cardManageService.unblockCard(card);
    }

    @WrapResponse
    @PostMapping(CARD + HISTORY)
    public Object getHistoryCard(@Valid @RequestBody CardHistoryDTO history) {
        return cardManageService.historyCard(history);
    }

    @WrapResponse
    @GetMapping(CARD + PIN + RESET + "/{cardId}")
    public Object pinReset(@PathVariable UUID cardId) {
        return cardManageService.resetPin(cardId);
    }

    @WrapResponse
    @PostMapping(CARD + PIN + RESET + VERIFY)
    public Object pinVerify(@RequestBody PinVerifyDto verifyDto) {
        return cardManageService.pinVerify(verifyDto);
    }

    @WrapResponse
    @PostMapping(CARD + TOTAL + BALANCE)
    public Object getTotalBalance(@RequestBody @NotEmpty Set<UUID> cards) {
        return cardManageService.getTotalBalance(cards);
    }

    @WrapResponse
    @PostMapping(CARD + ASSIGN + PIN)
    public Object assignPin(@RequestParam @NotNull UUID cardId,
                            @RequestParam @NotBlank String newPin,
                            @RequestParam @NotBlank String terminalId) {
        Boolean isAssigned = cardManageService.assignPin(cardId, newPin, terminalId);
        return new AssignPinResponse(isAssigned);
    }

    @WrapResponse
    @PostMapping("/transaction" + GET_PINFL_METHOD)
    public ResponseEntity<?> pinflMethod(@Valid @RequestBody PinflMethodDTO request) {
        return ResponseEntity.ok(responseData(cardManageService.getCardPinfl(request)));
    }

    @WrapResponse
    @GetMapping(CARD + GET_PINFL_METHOD + "/{pan}")
    public Object pinflMethod(@Valid @PathVariable String pan) {
        return ResponsePinflDto.builder().pinfl(StringUtils.trim(cardManageService.getOnlyCardPinfl(pan))).build();
    }


    @WrapResponse
    @GetMapping(CARD + TOKEN_LIST + "/{phone}")
    public Object getTokenList(@PathVariable @Valid  @PhoneNumberConstraint String phone) {
        return cardManageService.getListOfCardsByPhone(phone);
    }
}
