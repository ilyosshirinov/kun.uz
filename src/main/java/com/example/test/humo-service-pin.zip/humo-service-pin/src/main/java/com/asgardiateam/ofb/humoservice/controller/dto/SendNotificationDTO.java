package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SendNotificationDTO {

    @NotEmpty(message = APP_NAME_NOT_VALID)
    private String appName;

    @NotEmpty(message = RNS_ID_NOT_VALID)
    private String rnsId;

    @NotEmpty(message = RNS_MESSAGE_NOT_VALID)
    private String rnsMsg;

}
