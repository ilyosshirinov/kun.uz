package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.UUID;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardAddDTO {

    private UUID id;

    private String pan;

    private String expiry;

    private String phone;

}
