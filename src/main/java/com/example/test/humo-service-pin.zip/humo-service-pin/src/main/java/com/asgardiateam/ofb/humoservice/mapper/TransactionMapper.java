package com.asgardiateam.ofb.humoservice.mapper;

import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.controller.dto.EposDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.P2PTransactionInfoDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.TransactionInfoDTO;
import com.asgardiateam.ofb.humoservice.humo.HumoTransType;
import com.asgardiateam.ofb.humoservice.humo.dto.BaseHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.history.MiddleHistoryInfo;
import com.asgardiateam.ofb.humoservice.transaction.Transaction;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.ZoneId;

@Mapper(componentModel = "spring", imports = {StringUtils.class, Long.class, Utils.class, HumoTransType.class})
public interface TransactionMapper {

    ZoneId ASIA_KARACHI_ZONE = ZoneId.of("Asia/Karachi");

    @Mapping(target = "id", source = "id")
    @Mapping(target = "card", source = "card")
    @Mapping(target = "extId", source = "extId")
    @Mapping(target = "error", source = "error")
    @Mapping(target = "amount", source = "amount")
    @Mapping(target = "endTime", source = "endTime")
    @Mapping(target = "startTime", source = "startTime")
    @Mapping(target = "reverseTime", source = "reverseTime")
    @Mapping(target = "type", expression = "java(transaction.getType().getCode())")
    @Mapping(target = "epos", source = "transaction", qualifiedByName = "eposMapper")
    @Mapping(target = "status", expression = "java(transaction.getStatus().getCode())")
    @Mapping(target = "currency", expression = "java(transaction.getCurrency().getCode())")
    @Mapping(target = "paymentId", source = "responseId")
    @Mapping(target = "senderRRN", source = "senderRRN")
    @Mapping(target = "receiverRRN", source = "receiverRRN")
    TransactionInfoDTO toDTO(Transaction transaction);

    @Mapping(target = "sender", source = "card")
    @Mapping(target = "receiver", source = "extraCard")
    @Mapping(target = "id", source = "id")
    @Mapping(target = "extId", source = "extId")
    @Mapping(target = "error", source = "error")
    @Mapping(target = "amount", source = "amount")
    @Mapping(target = "endTime", source = "endTime")
    @Mapping(target = "startTime", source = "startTime")
    @Mapping(target = "reverseTime", source = "reverseTime")
    @Mapping(target = "type", expression = "java(transaction.getType().getCode())")
    @Mapping(target = "epos", source = "transaction", qualifiedByName = "eposMapper")
    @Mapping(target = "status", expression = "java(transaction.getStatus().getCode())")
    @Mapping(target = "currency", expression = "java(transaction.getCurrency().getCode())")
    @Mapping(target = "paymentId", source = "responseId")
    @Mapping(target = "senderRRN", source = "senderRRN")
    @Mapping(target = "receiverRRN", source = "receiverRRN")
    P2PTransactionInfoDTO toP2PDTO(Transaction transaction);

    @Named("eposMapper")
    default EposDTO eposMapper(Transaction transaction) {
        return new EposDTO(transaction.getMerchantId(), transaction.getTerminalId());
    }

    @Mapping(target = "city", source = "city")
    @Mapping(target = "amount", source = "tranAmt")
    @Mapping(target = "currency", source = "tranCcy")
    @Mapping(target = "terminal", source = "termId")
    @Mapping(target = "address", source = "country")
    @Mapping(target = "merchant", source = "merchant")
    @Mapping(target = "merchantName", source = "abvrName")
    @Mapping(target = "maskedPan", expression = "java(Utils.panFormat(pan))")
    @Mapping(target = "credit", expression = "java(HumoTransType.isCredit(HumoTransType.getByCode(historyInfo.getTranType())))")
    @Mapping(target = "reversal", expression = "java(HumoTransType.isReverse(HumoTransType.getByCode(historyInfo.getTranType())))")
    @Mapping(target = "time", expression = "java(historyInfo.getTranDateTime().atZone(ASIA_KARACHI_ZONE).toInstant().toEpochMilli())")
    @Mapping(target = "transactionNumber", expression = "java(StringUtils.isNumeric(historyInfo.getRefNumber()) ? Long.parseLong(historyInfo.getRefNumber()) : null)")
    BaseHistoryInfo toDTO(MiddleHistoryInfo historyInfo, @Context String pan);

}
