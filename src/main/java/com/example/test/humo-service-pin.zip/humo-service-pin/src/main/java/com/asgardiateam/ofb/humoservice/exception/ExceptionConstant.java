package com.asgardiateam.ofb.humoservice.exception;

import lombok.Getter;

@Getter
public final class ExceptionConstant {

    private ExceptionConstant() {
    }

    public static final String TIME_OUT = "TIME_OUT";
    public static final String SERVER_ERROR = "SERVER_ERROR";
    public static final String CLIENT_ERROR = "CLIENT_ERROR";
    public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
    public static final String ENCRYPTED_SERVICE_UNAVAILABLE = "ENCRYPT_SERVICE_UNAVAILABLE";

    public static final int RESOURCE_ACCESS_CODE = -1000;
    public static final int SERVER_ERROR_CODE = -1001;
    public static final int CLIENT_ERROR_CODE = 200;
    public static final int UNKNOWN_ERROR_CODE = -1003;

    public static final int PINFL_ERROR_CODE = 400;

    public static final int PINFL_NOT_FOUND_ERROR_CODE = 800;
}
