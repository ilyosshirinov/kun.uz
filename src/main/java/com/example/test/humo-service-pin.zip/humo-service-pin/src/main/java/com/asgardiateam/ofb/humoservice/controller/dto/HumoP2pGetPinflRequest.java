package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class HumoP2pGetPinflRequest {

    private String id;
    private Params params;

    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    public static class Params {

        private String pan;

        public String getPan() {
            return pan;
        }

        public void setPan(String pan) {
            this.pan = pan;
        }

        public Params(String pan) {
            this.pan = pan;
        }
    }
}
