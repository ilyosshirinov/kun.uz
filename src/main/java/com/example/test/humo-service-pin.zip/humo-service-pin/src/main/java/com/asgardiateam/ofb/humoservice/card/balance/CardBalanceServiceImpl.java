package com.asgardiateam.ofb.humoservice.card.balance;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;

import java.util.Optional;

import static com.asgardiateam.ofb.humoservice.common.Utils.setIfNonNull;

@Service
@RequiredArgsConstructor
public class CardBalanceServiceImpl implements CardBalanceService {

    private final CardBalanceRepo cardBalanceRepo;

    @Override
    public void resetBalance(String encPan) {
        cardBalanceRepo.findByEncryptedPan(encPan)
                .ifPresent(cardBalance -> {
                    cardBalance.setBalanceCacheTime(0L);
                    cardBalanceRepo.save(cardBalance);
                });
    }

    @Override
    public Optional<CardBalance> findByEncPan(String encPan) {
        return cardBalanceRepo.findByEncryptedPan(encPan);
    }

    @Override
    public CardBalance getById(String id) {
        return cardBalanceRepo.findById(id).orElseThrow(HumoServiceApiException::cardNotFound);
    }

    @Override
    public Optional<CardBalance> findById(String id) {
        return cardBalanceRepo.findById(id);
    }

    @Override
    public void delete(CardBalance cardBalance) {
        cardBalanceRepo.delete(cardBalance);
    }

    @Override
    public void update(CardBalance cardBalance, OnlineCardInfo cardInfo) {
        setIfNonNull(cardInfo.getBalance(), cardBalance::setBalance);
        setIfNonNull(cardInfo.getState(), cardBalance::setState);
        cardBalance.setBalanceCacheTime(System.currentTimeMillis());
        save(cardBalance);
    }

    @Override
    public CardBalance save(CardBalance cardBalance) {
        return cardBalanceRepo.save(cardBalance);
    }
}
