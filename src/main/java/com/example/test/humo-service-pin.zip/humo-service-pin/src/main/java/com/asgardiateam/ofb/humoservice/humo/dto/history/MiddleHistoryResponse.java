package com.asgardiateam.ofb.humoservice.humo.dto.history;

import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MiddleHistoryResponse {

    private List<MiddleHistoryInfo> rows;

}
