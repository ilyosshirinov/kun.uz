package com.asgardiateam.ofb.humoservice.humo.dto.payment;

import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Soap2CardDTO {

    private String sessionId;

    private String receiverPan;

    private String expiry;

    private Long amount;

    private String mid;

    private String tid;

    private String centerId;

    private SenderDTO sender;

}
