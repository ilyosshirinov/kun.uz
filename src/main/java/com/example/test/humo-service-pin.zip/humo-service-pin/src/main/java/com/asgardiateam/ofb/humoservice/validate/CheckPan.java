package com.asgardiateam.ofb.humoservice.validate;

import com.asgardiateam.ofb.humoservice.message.MessageKey;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CheckPanConstraint.class)
public @interface CheckPan {

    String message() default MessageKey.PAN_NOT_VALID;

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
