package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.humo.dto.DocumentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.Soap2CardDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class HumoFactoryTest {

    @InjectMocks
    private HumoFactory humoFactory;

    @Mock
    private HumoProps humoProps;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("test only has pinfl no passport data")
    void getSoap2CardWithPinfl() {
        // Arrange
        Soap2CardDTO request = new Soap2CardDTO();
        request.setSessionId("12345");
        request.setReceiverPan("4111111111111111");
        request.setExpiry("12/25");
        request.setAmount(1000L);
        request.setMid("MID123");
        request.setTid("TID123");
        request.setCenterId("CENTER123");

        SenderDTO sender = new SenderDTO();
        sender.setDoc(new DocumentDTO());
        sender.getDoc().setPinfl("31001937190024");

        request.setSender(sender);

        when(humoProps.getPointCode()).thenReturn("POINT123");
        when(humoProps.getLogin()).thenReturn("userLogin");
        String expectedSoapRequest = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAPENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
                "   <SOAP-ENV:Body>\n" +
                "      <ebppif1:Payment>\n" +
                "         <billerRef>SOAP_TOCARD_2</billerRef>\n" +
                "         <payinstrRef>SOAP_TOCARD_2</payinstrRef>\n" +
                "         <sessionID>12345</sessionID>\n" +
                "         <paymentRef>12345</paymentRef>\n" +
                "         <details>\n" +
                "            <item>\n" +
                "               <name>pan2</name>\n" +
                "               <value>4111111111111111</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>expiry</name>\n" +
                "               <value>12/25</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>ccy_code</name>\n" +
                "               <value>860</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>amount</name>\n" +
                "               <value>1000</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>merchant_id</name>\n" +
                "               <value>MID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>terminal_id</name>\n" +
                "               <value>TID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>point_code</name>\n" +
                "               <value>POINT123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>centre_id</name>\n" +
                "               <value>CENTER123</value>\n" +
                "            </item>\n" +
                "<item>\n" +
                "<name>sender_person_code</name>\n" +
                "<value>31001937190024</value>\n" +
                "</item>\n" +
                "         </details>\n" +
                "         <paymentOriginator>userLogin</paymentOriginator>\n" +
                "      </ebppif1:Payment>\n" +
                "   </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";

        // Act
        String actualSoapRequest = humoFactory.getSoap2Card(request);
        // Assert
        assertEquals(expectedSoapRequest, actualSoapRequest);
    }
    @Test
    @DisplayName("has passport data and sender fio and pinfl")
    void getSoap2CardWithPinflAndPassportData() {
        // Arrange
        Soap2CardDTO request = new Soap2CardDTO();
        request.setSessionId("12345");
        request.setReceiverPan("4111111111111111");
        request.setExpiry("12/25");
        request.setAmount(1000L);
        request.setMid("MID123");
        request.setTid("TID123");
        request.setCenterId("CENTER123");

        SenderDTO sender = new SenderDTO();
        sender.setDoc(new DocumentDTO());
        sender.getDoc().setPinfl("31001937190024");
        sender.getDoc().setSeriesNumber("AA1996221");
        sender.setFirstName("Jakhongir");
        sender.setLastName("Sabirov");

        request.setSender(sender);

        when(humoProps.getPointCode()).thenReturn("POINT123");
        when(humoProps.getLogin()).thenReturn("userLogin");
        String expectedSoapRequest = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAPENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
                "   <SOAP-ENV:Body>\n" +
                "      <ebppif1:Payment>\n" +
                "         <billerRef>SOAP_TOCARD_2</billerRef>\n" +
                "         <payinstrRef>SOAP_TOCARD_2</payinstrRef>\n" +
                "         <sessionID>12345</sessionID>\n" +
                "         <paymentRef>12345</paymentRef>\n" +
                "         <details>\n" +
                "            <item>\n" +
                "               <name>pan2</name>\n" +
                "               <value>4111111111111111</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>expiry</name>\n" +
                "               <value>12/25</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>ccy_code</name>\n" +
                "               <value>860</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>amount</name>\n" +
                "               <value>1000</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>merchant_id</name>\n" +
                "               <value>MID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>terminal_id</name>\n" +
                "               <value>TID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>point_code</name>\n" +
                "               <value>POINT123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>centre_id</name>\n" +
                "               <value>CENTER123</value>\n" +
                "            </item>\n" +
                "<item>\n" +
                "<name>sender_serial_no</name>\n" +
                "<value>AA</value>\n" +
                "</item>\n" +
                " <item>\n" +
                "<name>sender_id_card</name>\n" +
                "<value>1996221</value>\n" +
                "</item>\n" +
                "<item>\n" +
                "<name>sender_surname</name>\n" +
                "<value>Sabirov</value>\n" +
                "</item>\n" +
                "<item>\n" +
                "<name>sender_first_name</name>\n" +
                "<value>Jakhongir</value>\n" +
                "</item>\n" +
                "<item>\n" +
                "<name>sender_person_code</name>\n" +
                "<value>31001937190024</value>\n" +
                "</item>\n" +
                "         </details>\n" +
                "         <paymentOriginator>userLogin</paymentOriginator>\n" +
                "      </ebppif1:Payment>\n" +
                "   </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";


        // Act
        String actualSoapRequest = humoFactory.getSoap2Card(request);
        System.out.println(actualSoapRequest);
        // Assert
        assertEquals(expectedSoapRequest, actualSoapRequest);
    }

    @Test
    @DisplayName("has passport and no pinfl")
    void getSoap2CardNoPinflAndPassportData() {
        // Arrange
        Soap2CardDTO request = new Soap2CardDTO();
        request.setSessionId("12345");
        request.setReceiverPan("4111111111111111");
        request.setExpiry("12/25");
        request.setAmount(1000L);
        request.setMid("MID123");
        request.setTid("TID123");
        request.setCenterId("CENTER123");

        SenderDTO sender = new SenderDTO();
        sender.setDoc(new DocumentDTO());
        sender.getDoc().setSeriesNumber("AA1996221");
        sender.setFirstName("Jakhongir");
        sender.setLastName("Sabirov");

        request.setSender(sender);

        when(humoProps.getPointCode()).thenReturn("POINT123");
        when(humoProps.getLogin()).thenReturn("userLogin");
        String expectedSoapRequest = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAPENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
                "   <SOAP-ENV:Body>\n" +
                "      <ebppif1:Payment>\n" +
                "         <billerRef>SOAP_TOCARD_2</billerRef>\n" +
                "         <payinstrRef>SOAP_TOCARD_2</payinstrRef>\n" +
                "         <sessionID>12345</sessionID>\n" +
                "         <paymentRef>12345</paymentRef>\n" +
                "         <details>\n" +
                "            <item>\n" +
                "               <name>pan2</name>\n" +
                "               <value>4111111111111111</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>expiry</name>\n" +
                "               <value>12/25</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>ccy_code</name>\n" +
                "               <value>860</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>amount</name>\n" +
                "               <value>1000</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>merchant_id</name>\n" +
                "               <value>MID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>terminal_id</name>\n" +
                "               <value>TID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>point_code</name>\n" +
                "               <value>POINT123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>centre_id</name>\n" +
                "               <value>CENTER123</value>\n" +
                "            </item>\n" +
                "<item>\n" +
                "<name>sender_serial_no</name>\n" +
                "<value>AA</value>\n" +
                "</item>\n" +
                " <item>\n" +
                "<name>sender_id_card</name>\n" +
                "<value>1996221</value>\n" +
                "</item>\n" +
                "<item>\n" +
                "<name>sender_surname</name>\n" +
                "<value>Sabirov</value>\n" +
                "</item>\n" +
                "<item>\n" +
                "<name>sender_first_name</name>\n" +
                "<value>Jakhongir</value>\n" +
                "</item>\n" +
                "         </details>\n" +
                "         <paymentOriginator>userLogin</paymentOriginator>\n" +
                "      </ebppif1:Payment>\n" +
                "   </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";


        // Act
        String actualSoapRequest = humoFactory.getSoap2Card(request);
        System.out.println(actualSoapRequest);
        // Assert
        assertEquals(expectedSoapRequest, actualSoapRequest);
    }
    @Test
    @DisplayName("no passport and no pinfl")
    void getSoap2CardNoPinflAndNoPassportData() {
        // Arrange
        Soap2CardDTO request = new Soap2CardDTO();
        request.setSessionId("12345");
        request.setReceiverPan("4111111111111111");
        request.setExpiry("12/25");
        request.setAmount(1000L);
        request.setMid("MID123");
        request.setTid("TID123");
        request.setCenterId("CENTER123");

        SenderDTO sender = new SenderDTO();
        sender.setDoc(new DocumentDTO());


        request.setSender(sender);

        when(humoProps.getPointCode()).thenReturn("POINT123");
        when(humoProps.getLogin()).thenReturn("userLogin");
        String expectedSoapRequest = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAPENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
                "   <SOAP-ENV:Body>\n" +
                "      <ebppif1:Payment>\n" +
                "         <billerRef>SOAP_TOCARD_2</billerRef>\n" +
                "         <payinstrRef>SOAP_TOCARD_2</payinstrRef>\n" +
                "         <sessionID>12345</sessionID>\n" +
                "         <paymentRef>12345</paymentRef>\n" +
                "         <details>\n" +
                "            <item>\n" +
                "               <name>pan2</name>\n" +
                "               <value>4111111111111111</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>expiry</name>\n" +
                "               <value>12/25</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>ccy_code</name>\n" +
                "               <value>860</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>amount</name>\n" +
                "               <value>1000</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>merchant_id</name>\n" +
                "               <value>MID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>terminal_id</name>\n" +
                "               <value>TID123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>point_code</name>\n" +
                "               <value>POINT123</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>centre_id</name>\n" +
                "               <value>CENTER123</value>\n" +
                "            </item>\n" +
                "         </details>\n" +
                "         <paymentOriginator>userLogin</paymentOriginator>\n" +
                "      </ebppif1:Payment>\n" +
                "   </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";


        // Act
        String actualSoapRequest = humoFactory.getSoap2Card(request);
        System.out.println(actualSoapRequest);
        // Assert
        assertEquals(expectedSoapRequest, actualSoapRequest);
    }
}