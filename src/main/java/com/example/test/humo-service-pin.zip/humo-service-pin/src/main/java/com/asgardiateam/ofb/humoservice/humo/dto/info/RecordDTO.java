package com.asgardiateam.ofb.humoservice.humo.dto.info;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@JsonTypeName("record")
public class RecordDTO {

    private String status;

    private long index;

    private List<DataDTO> data;

}
