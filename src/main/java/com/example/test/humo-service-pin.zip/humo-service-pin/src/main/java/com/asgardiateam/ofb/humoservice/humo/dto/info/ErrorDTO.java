package com.asgardiateam.ofb.humoservice.humo.dto.info;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorDTO {

    private String code;

    @JsonAlias({"error", "error_message", "message"})
    private String error;

}
