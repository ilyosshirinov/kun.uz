package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CardUnblockResultDTO {

    private UUID id;

    private Boolean isUnblocked;

    private String message;

    private String cardInfo;

    private String blockOrUnblockInfo;

    public CardUnblockResultDTO(UUID id, Boolean isUnblocked, String message) {
        this.id = id;
        this.isUnblocked = isUnblocked;
        this.message = message;
    }
}
