package com.asgardiateam.ofb.humoservice.config;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@EnableRabbit
@Configuration
public class RabbitMqConfig {

    public static final String NOTIFICATION_HUMO_PAY_QUEUE = "notification.humo.pay.queue";
    public static final String NOTIFICATION_DIRECT_EXCHANGE = "notification.direct.exchange";


}