package com.asgardiateam.ofb.humoservice.gateway.notification.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PushRequestDTO {

    private String fcmToken;

    private String message;

}
