package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsBaseErrorResponse implements Serializable {

    private static final long serialVersionUID = 1905122041950251207L;

    private String id;

    private IiacsErrorResponse error;

    public IiacsBaseErrorResponse() {
        this.error = new IiacsErrorResponse();
    }

}
