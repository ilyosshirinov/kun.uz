package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CardListToken(String instId,
                            String lastActive,
                            String mfo,
                            String contractId,
                            String fullName,
                            String id,
                            String pan)
{

}
