package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType;
import com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateWrapper;
import com.asgardiateam.ofb.humoservice.config.ThreadLocalSinglton;
import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.controller.dto.HumoP2pGetPinflRequest;
import com.asgardiateam.ofb.humoservice.controller.dto.HumoP2pGetPinflResponse;
import com.asgardiateam.ofb.humoservice.exception.ExternalServiceException;
import com.asgardiateam.ofb.humoservice.exception.HumoPaymentException;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.BaseHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.history.MiddleHistoryRequest;
import com.asgardiateam.ofb.humoservice.humo.dto.history.MiddleHistoryResponse;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.*;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.P2PHumoRequest;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.PaymentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.Soap2CardDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.TransactionDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.request.PanRequest;
import com.asgardiateam.ofb.humoservice.mapper.TransactionMapper;
import com.asgardiateam.ofb.humoservice.transaction.TransType;
import com.asgardiateam.ofb.humoservice.transaction.Transaction;
import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;
import io.vavr.control.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.asgardiateam.ofb.humoservice.common.Utils.generateToken;
import static com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType.*;
import static com.asgardiateam.ofb.humoservice.exception.ExceptionConstant.*;
import static com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException.*;
import static com.asgardiateam.ofb.humoservice.humo.HumoTransStatus.getMsgKey;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.UNKNOWN_ERROR;
import static com.asgardiateam.ofb.humoservice.transaction.TransactionStatus.*;
import static com.asgardiateam.ofb.humoservice.transaction.TransactionStatus.SUCCESS;
import static java.time.Instant.ofEpochMilli;
import static java.util.Comparator.comparing;
import static java.util.Comparator.reverseOrder;
import static java.util.Objects.isNull;
import static java.util.Optional.ofNullable;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Log4j2
@Service
@RequiredArgsConstructor
public class HumoAPIImpl implements HumoAPI {

    private final HumoProps humoProps;
    private final HumoFactory humoFactory;
    private final TransactionMapper transactionMapper;
    private final RestTemplateWrapper restTemplateWrapper;

    private final HttpHeaders headers = new HttpHeaders();
    private final HttpHeaders soapHeaders = new HttpHeaders();

    private static final String PAYMENT_ID = "paymentID";
    private static final String PAYMENT_REF = "paymentRef";
    private static final String AUTH_REF_NUMBER = "auth_ref_number";
    private static final String ITEM = "item";
    private static final String AUTH_REF_NUMBER2 = "auth_ref_number2";
    private static final String ACTION = "action";
    private static final String CANCEL_REQUEST_RESPONSE = "ebppif1:CancelRequestResponse";
    private static final String TRANSACTION_STATUS = "status";
    private static final String RETURN_REQUEST_RESPONSE = "ebppif1:ReturnPaymentResponse";

    @PostConstruct
    protected void init() {
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(humoProps.getNewToken());

        soapHeaders.set("SOAPAction", "");
        soapHeaders.set("Connection", "close");
        soapHeaders.setContentType(MediaType.APPLICATION_XML);
        soapHeaders.setBasicAuth(humoProps.getLogin(), humoProps.getPassword());
    }

    @Override
    public IiacsSmsSendResponse sendSms(String pan, String phone, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsSmsSendRequest(pan));
        Supplier<IiacsBaseResponse<IiacsSmsSendResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/send/sms",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsSmsSendResponse>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    if (ex.getCode() == CLIENT_ERROR_CODE) {
                        if (Objects.equals(ex.getBodyInObject().getError().getCode(), 401))
                            throw phoneNumberNotSame();
                        else if (Objects.equals(ex.getBodyInObject().getError().getCode(), 409))
                            throw permissionAlreadyGranted();
                        else
                            throw cardNotFound();
                    } else {
                        throw ex;
                    }
                })
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public IiacsSmsVerifyResponse verifyCode(String pan, String code, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsSmsVerifyRequest(pan, code));
        Supplier<IiacsBaseResponse<IiacsSmsVerifyResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/send/code",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsSmsVerifyResponse>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 404) ? otpNotCorrect() : ex;
                })
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public IiacsPermissionDeactRes permissionDeactivate(String pan, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsPermissionDeactReq(pan));
        Supplier<IiacsBaseResponse<IiacsPermissionDeactRes>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/permission/deactivate",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsPermissionDeactRes>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 403) ? permissionWasNotGrantedPreviously() : ex;
                })
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public IiacsResponse getCardInfo(String pan, int mbFlag, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsCardRequest(pan, mbFlag));
        Supplier<IiacsBaseResponse<IiacsResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v3/iiacs/card",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsResponse>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                    .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE ? cardNotFound() : ex;
                })
                .peek(consumerResponse)
                .map(IiacsBaseResponse::getResult)
                .peek(iiacsResponse -> {
                    if(ThreadLocalSinglton.getFlag()){
                        ThreadLocalSinglton.setInfo(iiacsResponse.toString());
                    }
                })
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    private Consumer<IiacsBaseResponse<IiacsResponse>> consumerResponse = x ->{
        if (Objects.nonNull(x.getError()) && Integer.parseInt(x.getError().getCode()) == CLIENT_ERROR_CODE) {
            throw cardNotFound();
        }
    };

    private Consumer<IiacsBaseResponse<IiacsResponseV2>> consumerResponseV2 = x -> {
        if (Objects.nonNull(x.getError()) && Integer.parseInt(x.getError().getCode()) == CLIENT_ERROR_CODE) {
            throw cardNotFound();
        }
    };


    @Override
    public IiacsResponseV2 getCardInfoV2(String pan, int mbFlag, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsV2CardRequest(pan));
        Supplier<IiacsBaseResponse<IiacsResponseV2>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v3/iiacs/card2",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsResponseV2>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE ? cardNotFound() : ex;
                })
                .peek(consumerResponseV2)
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public MaskedPanDTO getMaskedPanDTO(String pan, RestTemplateType type) {

        var request = new IiacsBaseRequest<>(generateToken(), new PanRequest(pan));

        Supplier<IiacsBaseResponse<MaskedPanDTO>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v2/pm/masked-pan",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<MaskedPanDTO>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE ? cardNotFound() : ex;
                }).map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public TransactionDTO getTransactionByPaymentRef(String paymentRef, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getPaymentUrl(), type, humoFactory.getPaymentByRefNum(paymentRef));
        return checkTransaction(request);
    }

    @Override
    public TransactionDTO getTransactionByPaymentId(String paymentId, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getPaymentUrl(), type, humoFactory.getCheckPayment(paymentId));
        return checkTransaction(request);
    }

    private TransactionDTO checkTransaction(Supplier<String> request) {
        return Try.ofSupplier(request)
                .map(Utils::convertStringToDocument)
                .map(document -> TransactionDTO.builder()
                        .paymentRef(getFromNode(document, PAYMENT_REF))
                        .paymentId(getFromNode(document, PAYMENT_ID))
                        .status(getFromNode(document, TRANSACTION_STATUS))
                        .build()
                ).onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    String error = getFromNode(Utils.convertStringToDocument(ex.getBody()), "error");
                    if (Objects.equals(error, "-1"))
                        throw new HumoServiceApiException(TRANSACTION_NOT_FOUND, HttpStatus.BAD_REQUEST);
                    throw ex;
                }).getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public boolean blockCard(String pan, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIssuingUrl(), type, humoFactory.getAddCardToStop(pan));
        return Try.ofSupplier(request)
                .peek(ThreadLocalSinglton::setBlocOrUnblock)
                .map(Utils::convertStringToDocument)
                .map(result -> getFromNode(result, "response_code").equals("0"))
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);

    }

    @Override
    public boolean unblockCard(String pan, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIssuingUrl(), type, humoFactory.getRemoveCardFromStop(pan));
        return Try.ofSupplier(request)
                .peek(ThreadLocalSinglton::setBlocOrUnblock)
                .map(Utils::convertStringToDocument)
                .map(result -> getFromNode(result, "response_code").equals("0"))
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public boolean cardResetPin(String pan, String expiryDate, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIssuingUrl(), type, humoFactory.getResetPin(pan, expiryDate));
        return Try.ofSupplier(request)
                .map(Utils::convertStringToDocument)
                .map(result -> getFromNode(result, "response_code").equals("0"))
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public PaymentDTO holdCreate(String sessionId, String pan, String expiry, Long amount, String mid, String tid) {
        var transaction = new PaymentDTO(sessionId);
        transaction.setStatus(PENDING);
        try {
            var document = ofNullable(doPaymentRequest(humoFactory.getHoldCreate(sessionId, pan, expiry, amount + "", mid, tid)))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);

            var action = getFromNode(document, ACTION);
            if (!action.equals("4"))
                throw new HumoPaymentException(action);

            var paymentId = ofNullable(getFromNode(document, PAYMENT_ID))
                    .orElseThrow(ExternalServiceException::unknownErrorException);

            parseRRN(document, TransType.DEBIT, transaction);

            transaction.setPaymentId(paymentId);
            transaction.setStatus(HOLD);
        } catch (HumoPaymentException ex) {
            transaction.setHumoCode(ex.getCode());
            transaction.setErrorMsg(getMsgKey(ex.getCode()));
            transaction.setStatus(TransactionStatus.FAILED);
        } catch (ExternalServiceException ex) {
            transaction.setErrorMsg(ex.getMessage());
        } catch (Exception ex) {
            log.error(ex);
            transaction.setErrorMsg(UNKNOWN_ERROR);
        }
        return transaction;
    }

    @Override
    public TransactionStatus holdCancel(String paymentId) {
        try {
            var response = doPaymentRequest(humoFactory.getHoldCancel(paymentId));
            var document = ofNullable(response)
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
            var isEmpty = document.getElementsByTagName(CANCEL_REQUEST_RESPONSE).item(0).getTextContent().isEmpty();
            return isEmpty ? REVERSED : PENDING;
        } catch (HumoPaymentException ex) {
            log.debug("Payment Id = {} Failed = {}", paymentId, ex);
            return FAILED;
        } catch (ExternalServiceException ex) {
            return PENDING;
        } catch (Exception ex) {
            log.error(ex);
            return PENDING;
        }
    }

    @Override
    public IiacsSmsSendResponseInProd sendSmsInProd(String pan, String phone, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsSmsSendRequest(pan,phone));
        Supplier<IiacsBaseResponse<IiacsSmsSendResponseInProd>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/send/sms",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsSmsSendResponseInProd>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    if (ex.getCode() == CLIENT_ERROR_CODE) {
                        if (Objects.equals(ex.getBodyInObject().getError().getCode(), 401))
                            throw phoneNumberNotSame();
                        else if (Objects.equals(ex.getBodyInObject().getError().getCode(), 409))
                            throw permissionAlreadyGranted();
                        else
                            throw cardNotFound();
                    } else {
                        throw ex;
                    }
                }).map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public IiacsSmsVerifyResponseInProd verifyCodeInProd(String pan, String code, RestTemplateType type) {
        var request = new IiacsBaseRequest<>(generateToken(), new IiacsSmsVerifyRequest(pan, code));
        Supplier<IiacsBaseResponse<IiacsSmsVerifyResponseInProd>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/send/code",
                request,
                POST,
                headers,
                type,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsSmsVerifyResponseInProd>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == CLIENT_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 404) ? otpNotCorrect() : ex;
                })
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public IiacsCustomerListResponse getListOfCardsByPhone(IiacsCustomerListRequest request) {
        var sendingRequest = new IiacsBaseRequest<>(generateToken(),request);
        Supplier<IiacsBaseResponse<IiacsCustomerListResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v2/mb/customer-list",
                sendingRequest,
                POST,
                headers,
                TEN,
                new ParameterizedTypeReference<IiacsBaseResponse<IiacsCustomerListResponse>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                 .onFailure(ExternalServiceException.class, ex -> {
                throw ex.getCode() == CLIENT_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 404) ? otpNotCorrect() : ex;
        })
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public TransactionStatus holdReturn(String paymentId, String mid, String tid) {
        try {
            var document = ofNullable(doPaymentRequest(humoFactory.getHoldReturn(paymentId, mid, tid)))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
            var isEmpty = document.getElementsByTagName(RETURN_REQUEST_RESPONSE).item(0).getTextContent().isEmpty();
            return isEmpty ? REVERSED : PENDING;
        } catch (HumoPaymentException ex) {
            log.debug("Payment Id = {} Failed = {}", paymentId, ex);
            return FAILED;
        } catch (Exception ex) {
            log.error(ex);
            return PENDING;
        }
    }

    @Override
    public TransactionStatus creditCancel(String paymentId) {
        try {
            var document = ofNullable(doPaymentRequest(humoFactory.creditCancel(generateToken(), paymentId)))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
            var isEmpty = document.getElementsByTagName(CANCEL_REQUEST_RESPONSE).item(0).getTextContent().isEmpty();
            return isEmpty ? REVERSED : PENDING;
        } catch (HumoPaymentException ex) {
            log.debug("Payment Id = {} Failed = {}", paymentId, ex);
            return FAILED;
        } catch (Exception ex) {
            log.error(ex);
            return PENDING;
        }
    }

    @Override
    public TransactionStatus holdConfirm(String paymentId) {
        try {
            var document = ofNullable(doPaymentRequest(humoFactory.getHoldConfirm(paymentId)))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
            boolean isEqual = document.getElementsByTagName(ACTION).item(0).getTextContent().equals("10");
            return isEqual ? SUCCESS : PENDING;
        } catch (HumoPaymentException ex) {
            log.debug("Payment Id = {} Failed = {}", paymentId, ex);
            return FAILED;
        } catch (Exception ex) {
            log.error(ex);
            return PENDING;
        }
    }

    @Override
    public PaymentDTO credit(Soap2CardDTO request) {
        var transaction = new PaymentDTO(request.getSessionId());
        transaction.setStatus(PENDING);
        try {
            var document = ofNullable(doPaymentRequest(humoFactory.getSoap2Card(request)))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
            String action = document.getElementsByTagName(ACTION).item(0).getTextContent();
            if (!action.equals("4"))
                throw new HumoPaymentException(action);

            String paymentId = ofNullable(document.getElementsByTagName(PAYMENT_ID).item(0))
                    .map(Node::getTextContent)
                    .filter(StringUtils::isNoneEmpty)
                    .orElseThrow(ExternalServiceException::unknownErrorException);

            parseRRN(document, TransType.CREDIT, transaction);

            transaction.setPaymentId(paymentId);
            transaction.setStatus(SUCCESS);
        } catch (ExternalServiceException ex) {
            transaction.setErrorMsg(PROCESSING_NOT_AVAILABLE_MSG);
        } catch (HumoPaymentException ex) {
            log.debug("Error = {} Message = {}", ex.getCode(), ex.getMessage());
            transaction.setStatus(TransactionStatus.FAILED);
            transaction.setErrorMsg(getMsgKey(ex.getCode()));
        } catch (Exception ex) {
            log.error(ex);
            transaction.setErrorMsg(UNKNOWN_ERROR);
        }
        return transaction;
    }

    @Override
    public String p2pRequest(String sessionId, P2PHumoRequest request) {
        Supplier<String> p2pSupplier = () -> {
            request.setOriginatorId(humoProps.getLogin());
            String requestP2P = humoFactory.getEbppRequestP2P(request);

            return ofNullable(request(humoProps.getPaymentUrl(), TEN, requestP2P))
                    .map(Utils::convertStringToDocument)
                    .map(doc -> getFromNode(doc, PAYMENT_ID))
                    .filter(StringUtils::isNoneEmpty)
                    .orElseThrow(ExternalServiceException::unknownErrorException);
        };

        return Try.ofSupplier(p2pSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ExternalServiceException::reThrow)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public PaymentDTO p2pFinish(Transaction transaction) {

        var paymentDTO = new PaymentDTO(transaction.getRequestId());

        Supplier<Boolean> confirmSupplier = () -> {
            String request = humoFactory.getEbppPaymentP2P(transaction.getResponseId(), humoProps.getLogin());

            Document document = ofNullable(request(humoProps.getPaymentUrl(), THIRTY, request))
                    .map(Utils::convertStringToDocument)
                    .orElseThrow(ExternalServiceException::unknownErrorException);

            parseRRN(document, TransType.P2P, paymentDTO);

            return isNull(document.getElementsByTagName("error").item(0));
        };

        boolean isFinished = Try.ofSupplier(confirmSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    if (Objects.equals(ex.getHttpStatus(), INTERNAL_SERVER_ERROR)) {
                        String error = ofNullable(ex.getBody())
                                .map(Utils::convertStringToDocument)
                                .map(doc -> getFromNode(doc, "error"))
                                .orElse("-999");
                        throw new HumoPaymentException(error);
                    }
                    throw ex;
                }).getOrElseThrow(ExternalServiceException::unknownErrorException);

        paymentDTO.setStatus(isFinished ? SUCCESS : PENDING);

        return paymentDTO;
    }

    private void parseRRN(Document document, TransType transType, PaymentDTO transaction) {
        Try.of(() -> itemsToMap(document.getElementsByTagName(ITEM)))
                .peek(x -> {
                    switch (transType) {
                        case DEBIT, CREDIT -> transaction.setSenderRRN(x.get(AUTH_REF_NUMBER));
                        case P2P -> {
                            transaction.setSenderRRN(x.get(AUTH_REF_NUMBER));
                            transaction.setReceiverRRN(x.get(AUTH_REF_NUMBER2));
                        }
                    }
                });
    }

    private String doPaymentRequest(String request) {
        Supplier<String> requestSupplier = () -> request(humoProps.getPaymentUrl(), RestTemplateType.THIRTY, request);
        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .onFailure(ExternalServiceException.class, ex -> {
                    if (!Objects.equals(ex.getHttpStatus(), INTERNAL_SERVER_ERROR))
                        throw ex;
                    String error = ofNullable(ex.getBody())
                            .map(Utils::convertStringToDocument)
                            .map(doc -> getFromNode(doc, "error"))
                            .orElse("-999");
                    throw new HumoPaymentException(error);
                }).getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    private String request(String url, RestTemplateType type, String request) {
        return restTemplateWrapper.sendRequest(
                url,
                request,
                POST,
                soapHeaders,
                type,
                String.class
        );
    }

    private String getFromNode(Document document, String tag) {
        return Try.of(() -> document.getElementsByTagName(tag).item(0).getTextContent())
                .onFailure(log::error)
                .getOrElse("");
    }

    protected Map<String, String> itemsToMap(NodeList items) {
        HashMap<String, String> rowItems = new HashMap<>();
        if (items.getLength() != 0) {
            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);
                Element name = (Element) item.getElementsByTagName("name").item(0);
                Element value = (Element) item.getElementsByTagName("value").item(0);
                if (isNull(name) || isNull(value))
                    continue;

                rowItems.put(name.getTextContent(), value.getTextContent());
            }
        }
        return rowItems;
    }

    @Override
    public CardHistoryInfo getHistory(String pan, Long from, Long to) {
        Function<Long, LocalDateTime> toLocalTime = time ->
                ofEpochMilli(time)
                        .atZone(ZoneId.of("Asia/Karachi"))
                        .toLocalDateTime();

        var request = new IiacsBaseRequest<>(generateToken(),
                new MiddleHistoryRequest(pan,
                        toLocalTime.apply(from),
                        toLocalTime.apply(to))
        );

        Supplier<IiacsBaseResponse<MiddleHistoryResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/v1/ws/transaction-history",
                request,
                POST,
                headers,
                FORTY,
                new ParameterizedTypeReference<IiacsBaseResponse<MiddleHistoryResponse>>() {
                }
        );

        AtomicLong debit = new AtomicLong(0);
        AtomicLong credit = new AtomicLong(0);

        var result = Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                .map(IiacsBaseResponse::getResult)
                .map(MiddleHistoryResponse::getRows)
                .recoverWith(ExternalServiceException.class, ex -> {
                    if (Objects.equals(ex.getCode(), CLIENT_ERROR_CODE))
                        return Try.of(Collections::emptyList);
                    throw ex;
                }).getOrElseThrow(ExternalServiceException::unknownErrorException)
                .parallelStream()
                .map(item -> transactionMapper.toDTO(item, pan))
                .peek(item -> {
                    if (item.getCredit())
                        credit.addAndGet(item.getAmount());
                    else
                        debit.addAndGet(item.getAmount());
                }).sorted(comparing(BaseHistoryInfo::getTime, reverseOrder()))
                .collect(Collectors.toList());

        return new CardHistoryInfo(debit.get(), credit.get(), result);
    }

    @Override
    public Optional<String> reconciliationCreate(String terminalId) {
        String reconciliation = humoFactory.getReconciliation(terminalId);

        Supplier<String> request = () -> restTemplateWrapper.sendRequest(humoProps.getPaymentUrl(), reconciliation, POST,
                soapHeaders, FORTY, String.class);

        return Try.ofSupplier(request)
                .onFailure(log::error)
                .map(Utils::convertStringToDocument)
                .map(doc -> doc.getElementsByTagName(PAYMENT_ID))
                .map(node -> node.item(0))
                .map(Node::getTextContent)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex;
                }).toJavaOptional();
    }

    @Override
    public void reconciliationAuth(String paymentId) {
        String reconciliationAuth = humoFactory.getReconciliationAuth(paymentId);

        Supplier<String> request = () -> restTemplateWrapper.sendRequest(humoProps.getPaymentUrl(), reconciliationAuth, POST,
                soapHeaders, FORTY, String.class);

        Try.ofSupplier(request)
                .onFailure(log::error)
                .map(Utils::convertStringToDocument)
                .filter(Objects::nonNull)
                .map(doc -> doc.getElementsByTagName("error"))
                .map(node -> node.item(0))
                .filter(Objects::isNull)
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex;
                }).getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public boolean deactivateCard(String pan, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIssuingUrl(), type, humoFactory.deactivateCard(pan));
        return Try.ofSupplier(request)
                .map(Utils::convertStringToDocument)
                .map(result -> getFromNode(result, "response_code").equals("0"))
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public boolean activateCard(String pan, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIssuingUrl(), type, humoFactory.activateCard(pan));
        return Try.ofSupplier(request)
                .map(Utils::convertStringToDocument)
                .map(result -> getFromNode(result, "response_code").equals("0"))
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public AssignPinResponse assignPin(String pan, String originatorId, String expiry, String encryptedPin, String terminalId, RestTemplateType type) {
        Supplier<String> request = () -> request(humoProps.getIiaCardUrl(), type, humoFactory.assignPin(pan, humoProps.getLogin(), expiry, encryptedPin, terminalId));
        return Try.ofSupplier(request)
                .map(Utils::convertStringToDocument)
                .map(document -> AssignPinResponse.builder()
                        .acquirerId(getFromNode(document, "acquirerId"))
                        .approvalCode(getFromNode(document, "approvalCode"))
                        .terminalId(getFromNode(document, "terminalId"))
                        .transactionDateTime(getFromNode(document, "transactionDateTime"))
                        .transmissionDateTime(getFromNode(document, "transmissionDateTime"))
                        .systemsTraceAuditNumber(getFromNode(document, "systemsTraceAuditNumber"))
                        .build())
                .onFailure(log::error)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }

    @Override
    public HumoP2pGetPinflResponse p2pInfoGetPinfl(HumoP2pGetPinflRequest request, RestTemplateType type) {

        Supplier<IiacsBaseResponse<HumoP2pGetPinflResponse>> requestSupplier = () -> restTemplateWrapper.sendRequest(
                humoProps.getNewUrl() + "/cs/v1/pan-by-person-code",
                request,
                POST,
                headers,
                type, // -- not checked --
                new ParameterizedTypeReference<IiacsBaseResponse<HumoP2pGetPinflResponse>>() {
                }
        );

        return Try.ofSupplier(requestSupplier)
                .onFailure(log::error)
                /*.onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == PINFL_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 400) ? errorParamPan() : ex;
                })
                .onFailure(ExternalServiceException.class, ex -> {
                    throw ex.getCode() == PINFL_NOT_FOUND_ERROR_CODE && Objects.equals(ex.getBodyInObject().getError().getCode(), 404) ? errorPanPnflNotFound() : ex;
                })
                 */
                .map(IiacsBaseResponse::getResult)
                .getOrElseThrow(ExternalServiceException::unknownErrorException);
    }
}
