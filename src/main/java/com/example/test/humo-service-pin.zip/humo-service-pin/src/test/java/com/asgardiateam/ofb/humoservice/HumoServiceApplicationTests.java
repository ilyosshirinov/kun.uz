package com.asgardiateam.ofb.humoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumoServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
