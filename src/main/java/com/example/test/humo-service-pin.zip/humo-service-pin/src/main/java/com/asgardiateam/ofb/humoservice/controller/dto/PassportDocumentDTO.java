package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PassportDocumentDTO {

    private String firstName;

    private String lastName;

    private String seriesNumber;

    private String validTo;

    private String birthDate;

    private String nationality;

    private String pinfl;
}
