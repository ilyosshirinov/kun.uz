package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseTransactionInfoDTO {

    private Integer id;

    private String extId;

    private Long amount;

    private Integer currency;

    private Long startTime;

    private Long endTime;

    private Long reverseTime;

    private Integer type;

    private Integer status;

    private String error;

    private EposDTO epos;

    private String paymentId;

    private String senderRRN;

    private String receiverRRN;
}
