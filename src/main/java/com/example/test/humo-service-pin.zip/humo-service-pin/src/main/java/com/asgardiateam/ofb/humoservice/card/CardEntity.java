package com.asgardiateam.ofb.humoservice.card;

import com.asgardiateam.ofb.humoservice.audit.AuditingEntity;
import com.asgardiateam.ofb.humoservice.common.Currency;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Getter
@Setter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "card_table")
public class CardEntity extends AuditingEntity implements Serializable {

    @Transient
    private static final String sequenceName = "ofb_humo_card_seq";

    @Id
    @GeneratedValue(generator = sequenceName, strategy = GenerationType.SEQUENCE)
    @GenericGenerator(
            name = sequenceName,
            strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;

    @Column(name = "encrypted_pan", unique = true)
    private String encryptedPan;

    @Column(name = "expiry")
    private String expiry;

    @Column(name = "phone")
    private String phone;

    @Column(name = "bankc")
    private String bankC;

    @Column(name = "holder_name")
    private String holderName;

    @Column(name = "is_private")
    private Boolean isPrivate;

    @Column(name = "verify_code")
    private String verifyCode;

    @Column(name = "center_id")
    private String centerId;

    @Column(name = "currency")
    @Enumerated(EnumType.STRING)
    private Currency currency;

    @Column(name = "pinfl")
    private String pinfl;

    @Column(name = "token")
    private String token;

    public CardEntity(String encryptedPan) {
        this.encryptedPan = encryptedPan;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

}
