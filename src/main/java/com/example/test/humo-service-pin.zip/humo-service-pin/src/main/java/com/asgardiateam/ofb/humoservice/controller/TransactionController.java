package com.asgardiateam.ofb.humoservice.controller;

import com.asgardiateam.ofb.humoservice.controller.dto.CreditTransactionDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.P2PTransactionDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.PinflMethodDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.asgardiateam.ofb.humoservice.controller.dto.TransactionDTO;
import com.asgardiateam.ofb.humoservice.transaction.TransactionService;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import static com.asgardiateam.ofb.humoservice.common.ApiConstant.*;
import static com.asgardiateam.ofb.humoservice.common.ApiConstant.GET_PINFL_METHOD;
import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData.responseData;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.ID_NOT_VALID;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = PROCESSING_V1_API + TRANSACTION, produces = MediaType.APPLICATION_JSON_VALUE)
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping(HOLD)
    public ResponseEntity<?> doHoldCreate(@Valid @RequestBody TransactionDTO transaction) {
        return ResponseEntity.ok(responseData(transactionService.holdCreate(transaction)));
    }

    @PostMapping(HOLD_CONFIRM + "/{id}")
    public ResponseEntity<?> doHoldConfirm(@NotBlank(message = ID_NOT_VALID) @PathVariable String id) {
        return ResponseEntity.ok(responseData(transactionService.holdConfirm(id)));
    }

    @PostMapping(CREDIT)
    public ResponseEntity<?> doCredit(@Valid @RequestBody CreditTransactionDTO transaction) {
        return ResponseEntity.ok(responseData(transactionService.credit(transaction)));
    }

    @PostMapping(P2P)
    public ResponseEntity<?> doP2P(@Valid @RequestBody P2PTransactionDTO transaction) {
        return ResponseEntity.ok(responseData(transactionService.p2p(transaction)));
    }

    @PostMapping(REVERSE + "/{id}")
    public ResponseEntity<?> doReverse(@NotBlank(message = ID_NOT_VALID) @PathVariable String id) {
        return ResponseEntity.ok(responseData(transactionService.reverse(id)));
    }

    @PostMapping(CHECK + "/{id}")
    public ResponseEntity<?> doCheck(@NotBlank(message = ID_NOT_VALID) @PathVariable String id) {
        return ResponseEntity.ok(responseData(transactionService.checkTransaction(id)));
    }

}
