package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum GroupType {

    TRANSFER("transfer"),
    IDENTIFICATION("identification"),
    CIRCUIT_BREAKER("circuit_breaker");

    private final String secondName;

}