package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.encryptservice.encrypt.EncryptDecryptService;
import com.asgardiateam.ofb.humoservice.card.CardEntity;
import com.asgardiateam.ofb.humoservice.card.CardService;
import com.asgardiateam.ofb.humoservice.card.CardState;
import com.asgardiateam.ofb.humoservice.card.balance.CardBalance;
import com.asgardiateam.ofb.humoservice.card.balance.CardBalanceService;
import com.asgardiateam.ofb.humoservice.common.CircuitBreakerFactory;
import com.asgardiateam.ofb.humoservice.common.Currency;
import com.asgardiateam.ofb.humoservice.common.Utils;
import com.asgardiateam.ofb.humoservice.config.ThreadLocalSinglton;
import com.asgardiateam.ofb.humoservice.config.props.AppProps;
import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.encryption.TripleDES;
import com.asgardiateam.ofb.humoservice.epos.RecoEpos;
import com.asgardiateam.ofb.humoservice.epos.RecoEposRepository;
import com.asgardiateam.ofb.humoservice.exception.ExternalServiceException;
import com.asgardiateam.ofb.humoservice.exception.HumoPaymentException;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.*;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.P2PHumoRequest;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.PaymentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.Soap2CardDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.TransactionDTO;
import com.asgardiateam.ofb.humoservice.message.MessageKey;
import com.asgardiateam.ofb.humoservice.transaction.TransType;
import com.asgardiateam.ofb.humoservice.transaction.Transaction;
import com.asgardiateam.ofb.humoservice.transaction.TransactionRepo;
import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;
import com.asgardiateam.sms.SmsService;
import com.asgardiateam.sms.dto.SmsProvider;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.vavr.control.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.asgardiateam.ofb.humoservice.card.CardState.*;
import static com.asgardiateam.ofb.humoservice.common.Utils.*;
import static com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType.*;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;
import static com.asgardiateam.ofb.humoservice.transaction.TransType.CREDIT;
import static com.asgardiateam.ofb.humoservice.transaction.TransType.DEBIT;
import static com.asgardiateam.ofb.humoservice.transaction.TransactionStatus.*;
import static com.asgardiateam.ofb.humoservice.transaction.TransactionStatus.SUCCESS;
import static java.util.Objects.requireNonNullElse;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.StringUtils.*;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Log4j2
@Service
@RequiredArgsConstructor
public abstract class HumoService implements ProcessingService {
    private final HumoAPI humoAPI;
    private final AppProps appProps;
    private final CardService cardService;
    private final TransactionRepo transactionRepo;
    private final RecoEposRepository recoEposRepository;
    private final CardBalanceService cardBalanceService;
    private final CircuitBreakerFactory circuitBreakerFactory;
    private final EncryptDecryptService encryptDecryptService;
    private final HumoErrorRepository humoErrorRepository;
    private final HumoProps humoProps;
    private final TripleDES tripleDES;
    private final SmsService smsService;

    @Override
    public OnlineCardInfo getCardByUuid(UUID uuid) {
        CardEntity card = cardService.getById(uuid);
        return getCardByEncPan(card.getEncryptedPan());
    }

    @Override
    public Set<OnlineCardInfo> getCardsByUuids(Set<UUID> uuids) {
        return uuids.parallelStream()
                .map(card -> Try.of(() -> this.getCardByUuid(card)))
                .map(Try::toJavaOptional)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toSet());
    }

    @Override
    public OnlineCardInfo getCardByPan(String pan) {
        return getCardByEncPan(pan);
    }

    @Override
    public Transaction holdCreate(Transaction transaction) {
        try {
            transaction.setRequestId(generateToken());
            transactionRepo.save(transaction);

            CardEntity card = cardService.getByEncPan(transaction.getCard());
            String decPan = encryptDecryptService.decrypt(transaction.getCard());

            CircuitBreaker paymentCB = circuitBreakerFactory.getPayment();

            PaymentDTO result = paymentCB.executeSupplier(
                    () -> humoAPI.holdCreate(transaction.getRequestId(),
                            decPan,
                            card.getExpiry(),
                            transaction.getAmount(),
                            transaction.getMerchantId(),
                            transaction.getTerminalId())
            );

            if (result.getStatus() == TransactionStatus.FAILED) {
                transaction.setError(result.getErrorMsg());
                transaction.setResponseMeta(result.getHumoCode());
                transaction.setDetails(result.getErrorMsg());
            }
            transaction.setResponseId(result.getPaymentId());
            transaction.setResponseMeta(result.getHumoCode());
            transaction.setSenderRRN(result.getSenderRRN());
            transaction.setStatus(result.getStatus());
            return transactionRepo.save(transaction);
        } catch (CallNotPermittedException ex) {
            log.error(ex);
            transaction.setStatus(FAILED);
            transaction.setError(MessageKey.SERVICE_DISABLED);
            return transactionRepo.save(transaction);
        } catch (HumoServiceApiException ex) {
            log.error(ex);
            transaction.setStatus(FAILED);
            transaction.setError(ex.getMessage());
            return transactionRepo.save(transaction);
        } catch (Exception ex) {
            log.error(ex);
            transaction.setError(UNKNOWN_ERROR);
            transaction.setStatus(PENDING);
            return transactionRepo.save(transaction);
        }
    }

    @Override
    public Transaction holdConfirm(Transaction transaction) {
        CircuitBreaker paymentCB = circuitBreakerFactory.getPayment();
        try {
            TransactionStatus status = paymentCB.executeSupplier(() -> humoAPI.holdConfirm(transaction.getResponseId()));
            transaction.setStatus(status);
            return transactionRepo.save(transaction);
        } catch (HumoServiceApiException ex) {
            log.error(ex);
            transaction.setError(ex.getMessage());
            transaction.setStatus(FAILED);
            return transactionRepo.save(transaction);
        } catch (Throwable ex) {
            log.error(ex);
            transaction.setError(UNKNOWN_ERROR);
            transaction.setStatus(PENDING);
            return transactionRepo.save(transaction);
        }
    }

    @Override
    public Transaction credit(Transaction transaction, SenderDTO senderDetails) {
        try {
            transaction.setRequestId(generateToken());
            transactionRepo.save(transaction);

            if (transaction.getStatus() == FAILED)
                return transaction;

            CircuitBreaker paymentCB = circuitBreakerFactory.getPayment();

            CardEntity card = cardService.getByEncPan(transaction.getCard());
            String decPan = encryptDecryptService.decrypt(transaction.getCard());

            Soap2CardDTO request = Soap2CardDTO.builder()
                    .sessionId(transaction.getRequestId())
                    .sender(senderDetails)
                    .amount(transaction.getAmount())
                    .mid(transaction.getMerchantId())
                    .tid(transaction.getTerminalId())
                    .centerId(card.getCenterId())
                    .receiverPan(decPan)
                    .expiry(card.getExpiry())
                    .build();

            PaymentDTO result = paymentCB.executeSupplier(
                    () -> humoAPI.credit(request)
            );

            if (result.getStatus() == TransactionStatus.FAILED) {
                transaction.setError(result.getErrorMsg());
                transaction.setResponseMeta(result.getHumoCode());
                transaction.setDetails(result.getErrorMsg());
            }
            transaction.setResponseId(result.getPaymentId());
            transaction.setResponseMeta(result.getHumoCode());
            transaction.setReceiverRRN(result.getSenderRRN());
            transaction.setStatus(result.getStatus());
            cardBalanceService.resetBalance(card.getEncryptedPan());
            return transactionRepo.save(transaction);
        } catch (CallNotPermittedException ex) {
            log.error(ex);
            transaction.setError(MessageKey.SERVICE_DISABLED);
            transaction.setStatus(FAILED);
            return transactionRepo.save(transaction);
        } catch (HumoServiceApiException ex) {
            log.error(ex);
            transaction.setError(ex.getMessage());
            transaction.setStatus(FAILED);
            return transactionRepo.save(transaction);
        } catch (Throwable ex) {
            log.error(ex);
            transaction.setError(UNKNOWN_ERROR);
            transaction.setStatus(PENDING);
            return transactionRepo.save(transaction);
        }
    }

    @Override
    public boolean block(UUID uuid) {
        ThreadLocalSinglton.setFlag(Boolean.TRUE);
        CircuitBreaker cardInfo = circuitBreakerFactory.getCardInfo();
        CardEntity card = cardService.getById(uuid);
        String decPan = encryptDecryptService.decrypt(card.getEncryptedPan());

        Set<IiacsStatusItemDTO> statusesItems = Try.of(() -> cardInfo.executeSupplier(
                        () -> humoAPI.getCardInfo(decPan, 1, TEN)))
                .map(IiacsResponse::getCard)
                .map(IiacsCardResponse::getStatuses)
                .map(IiacsStatusDTO::getItem)
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        String actionCode = statusesItems.stream()
                .filter(item -> Objects.equals("card", item.getType()))
                .findFirst()
                .map(IiacsStatusItemDTO::getActionCode)
                .orElseThrow(HumoServiceApiException::humoNotAvailable);
        log.info(statusesItems);
        if (StringUtils.equals(actionCode, "000")) {
            CircuitBreaker cardsBlockCB = circuitBreakerFactory.getCardsBlock();
            return Try.of(() -> cardsBlockCB.executeSupplier(() -> humoAPI.blockCard(decPan, FIFTEEN)))
                    .onFailure(log::error)
                    .getOrElse(false);
        } else
            return false;
    }

    public boolean status(UUID uuid) {
        ThreadLocalSinglton.setFlag(Boolean.TRUE);
        CircuitBreaker cardInfo = circuitBreakerFactory.getCardInfo();
        CardEntity card = cardService.getById(uuid);
        String decPan = encryptDecryptService.decrypt(card.getEncryptedPan());

        Set<IiacsStatusItemDTO> statusesItems = Try.of(() -> cardInfo.executeSupplier(
                        () -> humoAPI.getCardInfo(decPan, 1, TEN)))
                .map(IiacsResponse::getCard)
                .map(IiacsCardResponse::getStatuses)
                .map(IiacsStatusDTO::getItem)
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        String actionCode = statusesItems.stream()
                .filter(item -> Objects.equals("card", item.getType()))
                .findFirst()
                .map(IiacsStatusItemDTO::getActionCode)
                .orElseThrow(HumoServiceApiException::humoNotAvailable);
        return StringUtils.equals(actionCode, "125");
    }

    @Override
    public CardUnblockResultDTO unblock(UUID uuid) {
        ThreadLocalSinglton.setFlag(Boolean.TRUE);
        CircuitBreaker cardInfo = circuitBreakerFactory.getCardInfo();

        CardEntity cardEntity = cardService.getById(uuid);

        String pan = encryptDecryptService.decrypt(cardEntity.getEncryptedPan());

        Set<IiacsStatusItemDTO> statusesItems = Try.of(() -> cardInfo.executeSupplier(
                        () -> humoAPI.getCardInfo(pan, 1, TEN)))
                .map(IiacsResponse::getCard)
                .map(IiacsCardResponse::getStatuses)
                .map(IiacsStatusDTO::getItem)
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        String actionCode = statusesItems.stream()
                .filter(item -> Objects.equals("card", item.getType()))
                .findFirst()
                .map(IiacsStatusItemDTO::getActionCode)
                .orElseThrow(HumoServiceApiException::humoNotAvailable);
        log.info(statusesItems);
        if (StringUtils.equals(actionCode, "281")) {
            CircuitBreaker cardsUnBlock = circuitBreakerFactory.getCardsUnBlock();
            Boolean isUnblocked = Try.of(() -> cardsUnBlock.executeSupplier(() -> humoAPI.unblockCard(pan, FIFTEEN)))
                    .onFailure(log::error)
                    .getOrElse(false);
            return new CardUnblockResultDTO(cardEntity.getId(), isUnblocked, CARD_IS_UNBLOCKED, ThreadLocalSinglton.getInfo(), ThreadLocalSinglton.getBlockOrUnblock());
        } else {
            return new CardUnblockResultDTO(cardEntity.getId(), false, ACCESS_DENIED_TO_UNBLOCK_CARD);
        }
    }

    @Override
    public boolean resetPin(UUID uuid) {

        CardEntity card = cardService.getByUUID(uuid);
        String code = generateRandomInt();

        Try.run(() -> smsService.sendSms(code, card.getPhone(), SmsProvider.PLAY_MOBILE, true))
                .onFailure(log::error);

        String encCode = encryptDecryptService.encrypt(code);
        card.setVerifyCode(encCode);
        cardService.save(card);

        return true;
    }

    @Override
    public TotalBalanceDTO getTotalBalance(Set<UUID> cards) {
        try {
//            AtomicLong balance = new AtomicLong(0L);
//            cardService.getByUUIDs(cards).stream()
//                    .map(CardEntity::getEncryptedPan)
//                    .map(encryptDecryptService::decrypt)
//                    .forEach(x -> {
//                        CircuitBreaker cardInfoCB = circuitBreakerFactory.getCardInfo();
//                        IiacsResponse resp = Try.of(() -> cardInfoCB.executeSupplier(
//                                () -> humoAPI.getCardInfo(x, 1, TEN))
//                        ).onFailure(log::error).get();
//                        balance.addAndGet(resp.getBalance().getAvailableAmount());
//                    });
//            return TotalBalanceDTO.builder()
//                    .balanceInfos(List.of(new BalanceInfo(balance.get(), Currency.UZS)))
//                    .build();

            Long totalBalance = cardService.getByUUIDs(cards)
                    .stream()
                    .map(CardEntity::getEncryptedPan)
                    .filter(Objects::nonNull)
                    .map(cardBalanceService::findByEncPan)
                    .filter(Optional::isPresent)
                    .map(Optional::get)
                    .map(x -> {
                                long cachePeriod = appProps.getCachePeriod();

                                long cacheTime = requireNonNullElse(x.getBalanceCacheTime(), 0L);
                                long now = System.currentTimeMillis();

                                if ((now - cacheTime) > cachePeriod) {
                                    return getCardByEncPan(x.getEncryptedPan())
                                            .getBalance();
                                } else {
                                    return x.getBalance();
                                }
                            }
                    )
                    .reduce(0L, Long::sum);

            return TotalBalanceDTO.builder()
                    .balanceInfos(List.of(new BalanceInfo(totalBalance, Currency.UZS)))
                    .build();
        } catch (Exception e) {
            log.error(e);
            return TotalBalanceDTO.builder()
                    .balanceInfos(List.of(new BalanceInfo(0L, Currency.UZS)))
                    .build();
        }
    }

    @Override
    public boolean pinVerify(PinVerifyDto verifyDto) {
        CardEntity card = cardService.getByUUID(verifyDto.getId());
        String decCode = encryptDecryptService.decrypt(card.getVerifyCode());

        if (!Objects.equals(verifyDto.getCode(), decCode))
            throw new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);

        CircuitBreaker cardResetPin = circuitBreakerFactory.getCardResetPin();
        String decPan = encryptDecryptService.decrypt(card.getEncryptedPan());
        String expiryDate = card.getExpiry();

        return Try.of(() -> cardResetPin.executeSupplier(() -> humoAPI.cardResetPin(decPan, expiryDate, FIFTEEN)))
                .onFailure(log::error)
                .getOrElse(false);
    }

    @Override
    public CardHistoryInfo getCardHistory(UUID uuid, Long from, Long to) {
        CircuitBreaker cardsHistoryCB = circuitBreakerFactory.getCardsHistory();
        CardEntity card = cardService.getById(uuid);
        String decPan = encryptDecryptService.decrypt(card.getEncryptedPan());

        return Try.of(() -> cardsHistoryCB.executeSupplier(
                        () -> humoAPI.getHistory(decPan, from, to))
                ).onFailure(log::error)
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);
    }


    @Override
    public boolean deactivateCard(UUID cardId) {
        CardEntity card = cardService.getById(cardId);

        CircuitBreaker verifySms = circuitBreakerFactory.getPermissionDeactivate();

        IiacsPermissionDeactRes iiacsPermissionDeactRes = Try.of(() ->
                        verifySms.executeSupplier(() ->
                                humoAPI.permissionDeactivate(encryptDecryptService.decrypt(card.getEncryptedPan()), FIVE)))
                .onFailure(log::error)
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        return StringUtils.equalsIgnoreCase(iiacsPermissionDeactRes.getStatus(), "off");
    }

    @Override
    public Transaction p2p(Transaction transaction) {
        try {
            transaction.setRequestId(generateToken());
            transactionRepo.save(transaction);

            CircuitBreaker paymentCB = circuitBreakerFactory.getPayment();

            CardEntity senderCard = cardService.getByEncPan(transaction.getCard());
            String senderPan = encryptDecryptService.decrypt(transaction.getCard());

            CardEntity receiverCard = cardService.getByEncPan(transaction.getExtraCard());
            String receiverPan = encryptDecryptService.decrypt(transaction.getExtraCard());

            String switchingId;
            String externalSwitchingId = "50";
            String internalSwitchingId = "48";
            if (!startsWith(senderPan, "9") || !startsWith(receiverPan, "9"))
                switchingId = "77";
            else if (Objects.equals(senderCard.getBankC(), receiverCard.getBankC()))
                switchingId = internalSwitchingId;
            else
                switchingId = externalSwitchingId;

            P2PHumoRequest p2pRequest = P2PHumoRequest.builder()
                    .amount(transaction.getAmount())
                    .sPan(senderPan)
                    .sExp(senderCard.getExpiry())
                    .rPan(receiverPan)
                    .mid(transaction.getMerchantId())
                    .tid(transaction.getTerminalId())
                    .paymentRef(transaction.getRequestId())
                    .switchId(switchingId)
                    .build();

            String paymentId = Try.of(() -> paymentCB.executeSupplier(
                            () -> humoAPI.p2pRequest(transaction.getRequestId(), p2pRequest)
                    )).onFailure(log::error)
                    .getOrElse("");

            if (isEmpty(paymentId)) {
                transaction.setStatus(FAILED);
                transaction.setError(MessageKey.DEBIT_ERROR);
                return transactionRepo.save(transaction);
            }

            transaction.setResponseId(paymentId);
            transactionRepo.save(transaction);

            try {
                PaymentDTO result = paymentCB.executeSupplier(() -> humoAPI.p2pFinish(transaction));
                transaction.setSenderRRN(result.getSenderRRN());
                transaction.setReceiverRRN(result.getReceiverRRN());
                transaction.setStatus(result.getStatus());
            } catch (CallNotPermittedException ex) {
                log.error(ex);
                transaction.setError(MessageKey.SERVICE_DISABLED);
                transaction.setStatus(FAILED);
            } catch (HumoPaymentException ex) {
                log.error(ex);
                HumoError humoError = humoErrorRepository.findById(ex.getCode())
                        .orElse(HumoError.pendingState(ex.getCode()));
                transaction.setError(humoError.getMessageKey());
                transaction.setStatus(humoError.getStatus());
            } catch (Exception ex) {
                log.error(ex);
                transaction.setError(ex instanceof ExternalServiceException ? SERVICE_DISABLED : UNKNOWN_ERROR);
                transaction.setStatus(PENDING);
            }

            cardBalanceService.resetBalance(senderCard.getEncryptedPan());
        } catch (Throwable ex) {
            log.error(ex);
            transaction.setError(UNKNOWN_ERROR);
            transaction.setStatus(PENDING);
        }
        return transactionRepo.save(transaction);
    }

    @Override
    public Transaction reverse(Transaction transaction) {
        CircuitBreaker paymentCB = circuitBreakerFactory.getPayment();
        if (transaction.isPending()) {
            TransactionStatus status = checkTransaction(transaction);
            if (status == REVERSED) {
                transaction.setReverseTime(System.currentTimeMillis());
                transaction.setStatus(REVERSED);
            } else if (status == FAILED) {
                transaction.setStatus(FAILED);
            }
            transactionRepo.save(transaction);
        }
        if (transaction.getStatus() == TransactionStatus.FAILED)
            return transaction;

        TransType currentType = transaction.getType();
        try {
            if (isEmpty(transaction.getResponseId())) {
                TransactionDTO result = humoAPI.getTransactionByPaymentRef(transaction.getRequestId(), FIFTEEN);
                transaction.setResponseId(result.getPaymentId());
            }

            if (currentType == DEBIT) {
                if (transaction.getStatus() == HOLD) {
                    TransactionStatus status = paymentCB.executeSupplier(() -> humoAPI.holdCancel(transaction.getResponseId()));
                    transaction.setStatus(status);
                } else if (transaction.getStatus() == SUCCESS) {
                    TransactionStatus status = paymentCB.executeSupplier(
                            () -> humoAPI.holdReturn(transaction.getResponseId(), transaction.getMerchantId(), transaction.getTerminalId()));
                    transaction.setStatus(status);
                }
            } else if (currentType == CREDIT) {
                TransactionStatus status = paymentCB.executeSupplier(() -> humoAPI.creditCancel(transaction.getResponseId()));
                transaction.setStatus(status);
            }
            return transactionRepo.save(transaction);
        } catch (CallNotPermittedException ex) {
            log.error(ex);
            transaction.setStatus(FAILED);
            transaction.setError(MessageKey.SERVICE_DISABLED);
            return transactionRepo.save(transaction);
        } catch (Exception ex) {
            log.error(ex);
            transaction.setStatus(PENDING);
            return transactionRepo.save(transaction);
        }
    }

    @Override
    public TransactionStatus checkTransaction(Transaction transaction) {
        try {
            TransactionDTO result;
            if (isNoneEmpty(transaction.getResponseId()))
                result = humoAPI.getTransactionByPaymentId(transaction.getResponseId(), FIFTEEN);
            else
                result = humoAPI.getTransactionByPaymentRef(transaction.getRequestId(), FIFTEEN);


            return ofNullable(result.getStatus())
                    .map(status -> switch (status) {
                        case "finished" -> SUCCESS;
                        case "returned" -> TransactionStatus.REVERSED;
                        case "active" -> transaction.getType() == CREDIT ?
                                SUCCESS : HOLD;
                        default -> TransactionStatus.FAILED;
                    })
                    .orElse(PENDING);
        } catch (ExternalServiceException ex) {
            return PENDING;
        } catch (HumoServiceApiException ex) {
            return TransactionStatus.FAILED;
        }
    }

    protected OnlineCardInfo getCardbyEncpanV2(String encPan) {
        final String pan = encryptDecryptService.decrypt(encPan);
        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));
        CardBalance cardBalance = cardBalanceService.findByEncPan(encPan).orElse(new CardBalance(encPan));

        var resultBuilder = OnlineCardInfo.builder()
                .isPrivate(requireNonNullElse(card.getIsPrivate(), isPrivate(pan)))
                .holderName(card.getHolderName())
                .expire(card.getExpiry())
                .maskedPan(Utils.panFormat(pan))
                .currency(card.getCurrency())
                .id(card.getId())
                .pan(pan);

        long cachePeriod = appProps.getCachePeriod();

        long cacheTime = requireNonNullElse(cardBalance.getBalanceCacheTime(), 0L);
        long now = System.currentTimeMillis();

        if ((now - cacheTime) > cachePeriod) {
            CircuitBreaker cardInfoCB = circuitBreakerFactory.getCardInfo();
            return card2NewMethod(pan, card, resultBuilder, cardInfoCB);
        }

        return resultBuilder.state(cardBalance.getState())
                .build();
    }

    protected OnlineCardInfo getCardByEncPan(String encPan) {
        String pan = encryptDecryptService.decrypt(encPan);
        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));

        CardBalance cardBalance = cardBalanceService.findByEncPan(encPan).orElse(new CardBalance(encPan));

        var resultBuilder = OnlineCardInfo.builder()
                .isPrivate(requireNonNullElse(card.getIsPrivate(), isPrivate(pan)))
                .holderName(card.getHolderName())
                .expire(card.getExpiry())
                .maskedPan(Utils.panFormat(pan))
                .currency(card.getCurrency())
                .phone(card.getPhone())
                .id(card.getId())
                .pan(pan);

        long cachePeriod = appProps.getCachePeriod();

        long cacheTime = requireNonNullElse(cardBalance.getBalanceCacheTime(), 0L);
        long now = System.currentTimeMillis();

        if ((now - cacheTime) > cachePeriod) {
            CircuitBreaker cardInfoCB = circuitBreakerFactory.getCardInfo();
            if (StringUtils.isBlank(card.getToken()) && !pan.substring(0, 6).equals("986027")) {
                return card2NewMethod(pan, card, resultBuilder, cardInfoCB);
            } else {
                return oldMethod(pan, card, cardBalance, resultBuilder, cardInfoCB);
            }
        }

        return resultBuilder.balance(cardBalance.getBalance())
                .state(cardBalance.getState())
                .build();
    }

    @NotNull
    private OnlineCardInfo card2NewMethod(String pan, CardEntity card, OnlineCardInfo.OnlineCardInfoBuilder resultBuilder, CircuitBreaker cardInfoCB) {
        final IiacsResponseV2 resp = Try.of(() -> cardInfoCB.executeSupplier(
                        () -> humoAPI.getCardInfoV2(pan, 1, TEN))
                )
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        final IiacsCardResponse cardInfo = resp.getCard();

        if (Objects.nonNull(cardInfo.getInstitutionId()))
            card.setCenterId(cardInfo.getInstitutionId());

        resultBuilder
                .holderName(cardInfo.getNameOnCard())
                .expire(cardInfo.getExpiry());

        Currency currency = Currency.UZS;

        resultBuilder
                .currency(currency);

        card.setBankC(cardInfo.getBankC());

        CardState state = getCardState(cardInfo);

        OnlineCardInfo result = resultBuilder.state(state)
                .build();

        CardEntity cardEntity = cardService.updateCardEntity(card, result);

        result.setId(cardEntity.getId());
        return result;
    }

    @NotNull
    private OnlineCardInfo oldMethod(String pan, CardEntity card, CardBalance cardBalance, OnlineCardInfo.OnlineCardInfoBuilder resultBuilder, CircuitBreaker cardInfoCB) {
        IiacsResponse resp = Try.of(() -> cardInfoCB.executeSupplier(
                        () -> humoAPI.getCardInfo(pan, 1, TEN))
                )
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        IiacsCardResponse cardInfo = resp.getCard();

        Currency currency = Currency.getCurrency(resp.getBalance()
                .getCurrency());

        resultBuilder
                .currency(currency);

        if (Objects.nonNull(cardInfo.getInstitutionId()))
            card.setCenterId(cardInfo.getInstitutionId());

        card.setBankC(cardInfo.getBankC());
        resultBuilder
                .holderName(cardInfo.getNameOnCard())
                .expire(cardInfo.getExpiry());

        MbDTO mb = resp.getMb();
        String phone;
        CardState cardState;

        if (Objects.isNull(mb.getState()) && Objects.nonNull(card.getPhone())) {
            phone = card.getPhone();
            cardState = ACTIVE;
        } else if (StringUtils.equalsIgnoreCase(mb.getState(), "on")) {
            phone = ofNullable(mb.getPhone())
                    .or(() -> ofNullable(card.getPhone()))
                    .map(Utils::phoneFormat)
                    .orElseThrow(HumoServiceApiException::humoNotAvailable);
            cardState = ACTIVE;
        } else {
            phone = "";
            cardState = SMS_DISABLED;
        }

        CardState state = getCardState(cardInfo);

        if (state != cardState && state == ACTIVE)
            state = cardState;

        ofNullable(resp.getBalance())
                .map(IiacsBalanceDTO::getAvailableAmount)
                .ifPresent(cardBalance::setBalance);

        cardBalance.setState(cardState);
        cardBalanceService.save(cardBalance);

        OnlineCardInfo result = resultBuilder.state(state)
                .phone(mb.getPhone())
                .balance(cardBalance.getBalance())
                .phone(phoneFormat(phone))
                .build();

        CardEntity cardEntity = cardService.updateCardEntity(card, result);
        result.setId(cardEntity.getId());

        return result;
    }

    private CardState getCardState(IiacsCardResponse cardInfo) {

        HumoCardStatus status = cardInfo.getStatuses()
                .getItem()
                .stream()
                .filter(item -> Objects.equals("card", item.getType()))
                .findFirst()
                .map(IiacsStatusItemDTO::getActionCode)
                .map(HumoCardStatus::getStatus)
                .orElse(HumoCardStatus.NOT_ACTIVE);

        boolean pinBlocked = requireNonNullElse(cardInfo.getPinTryCount(), 0).equals(3);

        return switch (status) {
            case APPROVED -> pinBlocked ? PIN_BLOCK : ACTIVE;
            case NOT_ACTIVE -> NOT_ACTIVE;
            case BLOCKED_BY_USER -> BLOCKED_BY_USER;
            default -> BLOCKED;
        };

    }

    private boolean isPrivate(String pan) {
        if (isEmpty(pan) && pan.length() != 16)
            return false;
        return !StringUtils.equals("02", pan.substring(6, 8));
    }

    @Override
    public void doReco(RecoEpos epos) {
        CircuitBreaker recoBreaker = circuitBreakerFactory.getRecoBreaker();
        Try.of(() -> recoBreaker.executeSupplier(() -> humoAPI.reconciliationCreate(epos.getTerminal())))
                .onFailure(log::error)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .andThenTry(humoAPI::reconciliationAuth)
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        epos.setRecoTime(System.currentTimeMillis());
        recoEposRepository.save(epos);
    }

    @Override
    public boolean assignPin(UUID cardId, String newPin, String terminalId) {
        if (newPin.length() != 4)
            throw new HumoServiceApiException(NEW_PIN_LENGTH_NOT_VALID, BAD_REQUEST);

        CardEntity card = cardService.getByUUID(cardId);
        String decPan = encryptDecryptService.decrypt(card.getEncryptedPan());

        CircuitBreaker circuitBreaker = circuitBreakerFactory.getDeactivateCard();

        Try.run(() -> circuitBreaker.executeSupplier(
                        () -> humoAPI.deactivateCard(decPan, FIVE))
                )
                .onFailure(log::error)
                .getOrElseThrow(() -> new HumoServiceApiException(DEACTIVATE_FAILED, BAD_REQUEST));

        String originatorId = humoProps.getLogin();

        AssignPinResponse assignPinResponse = Try.of(() -> circuitBreaker.executeSupplier(
                        () -> humoAPI.assignPin(decPan, originatorId, card.getExpiry(), tripleDES.encryption(decPan, newPin), terminalId, FIVE)
                )).onFailure(log::error)
                .getOrElse(() -> {
                            circuitBreaker.executeSupplier(() -> humoAPI.activateCard(decPan, FIVE));
                            throw new HumoServiceApiException(ASSIGN_PIN_FAILED, BAD_REQUEST);
                        }
                );

        return assignPinResponse.getApprovalCode() != null;
    }

    @Override
    public PinflMethodDTO cardPinfl(PinflMethodDTO request) {

        CardEntity cardEntity = cardService.getByEncPan(request.getCardId());

        if (Objects.isNull(cardEntity.getPinfl())) {

            request.setPinfl(
                    humoAPI.p2pInfoGetPinfl(HumoP2pGetPinflRequest
                                    .builder()
                                    .params(new HumoP2pGetPinflRequest.Params(encryptDecryptService.decrypt(request.getCardId())))
                                    .build(), TEN)
                            .getPinfl());

            cardEntity.setPinfl(request.getPinfl());
            cardService.save(cardEntity);

        } else {

            request.setPinfl(cardEntity.getPinfl());

        }

        return request;
    }

    /**
     * This method will send to request to humo to get OTP code from HUMO PC
     */
    protected void sendRequestToHumoToAddCard(String pan, String phone) {
        CircuitBreaker sendSms = circuitBreakerFactory.getSendSms();
        Try.of(() ->
                        sendSms.executeSupplier(() -> humoAPI.sendSmsInProd(pan, phone, FIVE)))
                .onFailure(log::error)
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

    }

    protected IiacsSmsVerifyResponseInProd sendRequestToHumoToVerifyAddCard(CardEntity card, CardVerifyDTO cardVerifyDto) {
        CircuitBreaker verifySms = circuitBreakerFactory.getVerifySms();

        return Try.of(() ->
                        verifySms.executeSupplier(() ->
                                humoAPI.verifyCodeInProd(encryptDecryptService.decrypt(card.getEncryptedPan()), cardVerifyDto.getCode(), FIVE)))
                .onFailure(log::error)
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);
    }

    @Override
    public String cardPinflByPan(String pan) {
        return humoAPI.p2pInfoGetPinfl(HumoP2pGetPinflRequest
                        .builder()
                        .params(new HumoP2pGetPinflRequest.Params(pan))
                        .build(), TEN)
                .getPinfl();
    }

    @Override
    public Set<CardListToken> getListOfCardsByPhone(String phone) {
        IiacsCustomerListResponse listOfCardsByPhone = humoAPI.getListOfCardsByPhone(new IiacsCustomerListRequest(Utils.makeGoodFormatForHumo(phone)));
        return listOfCardsByPhone.getCustomer().stream()
                .map(i -> new CardListToken(null, null,
                        i.getBankId(),
                        i.getCustomerId(),
                        i.getCardholderName(),
                        i.getCard().size() >= 1 ? i.getCard().get(0).getExpiry() : null,
                        i.getCard().size() >= 1 ? i.getCard().get(0).getPan() : null))
                .collect(Collectors.toSet());
    }
}
