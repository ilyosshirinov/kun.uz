package com.asgardiateam.ofb.humoservice.humo.dto.history;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MiddleHistoryInfo {

    @JsonProperty("CARD_ACCT")
    private String cardAcct;

    @JsonProperty("ACCOUNT_NO")
    private String accountNo;

    @JsonProperty("CL_ACCT_KEY")
    private String clAcctKey;

    @JsonProperty("CARD")
    private String card;

    @JsonProperty("CLIENT")
    private String client;

    @JsonProperty("EXP_DATE")
    private String expDate;

    @JsonProperty("TRAN_TYPE")
    private String tranType;

    @JsonProperty("TRAN_CCY")
    private String tranCcy;

    @JsonProperty("TRAN_AMT")
    private Long tranAmt;

    @JsonProperty("CCY_EXP")
    private String ccyExp;

    @JsonProperty("TRAN_DATE_TIME")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime tranDateTime;

    @JsonProperty("REC_DATE")
    private LocalDateTime recDate;

    @JsonProperty("POST_DATE")
    private String postDate;

    @JsonProperty("ACCNT_CCY")
    private String accntCcy;

    @JsonProperty("AMOUNT_NET")
    private String amountNet;

    @JsonProperty("ACQREF_NR")
    private String acqrefNr;

    @JsonProperty("APR_CODE")
    private String aprCode;

    @JsonProperty("APR_SCR")
    private String aprScr;

    @JsonProperty("STAN")
    private String stan;

    @JsonProperty("TERM_ID")
    private String termId;

    @JsonProperty("MERCHANT")
    private String merchant;

    @JsonProperty("POINT_CODE")
    private String pointCode;

    @JsonProperty("MCC_CODE")
    private String mccCode;

    @JsonProperty("ABVR_NAME")
    private String abvrName;

    @JsonProperty("CITY")
    private String city;

    @JsonProperty("COUNTRY")
    private String country;

    @JsonProperty("DEAL_DESC")
    private String dealDesc;

    @JsonProperty("COUNTERPARTY")
    private String counterParty;

    @JsonProperty("INTERNAL_NO")
    private String internalNo;

    @JsonProperty("FLD_104")
    private String fld104;

    @JsonProperty("BANK_C")
    private String bankC;

    @JsonProperty("GROUPC")
    private String groupC;

    @JsonProperty("CTIME")
    private String cTime;

    @JsonProperty("TR_CODE")
    private String trCode;

    @JsonProperty("TR_FEE")
    private String trFee;

    @JsonProperty("TR_CODE2")
    private String trCode2;

    @JsonProperty("TR_FEE2")
    private String trFee2;

    @JsonProperty("LOCKING_FLAG")
    private String lockingFlag;

    @JsonProperty("ADD_INFO")
    private String addInfo;

    @JsonProperty("REF_NUMBER")
    private String refNumber;

}
