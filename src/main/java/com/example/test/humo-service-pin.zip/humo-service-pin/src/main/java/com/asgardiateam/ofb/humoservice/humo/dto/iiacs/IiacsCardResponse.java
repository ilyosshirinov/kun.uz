package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsCardResponse {

    private String institutionId;

    private String primaryAccountNumber;

    private String effectiveDate;

    private String updateDate;

    private Integer prefixNumber;

    private String expiry;

    private Integer cardSequenceNumber;

    private String cardholderId;

    private String nameOnCard;

    private String cardholderPassword;

    private String accountRestrictionsFlag;

    private String cardUserId;

    private String additionalInfo;

    private String riskGroup;

    private String riskGroup2;

    private String bankC;

    private Integer pinTryCount;

    private IiacsStatusDTO statuses;

}
