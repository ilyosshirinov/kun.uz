package com.asgardiateam.ofb.humoservice.controller;

import com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData;
import com.asgardiateam.ofb.humoservice.epos.RecoTask;
import com.asgardiateam.ofb.humoservice.epos.dto.RecoEposDTO;
import com.asgardiateam.ofb.humoservice.message.MessageInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.time.LocalDate;

import static com.asgardiateam.ofb.humoservice.common.ApiConstant.*;
import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseData.responseData;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.SUCCESS;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = PROCESSING_V1_API + DASHBOARD + RECO,
        produces = APPLICATION_JSON_VALUE,
        consumes = APPLICATION_JSON_VALUE)
public class RecoController {

    private final RecoTask recoTask;

    @GetMapping
    public ResponseData<?> getAll() {
        return responseData(recoTask.getAllRecoEpos());
    }

    @PostMapping("/{recoEposId}")
    public ResponseData<?> doRecoForOne(@PathVariable Long recoEposId) {
        recoTask.doRecoForOne(recoEposId);
        return responseData(new MessageInfo(SUCCESS));
    }

    @PostMapping
    public ResponseData<?> doRecoAll() {
        recoTask.reco();
        return responseData(new MessageInfo(SUCCESS));
    }

    @PutMapping()
    public ResponseData<?> createReco(@RequestBody RecoEposDTO request){
        return responseData(
                recoTask.addNewReco(request));
    }
}
