package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.message.MessageKey;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardBlockDTO {

    @NotNull(message = MessageKey.UUID_NOT_VALID)
    private UUID id;

}
