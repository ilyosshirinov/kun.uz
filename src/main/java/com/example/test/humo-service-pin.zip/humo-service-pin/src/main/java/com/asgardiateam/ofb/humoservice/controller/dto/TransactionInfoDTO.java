package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionInfoDTO extends BaseTransactionInfoDTO {

    private String card;

}
