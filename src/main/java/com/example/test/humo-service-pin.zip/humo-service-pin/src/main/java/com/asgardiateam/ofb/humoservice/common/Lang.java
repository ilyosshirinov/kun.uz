package com.asgardiateam.ofb.humoservice.common;

import java.util.Arrays;
import java.util.Objects;

public enum Lang {

    UZ("UZ"),
    RU("RU"),
    EN("EN"),
    UZK("UZK"),
    TJ("TJ"),
    KAR("KAR");

    private final String value;

    Lang(String value) {
        this.value = value;
    }

    public static Lang findLangByValue(String value) {
        return Arrays.stream(Lang.values())
                .filter(lang -> Objects.equals(lang.name(), value))
                .findFirst()
                .orElse(UZ);
    }
}
