package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType;
import com.asgardiateam.ofb.humoservice.controller.dto.HumoP2pGetPinflRequest;
import com.asgardiateam.ofb.humoservice.controller.dto.HumoP2pGetPinflResponse;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.*;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.P2PHumoRequest;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.PaymentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.Soap2CardDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.TransactionDTO;
import com.asgardiateam.ofb.humoservice.transaction.Transaction;
import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;

import java.util.Optional;

public interface HumoAPI {

    IiacsSmsSendResponse sendSms(String pan, String phone, RestTemplateType type);

    IiacsSmsVerifyResponse verifyCode(String pan, String code, RestTemplateType type);

    IiacsPermissionDeactRes permissionDeactivate(String pan, RestTemplateType type);

    IiacsResponse getCardInfo(String pan, int mbFlag, RestTemplateType type);

    IiacsResponseV2 getCardInfoV2(String pan, int mbFlag, RestTemplateType type);

    MaskedPanDTO getMaskedPanDTO(String pan, RestTemplateType type);

    TransactionDTO getTransactionByPaymentRef(String paymentRef, RestTemplateType type);

    TransactionDTO getTransactionByPaymentId(String paymentId, RestTemplateType type);

    boolean blockCard(String pan, RestTemplateType type);

    boolean unblockCard(String pan, RestTemplateType type);

    boolean cardResetPin(String pan, String expiryDate, RestTemplateType type);

    PaymentDTO holdCreate(String sessionId, String pan, String expiry, Long amount, String mid, String tid);

    TransactionStatus holdCancel(String paymentId);

    TransactionStatus holdReturn(String paymentId, String mid, String tid);

    TransactionStatus creditCancel(String paymentId);

    TransactionStatus holdConfirm(String paymentId);

    PaymentDTO credit(Soap2CardDTO request);

    String p2pRequest(String sessionId, P2PHumoRequest request);

    PaymentDTO p2pFinish(Transaction transaction);

    CardHistoryInfo getHistory(String pan, Long from, Long to);

    Optional<String> reconciliationCreate(String terminalId);

    void reconciliationAuth(String paymentId);

    boolean deactivateCard(String pan, RestTemplateType type);

    boolean activateCard(String pan, RestTemplateType type);

    AssignPinResponse assignPin(String pan, String originatorId, String expiry, String encryptedPin, String terminalId, RestTemplateType type);

    abstract HumoP2pGetPinflResponse p2pInfoGetPinfl(HumoP2pGetPinflRequest request, RestTemplateType type);

    IiacsSmsSendResponseInProd sendSmsInProd(String pan, String phone, RestTemplateType type);

    IiacsSmsVerifyResponseInProd verifyCodeInProd(String pan, String code, RestTemplateType type);

    IiacsCustomerListResponse getListOfCardsByPhone(IiacsCustomerListRequest request);
}
