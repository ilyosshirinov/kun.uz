package com.asgardiateam.ofb.humoservice.exception;

import com.asgardiateam.ofb.humoservice.common.responsedata.ResponseCode;
import lombok.Getter;

import static com.asgardiateam.ofb.humoservice.common.responsedata.ResponseCode.ACCESS_DENIED;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.ACCESS_DENIED_TO_BLOCK_CARD;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.ACCESS_DENIED_TO_UNBLOCK_CARD;

@Getter
public class BadRequestAlertException extends RuntimeException {

    private final ResponseCode code;

    public BadRequestAlertException(String message, ResponseCode code) {
        super(message);
        this.code = code;
    }

    public static BadRequestAlertException badRequestAlertException(String key, ResponseCode code) {
        return new BadRequestAlertException(key, code);
    }

    public static BadRequestAlertException accessDeniedToUnblockCard() {
        return badRequestAlertException(ACCESS_DENIED_TO_UNBLOCK_CARD, ACCESS_DENIED);
    }

    public static BadRequestAlertException accessDeniedToBlockCard() {
        return badRequestAlertException(ACCESS_DENIED_TO_BLOCK_CARD, ACCESS_DENIED);
    }

}