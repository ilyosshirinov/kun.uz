package com.asgardiateam.ofb.humoservice.config;

public class ThreadLocalSinglton {

    private ThreadLocalSinglton(){

    }
    private static ThreadLocal<String> INFO = ThreadLocal.withInitial(() -> "");

    private static ThreadLocal<String> BLOCKORUNBLOCK = ThreadLocal.withInitial(() -> "");

    private static ThreadLocal<Boolean> FLAG = ThreadLocal.withInitial(()-> Boolean.FALSE);

    public static String getInfo() {
        return ThreadLocalSinglton.INFO.get();
    }

    public static void setInfo(String response) {
        ThreadLocalSinglton.INFO.set(response);
    }

    public static String getBlockOrUnblock(){
        return ThreadLocalSinglton.BLOCKORUNBLOCK.get();
    }

    public static void setBlocOrUnblock(String response){
        ThreadLocalSinglton.BLOCKORUNBLOCK.set(response);
    }

    public static Boolean getFlag(){
        return ThreadLocalSinglton.FLAG.get();
    }

    public static void setFlag(Boolean flag){
        ThreadLocalSinglton.FLAG.set(flag);
    }

    public static void remove() {
        ThreadLocalSinglton.INFO.remove();
        ThreadLocalSinglton.BLOCKORUNBLOCK.remove();
        ThreadLocalSinglton.FLAG.remove();
    }

}
