package com.asgardiateam.ofb.humoservice.humo.dto.info;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonTypeName("mb_agreement")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MbAgreementDTO {

    private String code;

    private String description;

    private String state;

    private String phone;

    @JsonAlias({"error", "erro_message"})
    private String error;

}
