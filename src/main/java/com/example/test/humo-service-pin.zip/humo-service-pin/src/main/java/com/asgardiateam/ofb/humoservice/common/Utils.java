package com.asgardiateam.ofb.humoservice.common;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.regex.Pattern;

import static org.apache.commons.lang3.StringUtils.substring;

public final class Utils {

    private Utils() {
    }

    public static String generateToken() {
        return UUID.randomUUID().toString();
    }

    public static String panFormat(String pan) {
        Pattern cardPanPattern = Pattern.compile("^[0-9]{16}$");
        if (cardPanPattern.matcher(pan).matches()) {
            return new StringBuilder(pan).replace(6, 12, "******").toString();
        }
        return pan;
    }

    public static String phoneFormat(String phone) {
        if (StringUtils.isEmpty(phone))
            return phone;
        if (phone.startsWith("+")) {
            phone = phone.substring(1);
        }
        if (phone.length() == 12) {
            if (phone.startsWith("998")) return phone;
            if (phone.startsWith("000")) return phone.replaceFirst("000", "998");
        }
        if (phone.length() == 9) return "998" + phone;
        return "";
    }

    public static String makeGoodFormatForHumo(String phone){
        if (phone.length() == 12) {
            return phone.startsWith("+") ? phone : "+" + phone;
        } else if (phone.length() == 9) {
            return "+998" + phone;
        } else if (phone.length() == 10 && phone.startsWith("98")) {
            return "+998" + phone.substring(2);
        }
        return "";
    }

    public static <T> void setIfNonNull(T t, Consumer<T> setMethod) {
        Optional.ofNullable(t).ifPresent(setMethod);
    }

    public static boolean isPanValid(String pan) {
        switch (pan.substring(0, 4)) {
            case "9860":
            case "4073":
            case "5555":
                return true;
            default:
                return false;
        }
    }
    public static String makePhoneFormatForHumo(String phone){
        if(phone.length() == 12)
            return "+" + phone;
        return phone;
    }

    public static String reverseExpiry(String date) {
        return String.valueOf(new char[]{date.charAt(2), date.charAt(3), date.charAt(0), date.charAt(1)});
    }

    public static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factory.newDocumentBuilder();
            return builder.parse(new InputSource(new StringReader(xmlStr)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean isCoobage(String pan) {
        var coobagePrefix = Set.of("6262", "5614", "5440", "4073", "5555");
        return coobagePrefix.contains(substring(pan, 0, 4));
    }

    public static String generateRandomInt() {
        Random random = new Random();
        int num = random.nextInt(100000);
        return String.format("%06d", num);
    }

}
