package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class IiacsAccountItem {

    private String institutionId;

    private String accountId;

    private String bankAccountId;

    private String currency;

    private String cardholderId;

    private String effectiveDate;

    private String updateDate;

    private String accountType;

    private Long initialAmount;

    private Long lockedBackofficeAmount;

    private String lockTime;

    private Long lockedAmount;

    private Long shadowAmount;

    private Integer priority;

    private String status;

    private Long availableAmount;

}
