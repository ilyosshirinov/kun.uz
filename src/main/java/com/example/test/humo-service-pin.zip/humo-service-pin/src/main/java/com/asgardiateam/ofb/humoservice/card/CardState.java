package com.asgardiateam.ofb.humoservice.card;

public enum CardState {

    ACTIVE,
    SMS_DISABLED,
    BLOCKED,
    BLOCKED_BY_USER,
    NOT_ACTIVE,
    PIN_BLOCK,
}
