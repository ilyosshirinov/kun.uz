package com.asgardiateam.ofb.humoservice.humo.dto.info;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CardInfoRequest {

    private String card;

    private String expiry;

}
