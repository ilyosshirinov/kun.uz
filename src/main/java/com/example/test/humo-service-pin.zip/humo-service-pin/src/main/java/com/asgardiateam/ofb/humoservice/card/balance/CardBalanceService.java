package com.asgardiateam.ofb.humoservice.card.balance;

import com.asgardiateam.ofb.humoservice.common.CrudService;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;

import java.util.Optional;

public interface CardBalanceService extends CrudService<CardBalance, OnlineCardInfo, String> {

    void resetBalance(String encPan);

    Optional<CardBalance> findByEncPan(String encPan);

}
