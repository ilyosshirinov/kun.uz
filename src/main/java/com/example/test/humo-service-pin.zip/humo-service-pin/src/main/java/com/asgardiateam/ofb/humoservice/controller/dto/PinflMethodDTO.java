package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Setter
@Getter
@ToString
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PinflMethodDTO {
    private String cardId;
    private String paymentId;

    private String pinfl;

    public PinflMethodDTO(String cardId, String paymentId) {
        this.cardId = cardId;
        this.paymentId = paymentId;
    }
    public PinflMethodDTO(String cardId) {
        this.cardId = cardId;
    }
}

