package com.asgardiateam.ofb.humoservice.humopay;

import com.asgardiateam.ofb.humoservice.controller.dto.SendNotificationDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.ProcessingPanDTO;

import java.util.UUID;

public interface HumoPayService {

    void sendPushNotification(SendNotificationDTO sendNotificationDTO);

    ProcessingPanDTO getProcessingPan(UUID id);
}
