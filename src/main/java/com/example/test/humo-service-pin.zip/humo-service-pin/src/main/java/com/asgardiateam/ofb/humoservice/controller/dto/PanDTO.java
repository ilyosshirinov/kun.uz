package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.PAN_NOT_VALID;

@Getter
@Setter
public class PanDTO {

    @NotBlank(message = PAN_NOT_VALID)
    private String pan;

}
