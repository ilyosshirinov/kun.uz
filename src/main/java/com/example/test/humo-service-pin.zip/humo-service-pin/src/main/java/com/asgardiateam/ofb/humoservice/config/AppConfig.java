package com.asgardiateam.ofb.humoservice.config;

import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableAsync;


@Configuration
@EnableCaching
@ConfigurationPropertiesScan
@EnableAsync(proxyTargetClass = true)
@EnableJpaAuditing(auditorAwareRef = "auditingAwareBean")
public class AppConfig {
}
