package com.asgardiateam.ofb.humoservice.common.resttemplatewrapper;

public enum RestTemplateType {
    FIVE, TEN, FIFTEEN, THIRTY, FORTY
}
