package com.asgardiateam.ofb.humoservice.exception;

import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsBaseErrorResponse;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static com.asgardiateam.ofb.humoservice.exception.ExceptionConstant.*;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.HUMO_NOT_AVAILABLE;

@Getter
public class ExternalServiceException extends RuntimeException {

    private final Integer code;
    private final String body;
    private final IiacsBaseErrorResponse bodyInObject;
    private final HttpStatus httpStatus;

    public ExternalServiceException(String message, Integer code, HttpStatus httpStatus, String body, IiacsBaseErrorResponse bodyInObject) {
        super(message);
        this.body = body;
        this.code = code;
        this.bodyInObject = bodyInObject;
        this.httpStatus = httpStatus;
    }

    public static void reThrow(ExternalServiceException ex) {
        throw ex;
    }
    public static ExternalServiceException resourceAccessException(String message, String body) {
        return new ExternalServiceException(message, RESOURCE_ACCESS_CODE, null, body, null);
    }

    public static ExternalServiceException serverErrorException(String message, HttpStatus httpStatus, String body) {
        return new ExternalServiceException(message, SERVER_ERROR_CODE, httpStatus, body, null);
    }

    public static ExternalServiceException clientErrorException(String message, HttpStatus httpStatus, String body, IiacsBaseErrorResponse bodyInObject) {
        return new ExternalServiceException(message, CLIENT_ERROR_CODE, httpStatus, body, bodyInObject);
    }

    public static ExternalServiceException unknownErrorException(String message, String body) {
        return new ExternalServiceException(message, UNKNOWN_ERROR_CODE, null, body, null);
    }

    public static ExternalServiceException unknownErrorException() {
        return new ExternalServiceException(HUMO_NOT_AVAILABLE, UNKNOWN_ERROR_CODE, null, null, null);
    }
}
