package com.asgardiateam.ofb.humoservice.humo.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EposInfo {

    private String mid;

    private String tid;

}
