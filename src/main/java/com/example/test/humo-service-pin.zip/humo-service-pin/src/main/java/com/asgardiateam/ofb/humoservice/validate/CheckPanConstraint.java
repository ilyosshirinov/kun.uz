package com.asgardiateam.ofb.humoservice.validate;

import com.asgardiateam.encryptservice.encrypt.EncryptDecryptService;
import com.asgardiateam.ofb.humoservice.common.Utils;
import lombok.RequiredArgsConstructor;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Optional;

@RequiredArgsConstructor
public class CheckPanConstraint implements ConstraintValidator<CheckPan, String> {

    private final EncryptDecryptService encryptDecryptService;

    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        return Optional.ofNullable(s)
                .map(encryptDecryptService::decrypt)
                .map(Utils::isPanValid)
                .orElse(false);
    }

}
