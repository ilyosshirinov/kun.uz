package com.asgardiateam.ofb.humoservice.humo.dto.payment;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDTO {

    private String paymentId;

    private String paymentRef;

    private String status;

}
