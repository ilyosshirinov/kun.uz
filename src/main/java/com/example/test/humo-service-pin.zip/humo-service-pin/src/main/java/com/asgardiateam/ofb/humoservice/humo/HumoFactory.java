package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.humo.dto.DocumentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.P2PHumoRequest;
import com.asgardiateam.ofb.humoservice.humo.dto.payment.Soap2CardDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.isNumeric;

@Component
@RequiredArgsConstructor
public class HumoFactory {

    private final HumoProps humoProps;

    private static final String GROUPC = "01";
    private static final String APP_NAME = "OFB";

    private static final String ADD_CARD_TO_STOP = """
                <soapenv:Envelope
                	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
                	<soapenv:Body>
                		<addCardToStop>
                			<ConnectionInfo>
                				<BANK_C>%s</BANK_C>
                				<GROUPC>%s</GROUPC>
                				<EXTERNAL_SESSION_ID xsi:type="xsd:string">%s</EXTERNAL_SESSION_ID>
                			</ConnectionInfo>
                			<Parameters>
                				<CARD>%s</CARD>
                				<STOP_CAUSE>B</STOP_CAUSE>
                				<TEXT>OFB</TEXT>
                				<BANK_C>%s</BANK_C>
                				<GROUPC>%s</GROUPC>
                			</Parameters>
                		</addCardToStop>
                	</soapenv:Body>
                </soapenv:Envelope>
            """;

    private static final String REMOVE_CARD_FROM_STOP = """
            <soapenv:Envelope
            	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
            	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            	<soapenv:Body>
            		<removeCardFromStop>
            			<ConnectionInfo>
            				<BANK_C>%s</BANK_C>
            				<GROUPC>%s</GROUPC>
            				<EXTERNAL_SESSION_ID xsi:type="xsd:string">%s</EXTERNAL_SESSION_ID>
            			</ConnectionInfo>
            			<Parameters>
            				<CARD>%s</CARD>
            				<TEXT>OFB</TEXT>
            				<BANK_C>%s</BANK_C>
            				<GROUPC>%s</GROUPC>
            			</Parameters>
            		</removeCardFromStop>
            	</soapenv:Body>
            </soapenv:Envelope>
            """;

    private static final String CARD_RESET_PIN = """
            <soapenv:Envelope
            	xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
            	xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'
            	xmlns:xsd='http://www.w3.org/2001/XMLSchema'>
            	<soapenv:Body>
            		<resetPINCounter>
            			<ConnectionInfo>
            				<BANK_C>%s</BANK_C>
            				<GROUPC>%s</GROUPC>
            				<EXTERNAL_SESSION_ID xsi:type="xsd:string">%s</EXTERNAL_SESSION_ID>
            			</ConnectionInfo>
            			<Parameters>
            				<CARD>%s</CARD>
            				<EXPIRY>%s</EXPIRY>
            				<TEXT>OFB APP</TEXT>
            				<OFFLINE>1</OFFLINE>
            			</Parameters>
            		</resetPINCounter>
            	</soapenv:Body>
            </soapenv:Envelope>
            """;

    private static final String DEACTIVATE_CARD = """
            <soapenv:Envelope
            	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            	xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
            	xmlns:bin="urn:IssuingWS/binding">
            	<soapenv:Header/>
            	<soapenv:Body>
            		<deactivateCard>
            			<ConnectionInfo>
            				<BANK_C>%s</BANK_C>
            				<GROUPC>%s</GROUPC>
            				<EXTERNAL_SESSION_ID>xsi:type=xsd:string>%s</EXTERNAL_SESSION_ID>
            			</ConnectionInfo>
            			<Parameters>
            				<CARD>%s</CARD>
            			</Parameters>
            		</deactivateCard>
            	</soapenv:Body>
            </soapenv:Envelope>
            """;

    private static final String ACTIVATE_CARD = """
            <?xml version="1.0" encoding="UTF-8"?>
            <soapenv:Envelope
              xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
              xmlns:xsd="http://www.w3.org/2001/XMLSchema"
              xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
              <soapenv:Body>
                <activateCard>
                  <ConnectionInfo>
                    <BANK_C>%s</BANK_C>
                    <GROUPC>%s</GROUPC>
                    <EXTERNAL_SESSION_ID>%s</EXTERNAL_SESSION_ID>
                  </ConnectionInfo>
                  <Parameters>
                    <CARD>%s</CARD>
                    <BANK_C>%s</BANK_C>
                    <GROUPC>%s</GROUPC>
                  </Parameters>
                </activateCard>
              </soapenv:Body>
            </soapenv:Envelope>""";

    private static final String ASSIGN_PIN = """
            <SOAP-ENV:Envelope
            	xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
            	xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"
            	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            	xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            	xmlns:cs="urn:CardServices">
            	<SOAP-ENV:Body>
            		<cs:assignPin>
            			<primaryAccountNumber>%s</primaryAccountNumber>
            			<originatorId>OFB</originatorId>
            			<expirationDate>%s</expirationDate>
            			<encryptedPin>%s</encryptedPin>
            			<terminalId>%s</terminalId>
            		</cs:assignPin>
            	</SOAP-ENV:Body>
            </SOAP-ENV:Envelope>
            """;
    private static final String HOLD_CREATE = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\"> " +
            "   <SOAP-ENV:Body> " +
            "      <ebppif1:Payment> " +
            "         <billerRef>SOAP_DMS</billerRef> " +
            "         <payinstrRef>SOAP_DMS</payinstrRef> " +
            "         <sessionID>%s</sessionID> " +
            "         <paymentRef>%s</paymentRef> " +
            "         <details> " +
            "            <item> " +
            "               <name>pan</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>expiry</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>ccy_code</name> " +
            "               <value>860</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>amount</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>merchant_id</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>terminal_id</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>point_code</name> " +
            "               <value>%s</value> " +
            "            </item> " +
            "            <item> " +
            "               <name>centre_id</name> " +
            "               <value>OFB</value> " +
            "            </item> " +
            "         </details> " +
            "         <paymentOriginator>%s</paymentOriginator> " +
            "      </ebppif1:Payment> " +
            "   </SOAP-ENV:Body> " +
            "</SOAP-ENV:Envelope>";

    private static final String HOLD_CONFIRM = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\"> " +
            "\t<SOAP-ENV:Body> " +
            "\t\t<ebppif1:Payment> " +
            "\t\t\t<paymentID>%s</paymentID> " +
            "\t\t\t<confirmed>true</confirmed> " +
            "\t\t\t<finished>true</finished> " +
            "\t\t\t<paymentOriginator>%s</paymentOriginator> " +
            "\t\t</ebppif1:Payment> " +
            "\t</SOAP-ENV:Body> " +
            "</SOAP-ENV:Envelope>";

    private static final String HOLD_CANCEL = "<soapenv:Envelope " +
            "\txmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "\txmlns:urn=\"urn:PaymentServer\"> " +
            "\t<soapenv:Header/> " +
            "\t<soapenv:Body> " +
            "\t\t<urn:CancelRequest> " +
            "\t\t\t<paymentID>%s</paymentID> " +
            "\t\t\t<paymentOriginator>%s</paymentOriginator> " +
            "\t\t</urn:CancelRequest> " +
            "\t</soapenv:Body> " +
            "</soapenv:Envelope>";

    private static final String HOLD_RETURN = "<soapenv:Envelope " +
            "\txmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "\txmlns:urn=\"urn:PaymentServer\"> " +
            "\t<soapenv:Header/> " +
            "\t<soapenv:Body> " +
            "\t\t<urn:ReturnPayment> " +
            "\t\t\t<paymentID>%s</paymentID> " +
            "\t\t\t<item> " +
            "\t\t\t\t<name>merchant_id</name> " +
            "\t\t\t\t<value>%s</value> " +
            "\t\t\t</item> " +
            "\t\t\t<item> " +
            "\t\t\t\t<name>centre_id</name> " +
            "\t\t\t\t<value>OFB</value> " +
            "\t\t\t</item> " +
            "\t\t\t<item> " +
            "\t\t\t\t<name>terminal_id</name> " +
            "\t\t\t\t<value>%s</value> " +
            "\t\t\t</item> " +
            "\t\t\t<paymentOriginator>%s</paymentOriginator> " +
            "\t\t</urn:ReturnPayment> " +
            "\t</soapenv:Body> " +
            "</soapenv:Envelope>";

    public String getSoap2Card(Soap2CardDTO request) {
        String query = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAPENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
                "   <SOAP-ENV:Body>\n" +
                "      <ebppif1:Payment>\n" +
                "         <billerRef>SOAP_TOCARD_2</billerRef>\n" +
                "         <payinstrRef>SOAP_TOCARD_2</payinstrRef>\n" +
                "         <sessionID>" + request.getSessionId() + "</sessionID>\n" +
                "         <paymentRef>" + request.getSessionId() + "</paymentRef>\n" +
                "         <details>\n" +
                "            <item>\n" +
                "               <name>pan2</name>\n" +
                "               <value>" + request.getReceiverPan() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>expiry</name>\n" +
                "               <value>" + request.getExpiry() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>ccy_code</name>\n" +
                "               <value>860</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>amount</name>\n" +
                "               <value>" + request.getAmount() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>merchant_id</name>\n" +
                "               <value>" + request.getMid() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>terminal_id</name>\n" +
                "               <value>" + request.getTid() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>point_code</name>\n" +
                "               <value>" + humoProps.getPointCode() + "</value>\n" +
                "            </item>\n" +
                "            <item>\n" +
                "               <name>centre_id</name>\n" +
                "               <value>" + request.getCenterId() + "</value>\n" +
                "            </item>\n";

        SenderDTO sender = request.getSender();
        if (nonNull(sender) && nonNull(sender.getDoc()))
        {
            if(nonNull(sender.getDoc().getSeriesNumber()))
            {
                DocumentDTO doc = sender.getDoc();
                String seriesNumber = doc.getSeriesNumber();

                String serialNo = "", serialNumber = "";
                Pattern pattern = Pattern.compile("^([A-Za-z]+)(\\d+)");
                Matcher matcher = pattern.matcher(isNumeric(seriesNumber) ? "AA" + seriesNumber : seriesNumber);

                while (matcher.find()) {
                    serialNo = matcher.group(1);
                    serialNumber = matcher.group(2);
                }

                String senderDetails = "<item>\n" +
                        "<name>sender_serial_no</name>\n" +
                        "<value>" + serialNo + "</value>\n" +
                        "</item>\n" +
                        " <item>\n" +
                        "<name>sender_id_card</name>\n" +
                        "<value>" + serialNumber + "</value>\n" +
                        "</item>\n" +
                        "<item>\n" +
                        "<name>sender_surname</name>\n" +
                        "<value>" + sender.getLastName() + "</value>\n" +
                        "</item>\n" +
                        "<item>\n" +
                        "<name>sender_first_name</name>\n" +
                        "<value>" + sender.getFirstName() + "</value>\n" +
                        "</item>\n";

                query += senderDetails;
            }

            if((nonNull(sender.getDoc().getPinfl()))){
                String senderPinfl = "<item>\n" +
                        "<name>sender_person_code</name>\n" +
                        "<value>" + sender.getDoc().getPinfl()  + "</value>\n" +
                        "</item>\n";
                query += senderPinfl;
            }
            if(nonNull(sender.getPan())){
                String senderPan = "<item>\n" +
                        "<name>sender_pan</name>\n" +
                        "<value>" + sender.getPan()  + "</value>\n" +
                        "</item>\n";
                query += senderPan;
            }
            if(nonNull(sender.getRetrievalRefNumber())){
                String senderRetrievalRefNumber = "<item>\n" +
                        "<name>sender_retrieval_ref_number</name>\n" +
                        "<value>" + sender.getRetrievalRefNumber()  + "</value>\n" +
                        "</item>\n";
                query += senderRetrievalRefNumber;
            }

        }



        String end = "         </details>\n" +
                "         <paymentOriginator>" + humoProps.getLogin() + "</paymentOriginator>\n" +
                "      </ebppif1:Payment>\n" +
                "   </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";

        return query + end;
    }

    private static final String PAYMENT_BY_REF_NUM = "<SOAP-ENV:Envelope " +
            "  xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "  xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" " +
            "  xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
            "  xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" " +
            "  xmlns:ebppif1=\"urn:PaymentServer\"> " +
            "  <SOAP-ENV:Body> " +
            "    <ebppif1:GetPayment> " +
            "      <paymentID/> " +
            "      <paymentRef>%s</paymentRef> " +
            "      <paymentOriginator>%s</paymentOriginator> " +
            "    </ebppif1:GetPayment> " +
            "  </SOAP-ENV:Body> " +
            "</SOAP-ENV:Envelope>";

    private static final String CHECK_PAYMENT = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\"> " +
            "   <SOAP-ENV:Body> " +
            "      <ebppif1:GetPayment> " +
            "         <paymentID>%s</paymentID> " +
            "         <paymentOriginator>%s</paymentOriginator> " +
            "      </ebppif1:GetPayment> " +
            "   </SOAP-ENV:Body> " +
            "</SOAP-ENV:Envelope>";

    private static final String CREDIT_CANCEL = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:PaymentServer\"> " +
            "   <soapenv:Header/> " +
            "   <soapenv:Body> " +
            "      <urn:CancelRequest> " +
            "         <sessionID>%s</sessionID> " +
            "         <paymentID>%s</paymentID> " +
            "         <paymentOriginator>%s</paymentOriginator> " +
            "      </urn:CancelRequest> " +
            "   </soapenv:Body> " +
            "</soapenv:Envelope>";

    private static final String RECONCILIATION = """
            <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:ebppif1="urn:PaymentServer">
                <SOAP-ENV:Body>
                    <ebppif1:Payment>
                        <billerRef>SOAP_RECO</billerRef>
                        <payinstrRef>SOAP_RECO</payinstrRef>
                        <details>
                            <item>
                                <name>terminal_id</name>
                                <value>%s</value>
                            </item>
                        </details>
                        <paymentOriginator>%s</paymentOriginator>
                    </ebppif1:Payment>
                </SOAP-ENV:Body>
            </SOAP-ENV:Envelope>
            """;

    private static final String RECONCILIATION_AUTH = """
            <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"\s
            xmlns:ebppif1="urn:PaymentServer">
                <SOAP-ENV:Header/>
                <SOAP-ENV:Body>
                    <ebppif1:Payment>
                        <payinstrRef>SOAP_RECO</payinstrRef>
                        <paymentID>%s</paymentID>
                        <confirmed>true</confirmed>
                        <finished>true</finished>
                        <paymentOriginator>%s</paymentOriginator>
                    </ebppif1:Payment>
                </SOAP-ENV:Body>
            </SOAP-ENV:Envelope>
            """;

    private static final String EBPP_REQUEST_P2P = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
            "   <SOAP-ENV:Body>\n" +
            "      <ebppif1:Request SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\n" +
            "         <language>en</language>\n" +
            "         <switchingID>\n" +
            "            <value>%s</value>\n" +
            "         </switchingID>\n" +
            "         <paymentRef>%s</paymentRef>\n" +
            "         <autoSwitch>1</autoSwitch>\n" +
            "         <details>\n" +
            "            <item>\n" +
            "               <name>pan</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>expiry</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>pan2</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>amount</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>ccy_code</name>\n" +
            "               <value>860</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>merchant_id</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "            <item>\n" +
            "               <name>terminal_id</name>\n" +
            "               <value>%s</value>\n" +
            "            </item>\n" +
            "         </details>\n" +
            "         <paymentOriginator>%s</paymentOriginator>\n" +
            "      </ebppif1:Request>\n" +
            "   </SOAP-ENV:Body>\n" +
            "</SOAP-ENV:Envelope>";

    private static final String EBPP_PAYMENT_P2P = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ebppif1=\"urn:PaymentServer\">\n" +
            "   <SOAP-ENV:Body>\n" +
            "      <ebppif1:Payment>\n" +
            "         <paymentID>%s</paymentID>\n" +
            "         <confirmed>true</confirmed>\n" +
            "         <finished>true</finished>\n" +
            "         <paymentOriginator>%s</paymentOriginator>\n" +
            "      </ebppif1:Payment>\n" +
            "   </SOAP-ENV:Body>\n" +
            "</SOAP-ENV:Envelope>";


    String getCheckPayment(String paymentId) {
        return String.format(CHECK_PAYMENT, paymentId, humoProps.getLogin());
    }

    String getPaymentByRefNum(String refNum) {
        return String.format(PAYMENT_BY_REF_NUM, refNum, humoProps.getLogin());
    }

    String creditCancel(String sessionId, String paymentID) {
        return String.format(CREDIT_CANCEL, sessionId, paymentID, humoProps.getLogin());
    }

    String getHoldCreate(String sessionId, String pan, String exp, String amount, String merchantId, String terminalId) {
        return String.format(HOLD_CREATE, sessionId, sessionId, pan, exp, amount, merchantId, terminalId, humoProps.getPointCode(), humoProps.getLogin());
    }

    String getHoldConfirm(String paymentId) {
        return String.format(HOLD_CONFIRM, paymentId, humoProps.getLogin());
    }

    String getHoldCancel(String paymentId) {
        return String.format(HOLD_CANCEL, paymentId, humoProps.getLogin());
    }

    String getHoldReturn(String paymentId, String merchantId, String terminalId) {
        return String.format(HOLD_RETURN, paymentId, merchantId, terminalId, humoProps.getLogin());
    }

    String getAddCardToStop(String pan) {
        String BANKC = pan.substring(4, 6);
        return String.format(ADD_CARD_TO_STOP, BANKC, GROUPC, generateExternalId(), pan, BANKC, GROUPC);
    }

    String getRemoveCardFromStop(String pan) {
        String BANKC = pan.substring(4, 6);
        return String.format(REMOVE_CARD_FROM_STOP, BANKC, GROUPC, generateExternalId(), pan, BANKC, GROUPC);
    }

    String getResetPin(String pan, String expiryDate) {
        String BANKC = pan.substring(4, 6);
        return String.format(CARD_RESET_PIN, BANKC, GROUPC, generateExternalId(), pan, expiryDate);
    }

    String deactivateCard(String pan) {
        String BANKC = pan.substring(4, 6);
        return String.format(DEACTIVATE_CARD, BANKC, GROUPC, generateExternalId(), pan);
    }

    String activateCard(String pan) {
        String BANKC = pan.substring(4, 6);
        return String.format(ACTIVATE_CARD, BANKC, GROUPC, generateExternalId(), pan, BANKC, GROUPC);
    }

    String assignPin(String pan, String originatorId, String expiry, String encryptedPin, String terminalId) {
        return String.format(ASSIGN_PIN, pan, expiry, encryptedPin, terminalId);
    }

    String getReconciliation(String terminalId) {
        return String.format(RECONCILIATION, terminalId, humoProps.getLogin());
    }

    String getReconciliationAuth(String paymentId) {
        return String.format(RECONCILIATION_AUTH, paymentId, humoProps.getLogin());
    }

    String getEbppRequestP2P(P2PHumoRequest request) {
        return String.format(EBPP_REQUEST_P2P, request.getSwitchId(),
                request.getPaymentRef(),
                request.getSPan(),
                request.getSExp(),
                request.getRPan(),
                request.getAmount(),
                request.getMid(),
                request.getTid(),
                request.getOriginatorId()
        );
    }

    String getEbppPaymentP2P(String paymentId, String originatorID) {
        return String.format(EBPP_PAYMENT_P2P, paymentId, originatorID);
    }

    private static String generateExternalId() {
        return String.format("%s %s", APP_NAME, System.currentTimeMillis());
    }
}
