package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.card.CardState;
import com.asgardiateam.ofb.humoservice.common.Currency;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class P2PInfoDTO {

    private UUID id;

    private String holderName;

    private String maskedPan;

    private boolean isPrivate;

    private CardState state;

    private Currency currency;

    private String phone;
}
