package com.asgardiateam.ofb.humoservice.humo.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class SenderDTO {

    private String pan;

    private String lastName;

    private String firstName;

    private String retrievalRefNumber;

    private DocumentDTO doc;

}
