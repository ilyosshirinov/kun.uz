package com.asgardiateam.ofb.humoservice.message;

public interface ValidationHelperService {

    String messageForClientToAddCard(String otp, String lang);

    void checkPhoneNumbers(String phoneNumber1, String phoneNumber2);

    String generateCodeToAddCard();

}
