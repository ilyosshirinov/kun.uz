package com.asgardiateam.ofb.humoservice.epos.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class RecoEposDTO {

    private Long id;

    private String name;

    private String merchant;

    private String terminal;

    private Long recoTime;

    private Long version;
}
