package com.asgardiateam.ofb.humoservice.card.balance;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;
import com.asgardiateam.ofb.humoservice.card.CardState;

import javax.persistence.Column;
import javax.persistence.Id;

@Getter
@Setter
@NoArgsConstructor
@RedisHash(value = "CardBalance", timeToLive = 72000)
public class CardBalance {

    @Id
    private String id;

    @Indexed
    @Column(name = "encrypted_pan", unique = true)
    private String encryptedPan;

    @Column(name = "balance")
    private Long balance;

    @Column(name = "state")
    private CardState state;

    @Column(name = "balance_cache_time")
    private Long balanceCacheTime;

    public CardBalance(String encryptedPan) {
        this.encryptedPan = encryptedPan;
    }
}
