package com.asgardiateam.ofb.humoservice.humo;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum HumoTransType {

    ACCOUNT_CREDIT("11M", 1, "Перевод с карты на карту"),
    CREDIT("110", 1, "Пополнение карты"),
    CREDIT_HUMO("11V", 1, "Пополнение карты"),
    PURCHASE("205", -1, "Оплата товаров и услуг"),
    P2P("206", 1, "P2P перевод"),
    INNER_TRANSFER("208", 1, "Входящий перевод"),
    CANCELLED_PURCHASE("225", 1, "Отмена оплаты товаров и услуг"),
    CANCELLED_WITHDRAWAL("227", 1, "Отмена выдачи наличности"),
    CANCELLED_REFUND("226", -1, "Отмена возврата средств"),
    CANCELLED_INNER_TRANSFER("228", -1, "Отмена входящего перевода"),
    BALANCE("32X", -1, "Проверка баланса"),
    ACCOUNT_COMMISSION("32I", -1, "Комиссия за обслуживание счета"),
    WITHDRAWAL("207", -1, "Выдача наличных"),
    DEBIT("129", -1, "Списание с карты"),
    ACCOUNT_DEBIT("12M", -1, "Перевод с карты на карту"),
    REVERSE_CREDIT("124", -1, "Отмена пополнения"),
    REVERSE_DEBIT("113", 1, "Отмена списания"),
    UNDEFINED("0", 0, "");

    private String code;
    private String processingCode;
    private int sign;
    private String name;

    HumoTransType(String code, int sign, String name) {
        this.code = code;
        this.sign = sign;
        this.name = name;
    }

    HumoTransType(String code, String processingCode, int sign, String name) {
        this.code = code;
        this.processingCode = processingCode;
        this.sign = sign;
        this.name = name;
    }

    public static HumoTransType getByCode(String code) {
        return Arrays.asList(HumoTransType.values())
                .parallelStream()
                .filter(transType -> transType.getCode().equals(code))
                .findFirst()
                .orElse(HumoTransType.UNDEFINED);
    }

    public static boolean isReverse(HumoTransType transType) {
        String code = transType.getCode();
        return switch (code) {
            case "225", "227", "226", "228", "124", "113" -> true;
            default -> false;
        };
    }

    public static boolean isCredit(HumoTransType transType) {
        String code = transType.getCode();
        return switch (code) {
            case "110", "11V", "208", "206" -> true;
            default -> false;
        };
    }
}
