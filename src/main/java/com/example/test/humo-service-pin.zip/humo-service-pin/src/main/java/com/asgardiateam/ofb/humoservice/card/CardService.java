package com.asgardiateam.ofb.humoservice.card;

import com.asgardiateam.ofb.humoservice.common.CrudService;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CardService extends CrudService<CardEntity, OnlineCardInfo, UUID> {

    CardEntity getByUUID(UUID uuid);

    List<CardEntity> getByUUIDs(Collection<UUID> uuids);

    Optional<CardEntity> findByEncPan(String pan);

    CardEntity getByEncPan(String pan);

    CardEntity updateCardEntity(CardEntity cardEntity, OnlineCardInfo onlineCardInfo);
}
