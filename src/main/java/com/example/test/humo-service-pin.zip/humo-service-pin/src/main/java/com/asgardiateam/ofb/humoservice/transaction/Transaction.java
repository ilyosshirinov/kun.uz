package com.asgardiateam.ofb.humoservice.transaction;

import lombok.*;
import com.asgardiateam.ofb.humoservice.common.Currency;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "transactions")
public class Transaction implements Serializable {

    @Transient
    private static final String sequenceName = "ofb_humo_transaction_seq";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName, allocationSize = 1)
    private Long id;

    @Column(name = "ext_id", unique = true)
    private String extId;

    @Column(name = "amount")
    private Long amount;

    @Column(name = "currency")
    @Enumerated(EnumType.STRING)
    private Currency currency;

    @Column(name = "start_time")
    private Long startTime;

    @Column(name = "end_time")
    private Long endTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type")
    private TransType type;

    @Column(name = "card_id")
    private UUID cardId;

    @Column(name = "extra_card_id")
    private UUID extraCardId;

    @Column(name = "card")
    private String card;

    @Column(name = "extra_card")
    private String extraCard;

    @Column(name = "merchant_id")
    private String merchantId;

    @Column(name = "terminal_id")
    private String terminalId;

    @Column(name = "request_id", unique = true)
    private String requestId;

    @Column(name = "request_meta")
    private String requestMeta;

    @Column(name = "responseMeta")
    private String responseMeta;

    @Column(name = "response_id")
    private String responseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_status")
    private TransactionStatus status;

    @Column(name = "reverse_time")
    private Long reverseTime;

    @Column(name = "details")
    private String details;

    @Column(name = "error")
    private String error;

    @Column(name = "sender_rrn")
    private String senderRRN;

    @Column(name = "receiver_rrn")
    private String receiverRRN;

    @Version
    @Column(name = "version")
    private Long version;

    public boolean isSuccess() {
        return Objects.equals(this.getStatus(), TransactionStatus.SUCCESS) || Objects.equals(this.getStatus(), TransactionStatus.REVERSED);
    }

    public boolean isHold() {
        return Objects.equals(this.getStatus(), TransactionStatus.HOLD);
    }

    public boolean isPending() {
        return Objects.equals(this.getStatus(), TransactionStatus.PENDING) || Objects.equals(this.getStatus(), TransactionStatus.PROCESSING);
    }

    public boolean isFailed() {
        return Objects.equals(this.getStatus(), TransactionStatus.FAILED);
    }
}
