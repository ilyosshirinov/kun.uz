package com.asgardiateam.ofb.humoservice.controller.dto;

import com.asgardiateam.ofb.humoservice.common.Currency;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;
import com.asgardiateam.ofb.humoservice.card.CardState;

import java.util.UUID;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CardInfoDTO {

    private UUID id;

    private Long balance;

    private String expire;

    private String holderName;

    private String maskedPan;

    private Currency currency;

    private String phone;

    private boolean isPrivate;

    private CardState state;

    private Boolean  isPinCode;
}
