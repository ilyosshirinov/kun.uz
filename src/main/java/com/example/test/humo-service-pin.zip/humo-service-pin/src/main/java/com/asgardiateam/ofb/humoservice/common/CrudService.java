package com.asgardiateam.ofb.humoservice.common;

import java.util.Optional;

public interface CrudService<T, U, I> {

    T getById(I id);

    Optional<T> findById(I id);

    void delete(T t);

    void update(T t, U u);

    T save(T t);

}
