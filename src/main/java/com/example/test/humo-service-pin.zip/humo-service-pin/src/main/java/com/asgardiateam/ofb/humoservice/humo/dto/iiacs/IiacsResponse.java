package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsResponse {

    private Integer listSize;

    private IiacsCardResponse card;

    private List<IiacsAccountItem> account;

    private IiacsBalanceDTO balance;

    private MbDTO mb;

}
