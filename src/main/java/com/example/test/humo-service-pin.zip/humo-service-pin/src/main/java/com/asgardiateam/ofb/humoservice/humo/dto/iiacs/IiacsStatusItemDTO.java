package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import com.asgardiateam.ofb.humoservice.humo.dto.info.StatusDTO;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class IiacsStatusItemDTO extends StatusDTO {

    private String type;

    @Override
    public String toString() {
        return "IiacsStatusItemDTO{" +
                "type='" + type + '\'' +
                '}' + " actionCode = " + super.getActionCode();
    }
}
