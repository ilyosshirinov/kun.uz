package com.asgardiateam.ofb.humoservice.transaction;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.asgardiateam.ofb.humoservice.controller.dto.PassportDocumentDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.SenderDetailsDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.DocumentDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Objects;
import java.util.Optional;

public class SenderDTOTest {
    private SenderDetailsDTO senderDetailsDTO;
    private SenderDTO.SenderDTOBuilder senderDTOBuilder;

    @BeforeEach
    void setUp() {
        // Create a mock of SenderDetailsDTO
        senderDetailsDTO = mock(SenderDetailsDTO.class);
        senderDTOBuilder = SenderDTO.builder();
    }

    @Test
    @DisplayName("test to invoke withou passportSeriesNumber")
    void testPinfl() {
        // Arrange
        PassportDocumentDTO passport = mock(PassportDocumentDTO.class);
        when(passport.getSeriesNumber()).thenReturn(null);
        when(passport.getPinfl()).thenReturn("31001937190024");
        when(senderDetailsDTO.getDocument()).thenReturn(passport);
        when(senderDetailsDTO.getFirstName()).thenReturn("Jakhongir");
        when(senderDetailsDTO.getLastName()).thenReturn("Sabirov");

        // Act
        SenderDTO result = buildDocument(senderDetailsDTO);

        // Assert
        DocumentDTO expectedDocument = new DocumentDTO();
        expectedDocument.setPinfl("31001937190024");
        SenderDTO expectedSenderDTO = senderDTOBuilder
                .firstName("Jakhongir")
                .lastName("Sabirov")
                .doc(expectedDocument)
                .build();

        assertAll(() -> assertEquals(expectedSenderDTO.getFirstName(), result.getFirstName()),
                  () -> assertEquals(expectedSenderDTO.getLastName(),  result.getLastName()),
                  () -> assertEquals(expectedSenderDTO.getDoc().getSeriesNumber(),  result.getDoc().getSeriesNumber()),
                  () -> assertEquals(expectedSenderDTO.getDoc().getPinfl(),  result.getDoc().getPinfl())
        );

    }



    // Your buildDocument method
    private SenderDTO buildDocument(SenderDetailsDTO senderDetailsDTO) {
        PassportDocumentDTO passport = senderDetailsDTO.getDocument();
        DocumentDTO document = new DocumentDTO();
        Optional.ofNullable(passport).ifPresent(pass -> {
            Optional.ofNullable(pass.getSeriesNumber())
                    .ifPresent(document::setSeriesNumber);

            Optional.ofNullable(pass.getPinfl())
                    .ifPresent(document::setPinfl);
        });

        return SenderDTO.builder()
                .firstName(senderDetailsDTO.getFirstName())
                .lastName(senderDetailsDTO.getLastName())
                .doc(document)
                .build();
    }
}
