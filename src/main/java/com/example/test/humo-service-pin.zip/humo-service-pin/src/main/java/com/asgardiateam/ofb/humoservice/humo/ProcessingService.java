package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.ofb.humoservice.common.Lang;
import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.epos.RecoEpos;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.SenderDTO;
import com.asgardiateam.ofb.humoservice.humo.dto.ShortCardInfo;
import com.asgardiateam.ofb.humoservice.transaction.Transaction;
import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;

import java.util.Set;
import java.util.UUID;

public interface ProcessingService {

    OnlineCardInfo getCardByUuid(UUID uuid);

    Set<OnlineCardInfo> getCardsByUuids(Set<UUID> uuids);

    OnlineCardInfo getCardByPan(String pan);

    Transaction holdCreate(Transaction transaction);

    Transaction holdConfirm(Transaction transaction);

    Transaction credit(Transaction transaction, SenderDTO senderDetails);

    Transaction reverse(Transaction transaction);

    boolean block(UUID uuid);

    CardUnblockResultDTO unblock(UUID uuid);

    boolean resetPin(UUID uuid);

    boolean pinVerify(PinVerifyDto verifyDto);

    TotalBalanceDTO getTotalBalance(Set<UUID> cards);

    TransactionStatus checkTransaction(Transaction transaction);

    CardHistoryInfo getCardHistory(UUID uuid, Long from, Long to);

    ShortCardInfo addCard(CardDTO card, String  lang);

    OnlineCardInfo verifyCard(CardVerifyDTO cardVerifyDto);

    boolean deactivateCard(UUID cardId);

    Transaction p2p(Transaction transaction);

    void doReco(RecoEpos epos);

    boolean assignPin(UUID cardId, String newPin, String terminalId);

    PinflMethodDTO cardPinfl(PinflMethodDTO request);

    String cardPinflByPan(String pan);

    ShortCardInfo addCardNewWay(CardDTO cardDTO);

    OnlineCardInfo verifyCardNew(CardVerifyDTO cardVerifyDTO);

    Set<CardListToken> getListOfCardsByPhone(String phone);
}
