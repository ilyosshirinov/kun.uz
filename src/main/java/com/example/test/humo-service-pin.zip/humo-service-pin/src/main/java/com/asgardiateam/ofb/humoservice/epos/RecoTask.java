package com.asgardiateam.ofb.humoservice.epos;

import com.asgardiateam.ofb.humoservice.epos.dto.RecoEposDTO;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.HumoService;
import com.asgardiateam.ofb.humoservice.mapper.EposMapper;
import io.vavr.control.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Log4j2
@Component
@RequiredArgsConstructor
public class RecoTask {

    private final HumoService humoService;
    private final RecoEposRepository eposRepository;
    private final EposMapper eposMapper;

    @Scheduled(cron = "0 45 8,11,14,23 * * ?")
    @SchedulerLock(name = "RECO_TASK", lockAtLeastFor = "PT5M", lockAtMostFor = "PT20M")
    public void reco() {
        log.debug("RECO IS WORKING: {} ", LocalDateTime.now());
        eposRepository.findAll()
                .forEach(epos -> Try.run(() -> humoService.doReco(epos)).onFailure(log::error));
    }

    public void doRecoForOne(Long id) {
        humoService.doReco(findById(id));
    }

    public List<RecoEposDTO> getAllRecoEpos() {
        return findAll()
                .stream()
                .map(eposMapper::toDTO)
                .toList();
    }

    private RecoEpos findById(Long id) {
        return eposRepository.findById(id)
                .orElseThrow(HumoServiceApiException::eposNotFound);
    }

    private List<RecoEpos> findAll() {
        return eposRepository.findAll();
    }
    public RecoEposDTO addNewReco(RecoEposDTO recoEposDTO){
        try{
            recoEposDTO.setRecoTime(Instant.now().toEpochMilli());
            eposRepository.save(eposMapper.toEntity(recoEposDTO));
        } catch (Throwable e) {
            log.error(e);
            log.error(Arrays.toString(e.getStackTrace()));
        }
        return recoEposDTO;
    }
}
