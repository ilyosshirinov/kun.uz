package com.asgardiateam.ofb.humoservice.controller.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CardBlockResultDTO {

    private UUID id;

    private Boolean isBlocked;

    private String cardInfo;

    private String blockOrUnblockInfo;

    public CardBlockResultDTO(UUID id, Boolean isBlocked) {
        this.id = id;
        this.isBlocked = isBlocked;
    }
}
