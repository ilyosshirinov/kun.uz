package com.asgardiateam.ofb.humoservice.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SenderDetailsDTO {

    @NotBlank
    private String pan;

    @NotBlank
    private String lastName;

    @NotBlank
    private String firstName;

    private String retrievalRefNumber;

    private PassportDocumentDTO document;
}
