package com.asgardiateam.ofb.humoservice.log;

import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;
import io.vavr.control.Try;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import io.sentry.Sentry;

import java.util.Arrays;
import java.util.Map;


@Log4j2
@Service
@RequiredArgsConstructor
public class LogService {

    private final Tracer tracer;

    public void logException(Throwable ex) {
        log.debug("ERROR = {} CAUSE = {}", ex.getMessage(), ex.getCause());
        log.error(Arrays.toString(ex.getStackTrace()));
        sentToSentry(ex, Map.of("span", getCurrentSpan()));
    }

    public String getCurrentSpan() {
        return Try.of(tracer::currentSpan)
                .map(Span::context)
                .map(TraceContext::spanIdString)
                .onFailure(this::logException)
                .getOrElse("");
    }

    public static void sentToSentry(Throwable ex, Map<String, String> params) {
        params.forEach(Sentry::setExtra);
        Sentry.captureException(ex);
    }

}
