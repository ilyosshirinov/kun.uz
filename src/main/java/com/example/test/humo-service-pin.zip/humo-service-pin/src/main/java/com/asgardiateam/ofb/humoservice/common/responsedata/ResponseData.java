package com.asgardiateam.ofb.humoservice.common.responsedata;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"data", "errorMessage", "timestamp"})
public class ResponseData<T> {

    private T data;

    private String errorMessage;

    private Long timestamp;

    public static <T> ResponseData<T> responseData(T t) {
        return new ResponseData<>(t, null, System.currentTimeMillis());
    }

    public static ResponseData<?> errorResponseData(String key) {
        return new ResponseData<>(null, key, System.currentTimeMillis());
    }
}
