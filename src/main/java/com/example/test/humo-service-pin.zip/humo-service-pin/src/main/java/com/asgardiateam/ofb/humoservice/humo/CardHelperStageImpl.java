package com.asgardiateam.ofb.humoservice.humo;

import com.asgardiateam.encryptservice.encrypt.EncryptDecryptService;
import com.asgardiateam.ofb.humoservice.card.CardEntity;
import com.asgardiateam.ofb.humoservice.card.CardService;
import com.asgardiateam.ofb.humoservice.card.balance.CardBalanceService;
import com.asgardiateam.ofb.humoservice.common.CircuitBreakerFactory;
import com.asgardiateam.ofb.humoservice.config.props.AppProps;
import com.asgardiateam.ofb.humoservice.config.props.HumoProps;
import com.asgardiateam.ofb.humoservice.controller.dto.CardDTO;
import com.asgardiateam.ofb.humoservice.controller.dto.CardVerifyDTO;
import com.asgardiateam.ofb.humoservice.encryption.TripleDES;
import com.asgardiateam.ofb.humoservice.epos.RecoEposRepository;
import com.asgardiateam.ofb.humoservice.exception.HumoServiceApiException;
import com.asgardiateam.ofb.humoservice.humo.dto.OnlineCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.ShortCardInfo;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsSmsSendResponse;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsSmsVerifyResponse;
import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsSmsVerifyResponseInProd;
import com.asgardiateam.ofb.humoservice.transaction.TransactionRepo;
import com.asgardiateam.sms.SmsService;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.vavr.control.Try;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType.FIVE;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.OTP_IS_NOT_CORRECT_MESSAGE;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Log4j2
@Service
@Profile("stage")
public class CardHelperStageImpl extends HumoService {

    private final HumoAPI humoAPI;
    private final CardService cardService;
    private final CircuitBreakerFactory circuitBreakerFactory;
    private final EncryptDecryptService encryptDecryptService;

    public CardHelperStageImpl(HumoAPI humoAPI, AppProps appProps, CardService cardService, TransactionRepo transactionRepo, RecoEposRepository recoEposRepository, CardBalanceService cardBalanceService, CircuitBreakerFactory circuitBreakerFactory, EncryptDecryptService encryptDecryptService, HumoErrorRepository humoErrorRepository, HumoProps humoProps, TripleDES tripleDES, SmsService smsService) {
        super(humoAPI, appProps, cardService, transactionRepo, recoEposRepository, cardBalanceService, circuitBreakerFactory, encryptDecryptService, humoErrorRepository, humoProps, tripleDES, smsService);
        this.humoAPI = humoAPI;
        this.cardService = cardService;
        this.circuitBreakerFactory = circuitBreakerFactory;
        this.encryptDecryptService = encryptDecryptService;
    }

    @Override
    public ShortCardInfo addCard(CardDTO cardDTO, String lang) {
        String encPan = cardDTO.getPan();
        String pan = encryptDecryptService.decrypt(encPan);

        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));

        CircuitBreaker sendSms = circuitBreakerFactory.getSendSms();

        String phone = cardDTO.getUserPhone().startsWith("+") ? cardDTO.getUserPhone() : "+" + cardDTO.getUserPhone();

        IiacsSmsSendResponse iiacsSmsSendResponse = Try.of(() ->
                        sendSms.executeSupplier(() -> humoAPI.sendSms(pan, phone, FIVE)))
                .onFailure(log::error)
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        if (!StringUtils.equalsIgnoreCase(iiacsSmsSendResponse.getState(), "on"))
            throw new HumoServiceApiException("state.not.valid", BAD_REQUEST);

        cardService.save(card);

        return ShortCardInfo.builder()
                .pan(pan)
                .id(card.getId())
                .expiry(cardDTO.getExpire())
                .phone(cardDTO.getUserPhone())
                .build();
    }

    @Override
    public OnlineCardInfo verifyCard(CardVerifyDTO cardVerifyDto) {
        CardEntity card = cardService.getById(cardVerifyDto.getId());

//        String code = encryptDecryptService.encrypt(cardVerifyDto.getCode());
//        if (!Objects.equals(code, card.getVerifyCode()))
//            throw new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);

        CircuitBreaker verifySms = circuitBreakerFactory.getVerifySms();

        IiacsSmsVerifyResponse iiacsSmsVerifyResponse = Try.of(() ->
                        verifySms.executeSupplier(() ->
                                humoAPI.verifyCode(encryptDecryptService.decrypt(card.getEncryptedPan()), cardVerifyDto.getCode(), FIVE)))
                .onFailure(log::error)
                .onFailure(HumoServiceApiException.class, ex -> {
                    throw ex;
                })
                .getOrElseThrow(HumoServiceApiException::humoNotAvailable);

        if (!StringUtils.equalsIgnoreCase(iiacsSmsVerifyResponse.getStatus(), "on"))
            throw new HumoServiceApiException("state.not.valid", BAD_REQUEST);

        return getCardByEncPan(card.getEncryptedPan());
    }

    @Override public ShortCardInfo addCardNewWay(CardDTO cardDTO) {
        String encPan = cardDTO.getPan();
        String pan = encryptDecryptService.decrypt(encPan);

        OnlineCardInfo cardInfo = getCardByEncPan(encPan);


        CardEntity card = cardService.findByEncPan(encPan)
                .orElse(new CardEntity(encPan));


        sendRequestToHumoToAddCard(pan,cardDTO.getUserPhone());

        cardService.save(card);


        return ShortCardInfo.builder()
                .pan(pan)
                .id(card.getId())
                .expiry(cardDTO.getExpire())
                .phone(cardInfo.getPhone())
                .build();



    }

    @Override public OnlineCardInfo verifyCardNew(CardVerifyDTO cardVerifyDTO) {
        CardEntity card = cardService.getById(cardVerifyDTO.getId());

        OnlineCardInfo onlineCardInfo = getCardByEncPan(card.getEncryptedPan());

        IiacsSmsVerifyResponseInProd response = sendRequestToHumoToVerifyAddCard(card, cardVerifyDTO);

        if (Objects.isNull(response.getToken()))
            throw new HumoServiceApiException(OTP_IS_NOT_CORRECT_MESSAGE, BAD_REQUEST);
        // TODO need to save token if we get succesffully get token from HUMO PC

        return onlineCardInfo;
    }


}
