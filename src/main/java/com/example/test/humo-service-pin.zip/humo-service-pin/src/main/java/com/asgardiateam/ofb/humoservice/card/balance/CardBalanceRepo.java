package com.asgardiateam.ofb.humoservice.card.balance;

import org.springframework.data.keyvalue.repository.KeyValueRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CardBalanceRepo extends KeyValueRepository<CardBalance, String> {

    Optional<CardBalance> findByEncryptedPan(String encPan);

}
