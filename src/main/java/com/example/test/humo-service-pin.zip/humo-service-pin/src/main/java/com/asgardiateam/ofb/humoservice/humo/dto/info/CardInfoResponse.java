package com.asgardiateam.ofb.humoservice.humo.dto.info;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardInfoResponse {

    private long count;

    private long success;

    private long fail;

    private List<RecordDTO> records;

}
