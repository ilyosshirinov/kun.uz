package com.asgardiateam.ofb.humoservice.humo.dto.payment;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class P2PHumoRequest {

    private String paymentRef;

    private String switchId;

    private String sPan;

    private String sExp;

    private String rPan;

    private Long amount;

    private String mid;

    private String tid;

    private String originatorId;

}
