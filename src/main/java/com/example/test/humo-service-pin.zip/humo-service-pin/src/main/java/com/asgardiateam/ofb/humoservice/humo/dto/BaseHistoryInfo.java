package com.asgardiateam.ofb.humoservice.humo.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"time", "maskedPan", "amount", "currency", "merchantName", "merchant",
        "terminal", "city", "address", "transactionNumber", "credit", "reversal"})
public class BaseHistoryInfo {

    private Long time;

    private String maskedPan;

    private Long amount;

    private String currency;

    private String merchantName;

    private String merchant;

    private String terminal;

    private String city;

    private String address;

    private Long transactionNumber;

    private Boolean credit;

    private Boolean reversal;

}
