package com.asgardiateam.ofb.humoservice.epos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecoEposRepository extends JpaRepository<RecoEpos, Long> {
    RecoEpos findByMerchant(String merchant);
}
