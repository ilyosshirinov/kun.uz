package com.asgardiateam.ofb.humoservice;

import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

@RefreshScope
@EnableScheduling
@EnableFeignClients
@EnableDiscoveryClient
@SpringBootApplication
@EnableSchedulerLock(defaultLockAtMostFor = "PT20M")
public class HumoServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(HumoServiceApplication.class, args);
    }

}

