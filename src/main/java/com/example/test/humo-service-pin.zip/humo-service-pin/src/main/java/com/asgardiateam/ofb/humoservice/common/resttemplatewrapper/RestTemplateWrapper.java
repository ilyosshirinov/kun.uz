package com.asgardiateam.ofb.humoservice.common.resttemplatewrapper;

import com.asgardiateam.ofb.humoservice.humo.dto.iiacs.IiacsBaseErrorResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.asgardiateam.ofb.humoservice.exception.ExternalServiceException;

import static io.vavr.API.*;
import static java.util.Optional.ofNullable;
import static com.asgardiateam.ofb.humoservice.common.resttemplatewrapper.RestTemplateType.*;
import static com.asgardiateam.ofb.humoservice.exception.ExceptionConstant.TIME_OUT;
import static com.asgardiateam.ofb.humoservice.exception.ExternalServiceException.*;
import static com.asgardiateam.ofb.humoservice.message.MessageKey.HUMO_NOT_AVAILABLE;

@Log4j2
@Component
public class RestTemplateWrapper {

    private final Tracer tracer;
    private final RestTemplate restTemplate5;
    private final RestTemplate restTemplate10;
    private final RestTemplate restTemplate30;
    private final RestTemplate restTemplate15;
    private final RestTemplate restTemplate40;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public RestTemplateWrapper(Tracer tracer,
                               @Qualifier("restTemplate5") RestTemplate restTemplate5,
                               @Qualifier("restTemplate10") RestTemplate restTemplate10,
                               @Qualifier("restTemplate30") RestTemplate restTemplate30,
                               @Qualifier("restTemplate15") RestTemplate restTemplate15,
                               @Qualifier("restTemplate40") RestTemplate restTemplate40) {
        this.tracer = tracer;
        this.restTemplate5 = restTemplate5;
        this.restTemplate10 = restTemplate10;
        this.restTemplate15 = restTemplate15;
        this.restTemplate30 = restTemplate30;
        this.restTemplate40 = restTemplate40;
    }

    public <T, R> T sendRequest(String url,
                                R request,
                                HttpMethod httpMethod,
                                HttpHeaders httpHeaders,
                                RestTemplateType type,
                                ParameterizedTypeReference<T> typeReference) {


        RestTemplate restTemplate = getRestTemplate(type);
        Span span = this.tracer.nextSpan().name("rest-template");

        try (Tracer.SpanInScope ws = this.tracer.withSpan(span.start())) {
            HttpEntity<?> httpEntity = new HttpEntity<>(request, httpHeaders);

            log.debug("REQUEST = {} url = {} ", request, url);

            var responseEntity = restTemplate.exchange(url, httpMethod, httpEntity, typeReference);

            log.debug("RESPONSE = {}", responseEntity.getBody());

            return ofNullable(responseEntity.getBody()).orElseThrow(ExternalServiceException::unknownErrorException);
        } catch (ResourceAccessException ex) {
            log.error(ex);
            log.debug(TIME_OUT);
            throw resourceAccessException(HUMO_NOT_AVAILABLE, null);
        } catch (HttpServerErrorException | HttpClientErrorException ex) {
            log.error(ex);
            log.debug("RESPONSE = {}", ex.getResponseBodyAsString());

            String body = ex.getResponseBodyAsString();

            IiacsBaseErrorResponse iiacsBaseErrorResponse = new IiacsBaseErrorResponse();
            try {
                iiacsBaseErrorResponse = objectMapper.readValue(body, IiacsBaseErrorResponse.class);
            } catch (JsonProcessingException e) {
                log.error(e);
            }

            throw ex.getStatusCode().is5xxServerError() ?
                    serverErrorException(HUMO_NOT_AVAILABLE, ex.getStatusCode(), body) :
                    clientErrorException(HUMO_NOT_AVAILABLE, ex.getStatusCode(), body, iiacsBaseErrorResponse);
        } catch (Throwable ex) {
            log.error(ex);
            throw unknownErrorException();
        } finally {
            span.end();
        }
    }

    public <T, R> T sendRequest(String url,
                                R request,
                                HttpMethod httpMethod,
                                HttpHeaders httpHeaders,
                                RestTemplateType type,
                                Class<T> responseType) {


        RestTemplate restTemplate = getRestTemplate(type);
        Span span = this.tracer.nextSpan().name("rest-template");

        try (Tracer.SpanInScope ws = this.tracer.withSpan(span.start())) {
            HttpEntity<?> httpEntity = new HttpEntity<>(request, httpHeaders);

            log.debug("REQUEST = {} url = {} ", request, url);

            var responseEntity = restTemplate.exchange(url, httpMethod, httpEntity, responseType);

            log.debug("RESPONSE = {}", responseEntity.getBody());

            return ofNullable(responseEntity.getBody()).orElseThrow(ExternalServiceException::unknownErrorException);
        } catch (ResourceAccessException ex) {
            log.error(ex);
            log.debug(TIME_OUT);
            throw resourceAccessException(HUMO_NOT_AVAILABLE, null);
        } catch (HttpServerErrorException | HttpClientErrorException ex) {
            log.error(ex);
            log.debug("RESPONSE = {}", ex.getResponseBodyAsString());

            String body = ex.getResponseBodyAsString();
            throw ex.getStatusCode().is5xxServerError() ?
                    serverErrorException(HUMO_NOT_AVAILABLE, ex.getStatusCode(), body) :
                    clientErrorException(HUMO_NOT_AVAILABLE, ex.getStatusCode(), body, null);
        } catch (Throwable ex) {
            log.error(ex);
            throw unknownErrorException();
        } finally {
            span.end();
        }
    }


    private RestTemplate getRestTemplate(RestTemplateType type) {
        return Match(type)
                .of(
                        Case($(FIVE), restTemplate5),
                        Case($(TEN), restTemplate10),
                        Case($(FIFTEEN), restTemplate15),
                        Case($(THIRTY), restTemplate30),
                        Case($(FORTY), restTemplate40),
                        Case($(), restTemplate15)
                );
    }
}
