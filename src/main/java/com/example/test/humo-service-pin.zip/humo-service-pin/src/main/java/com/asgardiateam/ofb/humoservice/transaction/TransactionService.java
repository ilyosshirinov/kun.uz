package com.asgardiateam.ofb.humoservice.transaction;

import com.asgardiateam.ofb.humoservice.controller.dto.*;

public interface TransactionService {

    BaseTransactionInfoDTO holdCreate(TransactionDTO transaction);

    BaseTransactionInfoDTO holdConfirm(String extID);

    BaseTransactionInfoDTO credit(CreditTransactionDTO transaction);

    BaseTransactionInfoDTO p2p(P2PTransactionDTO transaction);

    BaseTransactionInfoDTO reverse(String id);

    BaseTransactionInfoDTO checkTransaction(String extId);

}
