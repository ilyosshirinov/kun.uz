package com.asgardiateam.ofb.humoservice.humo;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.cloud.context.environment.EnvironmentChangeEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Log4j2
@Component
@RequiredArgsConstructor
public class HumoListener implements ApplicationListener<EnvironmentChangeEvent> {

    private final HumoAPIImpl humoAPI;

    @Override
    public void onApplicationEvent(EnvironmentChangeEvent event) {
        log.debug("Configs change" + event.getKeys());
        humoAPI.init();
    }

}
