package com.asgardiateam.ofb.humoservice.humo.dto.payment;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import com.asgardiateam.ofb.humoservice.transaction.TransactionStatus;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class PaymentDTO {

    private String paymentId;

    private String paymentRef;

    private TransactionStatus status;

    private String errorMsg;

    private String humoCode;

    private String senderRRN;

    private String receiverRRN;

    public PaymentDTO(String paymentRef) {
        this.paymentRef = paymentRef;
    }
}
