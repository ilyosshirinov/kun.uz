package com.asgardiateam.ofb.humoservice.humo.dto;

import com.asgardiateam.ofb.humoservice.common.Currency;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import com.asgardiateam.ofb.humoservice.card.CardState;

import java.util.UUID;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OnlineCardInfo {

    private UUID id;

    private CardState state;

    private String phone;

    private String holderName;

    private Long balance;

    private Currency currency;

    private String maskedPan;

    private String pan;

    private String expire;

    private boolean isPrivate;

    private Boolean  isPinCode;
}
