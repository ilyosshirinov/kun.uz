package com.asgardiateam.ofb.humoservice.humo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Set;

import static com.asgardiateam.ofb.humoservice.message.MessageKey.*;

@Getter
@RequiredArgsConstructor
public enum HumoTransStatus {

    APPROVED(Set.of("000", "001", "002", "003", "004", "005", "006", "007"), ""),
    EXPIRE_CARD(Set.of("101", "201"), CARDS_EXPIRED),
    EPOS_ERROR(Set.of("109", "120"), INTERNAL_ERROR),
    NOT_SUFFICIENT_FUND(Set.of("116"), CARDS_INSUFFICIENT_FUNDS),
    INVALID_CARD_NUMBER(Set.of("111"), CARD_NUMBER_INVALID),
    LIMIT_EXCEEDED(Set.of("107", "108"), CARD_LIMIT_EXCEEDED),
    CARD_BLOCKED(Set.of("100", "209", "208", "207", "203", "204", "205", "206", "200", "126", "125", "129"), CARDS_BLOCK),
    UNKNOWN(Set.of(), "");

    private static final HumoTransStatus[] vals = HumoTransStatus.values();

    private final Set<String> codes;

    private final String msgKey;

    public static String getMsgKey(String code) {
        return Arrays.stream(vals)
                .filter(status -> status.getCodes().contains(code))
                .findFirst()
                .map(HumoTransStatus::getMsgKey)
                .orElse(INTERNAL_ERROR);
    }

}
