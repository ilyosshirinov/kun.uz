package com.asgardiateam.ofb.humoservice.message;

public final class MessageKey {

    public static final String DEBIT_ERROR = "humo.debit.error";
    public static final String RECEIVER_CARD_NOT_VALID = "humo.receiver.card.not.valid";
    public static final String SENDER_CARD_NOT_VALID = "humo.sender.card.not.valid";

    private MessageKey() {

    }

    public static final String OTP_IS_NOT_CORRECT_MESSAGE = "otp.is.not.correct";
    public static final String PERMISSION_WAS_NOT_GRANTED_PREVIOUSLY = "permission.was.not.granted.previously";
    public static final String PERMISSION_ALREADY_GRANTED = "permission.already.granted";
    public static final String APP_NAME_NOT_VALID = "app.name.not.valid";
    public static final String RNS_ID_NOT_VALID = "rns.id.not.valid";
    public static final String RNS_MESSAGE_NOT_VALID = "rns.message.not.valid";
    public static final String SMS_INFO_PHONE_NOT_MATCHED = "sms.info.phone.not.matched";
    public static final String USER_PHONE_NOT_VALID = "user.phone.not.valid";
    public static final String NEW_PIN_NOT_VALID = "new.pin.not.valid";
    public static final String HUMO_NOT_AVAILABLE = "humo.not.available";
    public static final String PIN_LENGTH_NOT_VALID = "pin.length.not.valid";
    public static final String CARD_PAN_OR_NEW_PIN_NOT_VALID = "card.pan.or.new.pin.not.valid";
    public static final String CARD_PAN_OR_ENCRYPTED_PIN_NOT_VALID = "card.pan.or.encrypted.pin.not.valid";
    public static final String CARDS_BLOCK = "cards.blocked";
    public static final String CARDS_NOT_ACTIVE = "cards.not.active";
    public static final String CARDS_NOT_FOUND = "cards.not.found";
    public static final String DEACTIVATE_FAILED = "deactivate.card.failed";
    public static final String ASSIGN_PIN_FAILED = "assign.card.failed";
    public static final String CARDS_NOT_AVAILABLE = "cards.not.available";
    public static final String CARDS_EXPIRED = "cards.expired";
    public static final String CARDS_INSUFFICIENT_FUNDS = "cards.insufficient.funds";
    public static final String BANK_NOT_FOUND = "bank.not.found";
    public static final String CURRENCY_NOT_VALID = "currency.not.valid";
    public static final String OTP_NOT_FOUND = "otp.not.found";
    public static final String CARDS_PAN_OR_EXPIRE_NOT_VALID = "cards.panorexp.not.valid";
    public static final String CARDS_BLOCKED_BY_SVGATE = "cards.blocked.by.svgate";
    public static final String PAN_NOT_VALID = "pan.not.valid";
    public static final String UUID_NOT_VALID = "uuid.not.valid";
    public static final String PARAMETERS_NOT_VALID = "params.not.valid";
    public static final String PROCESSING_NOT_AVAILABLE_MSG = "processing.not.available";
    public static final String SMS_INFO_NOT_ACTIVE = "sms.info.not.active";
    public static final String USER_NOT_FOUND = "user.not.found";
    public static final String OPERATION_FORBIDDEN_COORP_CARD = "operation.forbidden.coorp.card";
    public static final String LIMIT_P2P_PASSED = "limit.p2p.passed";
    public static final String MERCHANT_ID_NOT_FOUND = "supplier.not.found";
    public static final String MERCHANT_ID_NOT_VALID = "merchant.id.not.valid";
    public static final String TERMINAL_ID_NOT_VALID = "merchant.id.not.valid";
    public static final String PORT_NOT_VALID = "port.not.valid";
    public static final String ID_NOT_VALID = "id.not.valid";
    public static final String AMOUNT_NOT_VALID = "amount.not.valid";
    public static final String AMOUNT_LOWER_THAN_EXPECTED = "amount.lower.than.expected";
    public static final String METHOD_NOT_FOUND = "method.not.found";
    public static final String CARD_CAN_NOT_BLOCK = "card.can.not.block";
    public static final String CARD_CAN_NOT_EMPTY = "card.can.not.empty";
    public static final String RECEIVER_CARD_NOT_AVAILABLE = "receiver.card.not.available";
    public static final String SENDER_CARD_NOT_AVAILABLE = "sender.card.not.available";
    public static final String CARD_NUMBER_INVALID = "card.number.invalid";
    public static final String CARD_TOKEN_NOT_FOUND = "card.token.not.found";
    public static final String CARD_EXPIRY_INVALID = "card.expiry.invalid";
    public static final String EXT_ID_EXISTS = "ext.id.exists";
    public static final String CARD_LIMIT_EXCEEDED = "card.limit.exceeded";
    public static final String INTERNAL_ERROR = "internal.error";
    public static final String SERVICE_DISABLED = "service.disabled";
    public static final String COMMISSION_NOT_VALID = "commission.not.valid";
    public static final String EPOS_NOT_FOUND = "epos.not.found";
    public static final String EPOS_NOT_VALID = "epos.not.valid";
    public static final String OPERATION_FORBIDDEN = "operation.forbidden";
    public static final String RECEIPT_CANCEL_FAILED = "receipt.cancel.failed";
    public static final String RECEIPT_CAN_NOT_PAY = "receipt.can.not.pay";
    public static final String RECEIPT_NOT_FOUND = "receipt.not.found";
    public static final String NOT_VALID_ACCOUNT_TYPE = "account.type.not.valid";
    public static final String TRANSACTION_CAN_NOT_CONFIRM = "transaction.can.not.confirm";
    public static final String TRANSACTION_NOT_FOUND = "transaction.not.found";
    public static final String P2P_DISABLED = "p2p.disabled";
    public static final String TERMINAL_TYPE_WRONG = "wrong.terminal.type";
    public static final String TERMINAL_ID_WRONG = "wrong.terminal.id";
    public static final String MERCHANT_ID_WRONG = "wrong.merchant.id";
    public static final String WRONG_TRANS_TYPE = "wrong.trans.type";
    public static final String PHONE_NOT_VALID = "phone.not.valid";

    public static final String CARD_TAKING_ANOTHER_OPERATION = "card.taking.another.operation";
    public static final String UNKNOWN_ERROR = "unknown.error";
    public static final String DATE_INVALID = "date.invalid";
    public static final String PERIOD_TOO_LONG = "period.too.long";
    public static final String SENDER_AND_RECEIVER_CARD_EQUALS = "sender.and.receiver.card.equals";
    public static final String SUCCESS = "success";
    public static final String NEW_PIN_LENGTH_NOT_VALID = "new.pin.length.not.valid";
    public static final String OTP_LENGTH_NOT_VALID = "otp.length.not.valid";
    public static final String ACCESS_DENIED_TO_UNBLOCK_CARD = "access.denied.to.unblock.card";
    public static final String ACCESS_DENIED_TO_BLOCK_CARD = "access.denied.to.block.card";
    public static final String CARD_IS_UNBLOCKED = "card.is.unblocked";

    public static final String SMS_SEND_TO_ADD_CARD = "sms.send.to.add.card";

    public static final String PAN_MUST_CONTAIN_ONLY_16DIGITS = "param.pan must contain only 16 digits";
    public static final String PINFL_NOT_FOUND = "pinfl not found";
}
