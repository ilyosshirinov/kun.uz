package com.asgardiateam.ofb.humoservice.humo.dto.iiacs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class IiacsCardRequest {

    public IiacsCardRequest(String primaryAccountNumber) {
        this.primaryAccountNumber = primaryAccountNumber;
    }

    private String primaryAccountNumber;

    @JsonProperty("mb_flag")
    private int mbFlag;

}
