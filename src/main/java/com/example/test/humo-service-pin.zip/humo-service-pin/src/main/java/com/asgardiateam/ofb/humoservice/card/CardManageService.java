package com.asgardiateam.ofb.humoservice.card;

import com.asgardiateam.ofb.humoservice.controller.dto.*;
import com.asgardiateam.ofb.humoservice.humo.dto.CardHistoryInfo;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public interface CardManageService {

    CardAddDTO addCard(CardDTO card, String  lang);

    CardInfoDTO verifyCard(CardVerifyDTO card);

    CardPermissionDeactResponse deactivatePermission(UUID cardId);

    CardInfoDTO getCard(UUID uuid);

    P2PInfoDTO getCardBy(String encPan);

    List<CardInfoDTO> getCards(Set<UUID> uuids);

    CardBlockResultDTO blockCard(CardBlockDTO card);

    CardUnblockResultDTO unblockCard(CardBlockDTO card);

    CardHistoryInfo historyCard(CardHistoryDTO history);

    PinResetResponse resetPin(UUID cardId);

    PinVerifyResponse pinVerify(PinVerifyDto verifyDto);

    TotalBalanceDTO getTotalBalance(Set<UUID> cards);

    boolean assignPin(UUID cardId, String newPin, String terminalId);

    PinflMethodDTO getCardPinfl(PinflMethodDTO request);

    String getOnlyCardPinfl(String pan);

    Set<CardListToken> getListOfCardsByPhone(String phone);

}
