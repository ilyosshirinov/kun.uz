package com.asgardiateam.ofb.humoservice.config;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class R4JConfig {

    public static final String HUMO_PAYMENT = "humo_payment_config";
    public static final String CARDS_CONFIG = "humo_cards_config";
    public static final String HUMO_HISTORY = "humo_history_config";
    public static final String BLOCK_CONFIG = "block_config";
    public static final String UN_BLOCK_CONFIG = "un_block_config";
    public static final String CARD_RESET_PIN = "card_reset_pin";
    public static final String SEND_SMS = "send-sms";
    public static final String VERIFY_SMS = "verify-sms";
    public static final String PERMISSION_DEACTIVATE = "permission-deactivate";

    public CircuitBreakerConfig globalCircuitBreakerConfig() {
        return CircuitBreakerConfig.ofDefaults();
    }

    public CircuitBreakerConfig cardHistory() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(100))
                .slowCallDurationThreshold(Duration.ofSeconds(44))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig sendSms() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(100))
                .slowCallDurationThreshold(Duration.ofSeconds(44))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig verifySms() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(100))
                .slowCallDurationThreshold(Duration.ofSeconds(44))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig permissionDeactivate() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(100))
                .slowCallDurationThreshold(Duration.ofSeconds(44))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig cardResetPin() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(100))
                .slowCallDurationThreshold(Duration.ofSeconds(44))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig cardsConfig() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(60))
                .slowCallDurationThreshold(Duration.ofSeconds(4))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig paymentConfig() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofMinutes(2))
                .slowCallDurationThreshold(Duration.ofSeconds(29))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig blockConfig() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(60))
                .slowCallDurationThreshold(Duration.ofSeconds(9))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    public CircuitBreakerConfig unBlockConfig() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .slowCallRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(60))
                .slowCallDurationThreshold(Duration.ofSeconds(9))
                .permittedNumberOfCallsInHalfOpenState(5)
                .minimumNumberOfCalls(10)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(20)
                .build();
    }

    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry() {
        CircuitBreakerRegistry circuitBreakerRegistry = CircuitBreakerRegistry.of(globalCircuitBreakerConfig());
        circuitBreakerRegistry.addConfiguration(SEND_SMS, sendSms());
        circuitBreakerRegistry.addConfiguration(VERIFY_SMS, verifySms());
        circuitBreakerRegistry.addConfiguration(CARDS_CONFIG, cardsConfig());
        circuitBreakerRegistry.addConfiguration(HUMO_PAYMENT, paymentConfig());
        circuitBreakerRegistry.addConfiguration(HUMO_HISTORY, cardHistory());
        circuitBreakerRegistry.addConfiguration(BLOCK_CONFIG, blockConfig());
        circuitBreakerRegistry.addConfiguration(UN_BLOCK_CONFIG, unBlockConfig());
        circuitBreakerRegistry.addConfiguration(CARD_RESET_PIN, cardResetPin());
        circuitBreakerRegistry.addConfiguration(PERMISSION_DEACTIVATE, permissionDeactivate());
        return circuitBreakerRegistry;
    }
}
